// src/api.js — cliente API com retry/backoff (anti-queda de rede) + logs coloridos
import axios from 'axios';
import log from './logger.js';

const API_BASE = process.env.API_BASE || 'https://esim.buscalotter.com/api';

/* ========= Axios com retry/backoff ========= */
const http = axios.create({ baseURL: API_BASE, timeout: 25000 });

http.interceptors.response.use(
  r => r,
  async err => {
    const cfg = err.config || {};
    cfg.__retryCount = (cfg.__retryCount || 0) + 1;

    const code = err.code;
    const status = err.response?.status;
    const transient =
      ['ECONNRESET','ETIMEDOUT','EAI_AGAIN'].includes(code) ||
      (status && [502,503,504].includes(status));

    if (transient && cfg.__retryCount <= 3) {
      const wait = 600 * Math.pow(2, cfg.__retryCount); // 600, 1200, 2400 ms
      // log colorido
      log.warn?.(
        `↻ [API Retry] ${cfg.__retryCount}/3 em ${wait}ms — ` +
        `${status || code || 'erro de rede'} — ${cfg.method?.toUpperCase()} ${cfg.url}`
      );
      await new Promise(r => setTimeout(r, wait));
      return http(cfg);
    }

    return Promise.reject(err);
  }
);

/* ========= Funções ========= */
export async function getProdutos() {
  const { data } = await http.get('/products.php');
  return data;
}

export async function createOrder(productId, chatId, coupon, esimId) {
  const payload = { product_id: productId, chat_id: String(chatId) };
  if (coupon) payload.coupon = coupon;
  if (esimId) payload.esim_id = esimId;

  const { data } = await http.post('/orders_create.php', payload);
  if (data && data.ok === false) throw new Error(data.message || 'Erro na API');

  return {
    ...data,
    mxv_txid: data.mxv_txid || data.txid || data.idTransaction || null,
    qrcode: data.qrcode || data.pix_code || data.qr_code || null,
    qr_code_image_url: data.qr_code_image_url || data.qrcode_image_url || null,
    final_price_cents:
      typeof data.final_price_cents === 'number'
        ? data.final_price_cents
        : (typeof data.price_cents === 'number'
            ? data.price_cents
            : undefined)
  };
}

export async function orderStatusById(id) {
  const { data } = await http.get(`/order_status.php?order_id=${encodeURIComponent(id)}`);
  return data;
}

export async function listOrdersByChat(chatId) {
  const { data } = await http.get(`/orders_list.php?chat_id=${encodeURIComponent(chatId)}`);
  return data.orders || data;
}

export async function listOrdersByChatPaged(chatId, page = 1, perPage = 10) {
  const { data } = await http.get(`/orders_list.php?chat_id=${encodeURIComponent(chatId)}&page=${page}&per_page=${perPage}`);
  return data;
}

// estoque livre por produto (usa esims.php)
export async function listStockByProduct(productId, page = 1, perPage = 5) {
  const url = `/esims.php?product_id=${encodeURIComponent(productId)}&status=free&page=${page}&per_page=${perPage}`;
  const { data } = await http.get(url);
  return data;
}
