const axios = require('axios');
const log = require('./logger');

const API_BASE = process.env.API_BASE || 'https://esim.buscalotter.com/api';
const SUPPORT_URL = process.env.SUPPORT_URL || 'https://t.me/SEU_SUPORTE';
const STORE_TITLE = process.env.STORE_TITLE || 'UNIVERSAL UNLOCKERS';
const BRAND_URL = process.env.BRAND_URL || 'https://seusite.com';
const OPS = (process.env.OPERADORAS || 'Claro - Cobertura nacional;TIM - 4G/5G de alta velocidade;Vivo - Melhor custo-benefício')
  .split(';').map(s=>s.trim()).filter(Boolean);

function brl(v){ return (v/100).toLocaleString('pt-BR',{minimumFractionDigits:2}); }
function bold(s){ return '<b>'+s+'</b>'; }
function link(txt,url){ return '<a href="'+url+'">'+txt+'</a>'; }

function userLine(username){ return username ? ('👤 '+bold('Username:')+' @'+username+'\n') : ''; }
function idLines(teleId, internalId){
  return '🆔 '+bold('ID do usuário:')+' '+(internalId||'-')+'\n'
       + '🆔 '+bold('ID do Telegram:')+' '+teleId+'\n';
}
function opsLines(){
  const b = [];
  if (OPS.length){
    b.push('🔹 '+bold('Bem-vindo ao Bot de eSIMs!')); b.push('');
    b.push('Aqui você pode comprar eSIMs das principais operadoras:');
    OPS.forEach(op => {
      const lower = op.toLowerCase();
      let emoji = '🔘'; if (lower.startsWith('claro')) emoji='🔵'; else if (lower.startsWith('tim')) emoji='🟣'; else if (lower.startsWith('vivo')) emoji='🟢';
      b.push(`${emoji} ${op}`);
    });
    b.push('');
  }
  return b.join('\n');
}
function infoLines(){
  return [
    '💳 '+bold('Pagamento:')+' PIX instantâneo',
    '⚡ '+bold('Entrega:')+' Automática e instantânea',
    '🔒 '+bold('Segurança:')+' Processado  Com Segurança'
  ].join('\n');
}
function mainCaption(user){
  const title = '✨ '+bold('Bem-vindo(a),')+' '+link(STORE_TITLE, BRAND_URL)+'!';
  const u = userLine(user.username);
  const ids = idLines(user.id, user.internalId || user.chatId);
  const ops = opsLines();
  const infos = infoLines();
  const footer = '\nEscolha uma opção abaixo para começar:';
  return [title, '', u+ids, ops, infos, footer].join('\n');
}
function mainKeyboard(){
  return {
    reply_markup: {
      inline_keyboard: [
        [{ text:'🛒 Comprar eSIM', callback_data:'products' }, { text:'🧾 Meus Pedidos', callback_data:'orders' }],
        [{ text:'ℹ️ Sobre', callback_data:'about' }, { text:'📞 Suporte', url: SUPPORT_URL }]
      ]
    },
    parse_mode: 'HTML', disable_web_page_preview: true
  };
}
function backKeyboard(dest='home'){ return { reply_markup: { inline_keyboard: [[{ text:'↩️ Voltar', callback_data: dest }]] } }; }
async function apiProducts(){ const res = await axios.get(API_BASE+'/products.php', { timeout: 10000 }); if(!res.data||!res.data.ok) throw new Error(res.data&&res.data.message||'falha products'); return res.data.products||[]; }

async function editOrSend(bot, chatId, message, text, opts={}){
  const base={ parse_mode:'HTML', ...opts };
  if (message && typeof message.text==='string'){ return bot.editMessageText(text,{ chat_id:chatId, message_id:message.message_id, ...base }); }
  if (message && typeof message.caption==='string'){ try{ return await bot.editMessageCaption(text,{ chat_id:chatId, message_id:message.message_id, ...base }); }catch{} }
  return bot.sendMessage(chatId, text, base);
}

async function showCategories(bot, chatId, message){
  const prods = await apiProducts();
  if (!prods.length) return editOrSend(bot, chatId, message, 'Sem produtos no momento.', backKeyboard());
  const set=new Set(); prods.forEach(p=> set.add((p.category||'ESIM').toUpperCase()));
  const rows=[...set].map(c=>[{ text:c, callback_data:'cat:'+c }]); rows.push([{ text:'↩️ Voltar', callback_data:'home'}]);
  return editOrSend(bot, chatId, message, 'Escolha uma categoria:', { reply_markup:{ inline_keyboard: rows } });
}
async function showProductsByCategory(bot, chatId, message, category){
  const prods = await apiProducts(); const cat=(category||'ESIM').toUpperCase();
  const items = prods.filter(p => (p.category||'ESIM').toUpperCase()===cat);
  if (!items.length) return editOrSend(bot, chatId, message, 'Sem itens na categoria: '+cat, backKeyboard('products'));
  const rows = items.map(p => [{ text: `${p.name} — R$ ${brl(p.price_cents)} (${p.stock} em estoque)`, callback_data: 'buy:'+p.id }]);
  rows.push([{ text:'↩️ Voltar', callback_data:'products'}]);
  return editOrSend(bot, chatId, message, `Categoria: ${cat}\nSelecione um produto:`, { reply_markup:{ inline_keyboard: rows } });
}

async function showAbout(bot, chatId, message){
  const text='ℹ️ <b>Sobre</b>\nEste bot automatiza vendas de eSIM com pagamento PIX e entrega instantânea.\nQualquer dúvida, fale com o suporte.';
  return editOrSend(bot, chatId, message, text, backKeyboard('home'));
}

module.exports = { mainCaption, mainKeyboard, showCategories, showProductsByCategory, showAbout, backKeyboard };
