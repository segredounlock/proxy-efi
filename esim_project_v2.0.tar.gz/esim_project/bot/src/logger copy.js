// logger.js (ESM)
const C = { reset:'\x1b[0m', dim:'\x1b[2m', g:'\x1b[32m', c:'\x1b[36m', y:'\x1b[33m', r:'\x1b[31m' };
const ts = ()=>{const d=new Date();const p=n=>String(n).padStart(2,'0');return `${p(d.getFullYear())}-${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}.${String(d.getMilliseconds()).padStart(3,'0')}`};
export default {
  banner(){ console.log('┌'+'─'.repeat(62)+'┐');console.log(`│  eSIM Bot (v1.14 pedidos)            ${C.dim}${ts()}${C.reset} │`);console.log(`│  ${C.c}node-telegram-bot-api loaded${C.reset}                         │`);console.log('└'+'─'.repeat(62)+'┘'); },
  ok(m){console.log(`${C.g}✔ ${ts()}${C.reset} ${m}`)}, info(m){console.log(`${C.c}ℹ ${ts()}${C.reset} ${m}`)}, warn(m){console.log(`${C.y}◆ ${ts()}${C.reset} ${m}`)}, err(m){console.error(`${C.r}✖ ${ts()}${C.reset} ${m}`)},
};
