const axios = require('axios');
const log = require('./logger');
const { backKeyboard } = require('./menu');

const API_BASE = process.env.API_BASE || 'https://esim.buscalotter.com/api';
const MXV_TOKEN = process.env.MXV_TOKEN || process.env.MXV_TOKEN_V2 || '';
const MXV_SECRET = process.env.MXV_SECRET || process.env.MXV_SECRET_V2 || '';
const MXV_ENDPOINT = process.env.MXV_ENDPOINT || 'https://mxvpay.com/api/qrcode-pix';
const CALLBACK_URL = process.env.CALLBACK_URL || (API_BASE.replace('/api','') + '/mxvpay/callback');

// estado simples em memória (pode trocar por Redis)
const pendingCPF = new Map();  // chatId -> { productId, messageId }
const polling = new Map();     // orderId -> timer

function askCPF(bot, chatId, productId){
  pendingCPF.set(chatId, { productId });
  return bot.sendMessage(chatId, '🧾 Informe seu CPF (somente números) para gerar o PIX:', {
    reply_markup: { force_reply: true, input_field_placeholder: 'Digite seu CPF (11 dígitos)' }
  });
}

function onlyDigits(s){ return (s || '').replace(/\D+/g,''); }
function isValidCPF(cpf){ return onlyDigits(cpf).length === 11; } // validação simples

async function createOrder(productId, chatId, coupon){
  const payload = { product_id: productId, chat_id: chatId };
  if (coupon) payload.coupon = coupon;
  const { data } = await axios.post(API_BASE + '/orders_create.php', payload, { timeout: 12000, headers:{ 'Content-Type':'application/json' } });
  if (!data || !data.ok) throw new Error(data && data.message || 'Falha ao criar pedido');
  return data; // { ok:true, order_id, amount_cents, product_name, price_cents, ... }
}

async function createPix(amount_cents, cpf){
  const payload = {
    token: MXV_TOKEN,
    secret: MXV_SECRET,
    amount: String(Math.round(amount_cents/100)),
    cpf: onlyDigits(cpf),
    url_callback: CALLBACK_URL,
    paymentType: 'pix'
  };
  const { data } = await axios.post(MXV_ENDPOINT, payload, { timeout: 20000, headers:{ 'Content-Type':'application/json' } });
  if (!data || data.status !== true) throw new Error((data && data.message) || 'Falha ao gerar QRCode');
  return data; // { status:true, idTransaction, qr_code_image_url, qrcode }
}

async function pollStatus(bot, chatId, orderId, message){
  let attempts = 0;
  const maxAttempts = 60; // ~5 min (5s * 60)
  const tick = async () => {
    attempts++;
    try{
      const { data } = await axios.get(API_BASE + '/order_status.php', { params: { order_id: orderId }, timeout: 10000 });
      if (data && data.ok){
        if (data.status === 'paid' || data.status === 'delivered' || data.delivered){
          clearInterval(polling.get(orderId)); polling.delete(orderId);
          // Enviar mídia (QR/ESIM) ao usuário
          const media = data.media_url || data.qr_url || data.qr_path;
          const caption = data.message || '✅ Pagamento confirmado! Segue sua eSIM:';
          if (media && /(\.png|\.jpg|\.jpeg|\.webp|\/)/i.test(media)){
            try{
              await bot.sendPhoto(chatId, media, { caption });
            }catch{ await bot.sendMessage(chatId, caption + (media ? ('\n' + media) : '')); }
          } else {
            await bot.sendMessage(chatId, caption);
          }
          return;
        }
      }
    }catch(e){
      log.err('poll error: ' + e.message);
    }
    if (attempts >= maxAttempts){
      clearInterval(polling.get(orderId)); polling.delete(orderId);
      try{ await bot.sendMessage(chatId, '⏱️ Tempo esgotado aguardando confirmação do pagamento. Se já pagou, aguarde mais alguns minutos ou fale com o suporte.'); }catch{}
    }
  };
  const timer = setInterval(tick, 5000);
  polling.set(orderId, timer);
  tick(); // primeira chamada imediata
}

async function startBuy(bot, chatId, message, productId){
  // pedir CPF primeiro
  return askCPF(bot, chatId, productId);
}

async function onTextReply(bot, msg){
  const chatId = msg.chat.id;
  const pend = pendingCPF.get(chatId);
  if (!pend) return false; // não é reply esperado

  const cpf = onlyDigits(msg.text || '');
  if (!isValidCPF(cpf)){
    await bot.sendMessage(chatId, 'CPF inválido. Envie novamente (apenas números, 11 dígitos).');
    return true;
  }
  pendingCPF.delete(chatId);

  try{
    // 1) cria pedido no painel
    const order = await createOrder(pend.productId, chatId);
    // 2) gera pix na MXV
    const pix = await createPix(order.amount_cents || order.price_cents || 500, cpf);

    const kb = {
      reply_markup: { inline_keyboard: [
        [{ text:'✅ Já paguei (verificar)', callback_data:'chk:'+order.order_id }],
        [{ text:'↩️ Voltar', callback_data:'home' }]
      ]}
    };

    const caption = '🧾 <b>Pedido #'+order.order_id+'</b>\n'
      + 'Produto: '+(order.product_name || ('ID '+pend.productId))+'\n'
      + 'Valor: R$ '+((order.amount_cents||order.price_cents)/100).toLocaleString('pt-BR',{minimumFractionDigits:2})+'\n'
      + '\nEscaneie o QR abaixo ou use "PIX Copia e Cola":\n<code>'+pix.qrcode+'</code>';

    // envia a imagem do QR (url do provedor) + botões
    try {
      await bot.sendPhoto(chatId, pix.qr_code_image_url, { caption, parse_mode:'HTML', ...kb });
    } catch {
      await bot.sendMessage(chatId, caption + '\n' + pix.qr_code_image_url, { parse_mode:'HTML', ...kb });
    }

    // começar polling do status
    await pollStatus(bot, chatId, order.order_id);
  }catch(e){
    log.err('buy flow error: ' + e.message);
    await bot.sendMessage(chatId, '❌ Falha ao iniciar a compra: ' + e.message, backKeyboard('home'));
  }
  return true;
}

async function onCallback(bot, q){
  const chatId = q.message.chat.id;
  const data = q.data || '';
  if (data.startsWith('buy:')){
    const productId = parseInt(data.split(':')[1],10);
    await startBuy(bot, chatId, q.message, productId);
    return true;
  }
  if (data.startsWith('chk:')){
    const orderId = data.split(':')[1];
    await bot.answerCallbackQuery(q.id, { text:'Verificando pagamento...' });
    await pollStatus(bot, chatId, orderId, q.message);
    return true;
  }
  return false;
}

module.exports = { onCallback, onTextReply, startBuy };
