import axios from 'axios';
import { log } from './logger.js';

const ENDPOINT = process.env.MXVPAY_ENDPOINT;
const TOKEN = process.env.MXVPAY_TOKEN;
const SECRET = process.env.MXVPAY_SECRET;
const PAYER_CPF = process.env.PAYER_CPF || '00000000000';

export async function gerarPix(amountBRL, callbackUrl){
  const body = {
    token: TOKEN,
    secret: SECRET,
    amount: String(Math.round(amountBRL)),
    cpf: PAYER_CPF,
    url_callback: callbackUrl,
    paymentType: 'pix'
  };
  const r = await axios.post(ENDPOINT, body, { timeout: 20000 });
  if (!r.data || r.data.status !== true) {
    const msg = r.data?.message || 'Falha ao gerar PIX';
    throw new Error(msg);
  }
  return r.data; // {status:true,idTransaction,qr_code_image_url,qrcode}
}
