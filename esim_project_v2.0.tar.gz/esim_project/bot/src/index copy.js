// src/index.js — bot com fluxo: Operadoras -> Estoque (paginado) -> PIX -> Entrega automática
import 'dotenv/config';
import TelegramBot from 'node-telegram-bot-api';
import axios from 'axios';
import QRCode from 'qrcode';
import log from './logger.js';
import {
  getProdutos,
  createOrder,
  orderStatusById,
  listOrdersByChat,
  listOrdersByChatPaged as listOrdersByChatPagedMaybe,
  listStockByProduct
} from './api.js';

const BOT_TOKEN   = process.env.BOT_TOKEN;
const API_BASE    = process.env.API_BASE || 'https://esim.buscalotter.com/api';
const BRAND       = process.env.STORE_TITLE || 'Sua Loja eSIM';
const BRAND_URL   = process.env.BRAND_URL || 'https://segredounlock.com';
const HEADER      = process.env.HEADER_IMAGE_URL || 'https://i.imgur.com/mdSl4NU.png';
const SUPPORT_URL = process.env.SUPPORT_URL || 'https://t.me/segredounlocker';
const OPS         = (process.env.OPERADORAS || '').split(';').map(s=>s.trim()).filter(Boolean);

const ORDER_COOLDOWN_MS = 2 * 60 * 1000;

if (!BOT_TOKEN) {
  console.error('Falta BOT_TOKEN no .env');
  process.exit(1);
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });
log.ok?.('Bot conectado (polling habilitado)');
log.info?.(`API_BASE: ${API_BASE}`);

/* ========= Estado ========= */
const state = new Map();

/* ========= Utils ========= */
const sleep = (ms)=>new Promise(r=>setTimeout(r,ms));
const esc = s => String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

async function fetchImageBuffer(url){
  const r = await axios.get(url, { responseType:'arraybuffer', timeout: 20000 });
  if (r.status !== 200) throw new Error(`HTTP ${r.status}`);
  return Buffer.from(r.data);
}
async function generatePixPng(payload){
  return QRCode.toBuffer(String(payload||''), {
    type: 'png',
    errorCorrectionLevel: 'M',
    margin: 3,
    scale: 8,
    color: { dark:'#000000', light:'#00000000' }
  });
}

/* ========= Reação 🎉 automática ========= */
async function reactConfetti(chatId, messageId){
  try {
    await axios.post(`https://api.telegram.org/bot${BOT_TOKEN}/setMessageReaction`, {
      chat_id: chatId,
      message_id: messageId,
      reaction: [{ type: 'emoji', emoji: '🎉' }],
      is_big: true
    }, { timeout: 10000 });
  } catch (e) {
    log.err?.('reactConfetti: ' + (e?.response?.data?.description || e.message));
  }
}

/* ========= Tradução de status ========= */
const statusPt = s =>
  s === 'delivered' ? 'ENTREGUE' :
  s === 'paid'      ? 'PAGO'     :
  s === 'pending'   ? 'PENDENTE' :
  String(s || '').toUpperCase();

/* ========= Rate limit (anti-spam de criação de pedido) ========= */
function canCreateOrderNow(chatId){
  const st = state.get(chatId) || {};
  const last = st.lastPurchaseAt || 0;
  const now  = Date.now();
  const diff = now - last;
  if (diff >= ORDER_COOLDOWN_MS) return { ok: true, waitMs: 0 };
  return { ok: false, waitMs: ORDER_COOLDOWN_MS - diff };
}

/* ========= Teclados ========= */
function mainKeyboard(){
  return {
    inline_keyboard: [
      [{ text:'🛒 Comprar eSIM', callback_data:'BUY' }],
      [{ text:'📦 Meus Pedidos', callback_data:'ORDERS' }],
      [{ text:'🌐 Visitar loja', url: BRAND_URL }, { text:'ℹ️ Sobre', callback_data:'ABOUT' }],
      [{ text:'🧑‍💻 Suporte', url: SUPPORT_URL }],
    ]
  };
}

/* ========= Captions ========= */
function captionHome(chatId){
  const st = state.get(chatId) || {};
  const username = st.username ? '@'+st.username : '(sem username)';
  const opsText = OPS.length
    ? OPS.map(x=>'• '+esc(x)).join('\\n')
    : '• Claro — Cobertura nacional\\n• TIM — 4G/5G de alta velocidade\\n• Vivo — Melhor custo-benefício';
  // note: aqui usamos '\n' dentro da string final (Telegram interpreta OK)
  return [
    `🚀 <b>Bem-vindo(a),</b> <a href="${esc(BRAND_URL)}">${esc(BRAND)}</a>!`,
    '',
    `🆔 <b>ID do usuário:</b> <code>${esc(chatId)}</code>`,
    '',
    '💳 <b>Pagamento:</b> PIX',
    '⚡ <b>Entrega:</b> Automática',
    '',
    'Escolha uma opção abaixo para começar:'
  ].join('\n');
}

function pixCaption({orderId, txid, brcode, amountBRL}){
  const qrline = brcode ? `\n<code>${esc(brcode)}</code>\n` : '';
  const parts = [
    '🧾 <b>PIX Gerado</b>',
    `<b>Pedido:</b> #${esc(orderId)} — <b>Valor:</b> R$ ${esc(amountBRL)}`,
    txid ? `<b>TXID:</b> <code>${esc(txid)}</code>` : null,
    qrline,
    '⏱️ <b>Prazo:</b> você tem <b>até 10 minutos</b> para pagar.',
    '🔔 Após o pagamento, o eSIM será enviado automaticamente aqui.',
    'Se o prazo expirar, use <b>Voltar aos produtos</b> e gere um novo PIX.'
  ];
  return parts.filter(Boolean).join('\n');
}

function orderCaptionWithCode(orderId, status, codeText){
  const codeLine = codeText ? `🔢 Número: <code>${esc(codeText)}</code>\n` : '';
  return (
    `📦 Pedido <code>#${esc(orderId)}</code>\n` +
    codeLine +
    `📌 Status: <code>✅${statusPt(status)}✅</code>`
  );
}

/* ========= Envio robusto ========= */
async function sendPhotoSafe(chatId, photoBuffer, options = {}){
  try {
    return await bot.sendPhoto(chatId, { filename: 'image.png', content: photoBuffer }, options);
  } catch (e1) {
    try {
      return await bot.sendPhoto(chatId, { source: photoBuffer, filename: 'image.png' }, options);
    } catch (e2) {
      try {
        return await bot.sendPhoto(chatId, photoBuffer, options);
      } catch (e3) {
        log.err?.('sendPhotoSafe falhou: ' + (e1?.message||e1) + ' | ' + (e2?.message||e2) + ' | ' + (e3?.message||e3));
        throw e3;
      }
    }
  }
}

/* ========= Único balão ========= */
async function ensurePhotoMessage(chatId){
  const st = state.get(chatId) || {};
  if (st.msgId) return st.msgId;

  if (st.creating) {
    for (let i=0;i<20;i++){ await sleep(50); const m=state.get(chatId)?.msgId; if (m) return m; }
  }
  state.set(chatId, {...st, creating:true});

  try {
    const sent = await bot.sendPhoto(chatId, HEADER, {
      caption: captionHome(chatId),
      parse_mode:'HTML',
      reply_markup: mainKeyboard()
    });
    state.set(chatId, { ...(state.get(chatId)||{}), msgId: sent.message_id, creating:false });
    return sent.message_id;
  } catch (e) {
    state.set(chatId, { ...(state.get(chatId)||{}), creating:false });
    throw e;
  }
}

async function editCaption(chatId, messageId, caption, reply_markup){
  try {
    await bot.editMessageCaption(caption, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode:'HTML',
      reply_markup
    });
  } catch (e) {
    const body = e?.response?.body || e?.message || '';
    if (typeof body === 'string' && /message is not modified/i.test(body)) {
      return;
    }
    try { await bot.deleteMessage(chatId, messageId); } catch {}
    const sent = await bot.sendPhoto(chatId, HEADER, { caption, parse_mode:'HTML', reply_markup });
    state.set(chatId, { ...(state.get(chatId)||{}), msgId: sent.message_id });
  }
}

async function replaceWithBufferPhoto(chatId, messageId, imageBuffer, caption, reply_markup){
  try { await bot.deleteMessage(chatId, messageId); } catch {}
  const sent = await sendPhotoSafe(chatId, imageBuffer, { caption, parse_mode:'HTML', reply_markup });
  state.set(chatId, { ...(state.get(chatId)||{}), msgId: sent.message_id });
  return sent;
}

/* ========= Helpers para produto ========= */
async function getProductById(pid){
  try {
    const data = await getProdutos();
    const list = Array.isArray(data.products) ? data.products : [];
    const found = list.find(p => Number(p.id) === Number(pid));
    if (found) return found;
  } catch (e) {
    log.err?.('getProductById: ' + e.message);
  }
  return null;
}

function truncateText(s, max=120){
  if (!s) return '';
  const t = String(s).trim();
  if (t.length <= max) return t;
  return t.slice(0, max-1).trim() + '…';
}

/* ========= Views ========= */
async function showHome(chatId){
  const msgId = await ensurePhotoMessage(chatId);
  await editCaption(chatId, msgId, captionHome(chatId), mainKeyboard());
  const st = state.get(chatId)||{};
  state.set(chatId, { ...st, ordersPage: 1, ordersTotalPages: 1 });
}

function operatorsKeyboard(products){
  const rows = [];
  for (const p of products) {
    rows.push([{ text: `📦 ${p.name}`, callback_data: `OP_${p.id}_1` }]);
  }
  rows.push([{ text:'🏠 Menu principal', callback_data:'HOME' }]);
  return { inline_keyboard: rows };
}

async function showOperators(chatId){
  const data = await getProdutos();
  const prods = Array.isArray(data.products) ? data.products : [];
  const msgId = await ensurePhotoMessage(chatId);
  await editCaption(chatId, msgId, '<b>Escolha a operadora:</b>', operatorsKeyboard(prods));
}

function stockKeyboard(pid, data){
  const rows = [];
  const esims = data.esims || [];
  for (const e of esims) {
    const codeText = e.code_text || e.note || '';
    const ddd = (codeText || '').slice(0,2);
    rows.push([{ text:`#${e.id} — DDD ${ddd||'??'}`, callback_data:`BUY_ESIM_${pid}_${e.id}` }]);
  }
  const nav = [];
  nav.push({ text:'🧭 Operadoras', callback_data:'BUY' });
  nav.push({ text:'◀️', callback_data:`OP_${pid}_${Math.max(1, (data.page||1)-1)}` });
  nav.push({ text:`📄 ${data.page||1}/${data.total_pages||1}`, callback_data:'NOP' });
  nav.push({ text:'▶️', callback_data:`OP_${pid}_${Math.min(data.total_pages||1, (data.page||1)+1)}` });
  rows.push(nav);
  rows.push([{ text:'🏠 Menu principal', callback_data:'HOME' }]);
  return { inline_keyboard: rows };
}

async function showStock(chatId, productId, page=1){
  const perPage = 5;
  const data = await listStockByProduct(productId, page, perPage).catch(()=>null);
  const msgId = await ensurePhotoMessage(chatId);

  if (!data || !data.esims || data.esims.length === 0) {
    await editCaption(chatId, msgId, 'Sem estoque livre para esta operadora no momento.', {
      inline_keyboard: [
        [{ text:'🧭 Operadoras', callback_data:'BUY' }],
        [{ text:'🏠 Menu principal', callback_data:'HOME' }],
      ]
    });
    return;
  }

  let prodName = '';
  let prodDescRaw = '';

  if (data.product && typeof data.product === 'object') {
    prodName = data.product.name || '';
    prodDescRaw = data.product.description || data.product.desc || '';
  }
  if (!prodName) {
    const prod = await getProductById(productId).catch(()=>null);
    if (prod) {
      prodName = prod.name || '';
      prodDescRaw = prod.description || prod.desc || prod.note || '';
    }
  }

  const prodNameLine = prodName ? `\nOperadora: <b>${esc(prodName)}</b>` : '';
  const descText = prodDescRaw ? truncateText(String(prodDescRaw).replace(/\s+/g,' '), 160) : '';
  const prodDescLine = descText ? `\n<i>${esc(descText)}</i>` : '';

  const cap = `✨ <b>Estoque disponível</b>\nProduto ID: ${productId}${prodNameLine}${prodDescLine}`;
  await editCaption(chatId, msgId, cap, stockKeyboard(productId, data));

  const st = state.get(chatId)||{};
  state.set(chatId, { ...st, stockPageByProduct: { ...(st.stockPageByProduct||{}), [productId]: data.page }});
}

async function showOrders(chatId, page = 1){
  try {
    const perPage = 5;

    let data;
    if (typeof listOrdersByChatPagedMaybe === 'function') {
      try {
        data = await listOrdersByChatPagedMaybe(chatId, page, perPage);
      } catch { data = null; }
    }
    if (!data) {
      const all = await listOrdersByChat(chatId);
      const total = Array.isArray(all) ? all.length : 0;
      const total_pages = Math.max(1, Math.ceil(total / perPage));
      const start = (page-1)*perPage;
      const orders = Array.isArray(all) ? all.slice(start, start+perPage) : [];
      data = { ok:true, page, per_page: perPage, total_pages, orders };
    }

    const msgId = await ensurePhotoMessage(chatId);
    if (!data || !data.orders || !data.orders.length) {
      await editCaption(chatId, msgId, 'Você ainda não possui pedidos.', {
        inline_keyboard:[[{ text:'⬅️ Voltar', callback_data:'HOME'}]]
      });
      const st = state.get(chatId)||{};
      state.set(chatId, { ...st, ordersPage: 1, ordersTotalPages: 1 });
      return;
    }

    const rows = data.orders.map(o=>[{
      text: `#${o.id} — ${o.product_name||'Produto'} — R$ ${((o.final_price_cents??o.price_cents??0)/100).toFixed(2)} — ${statusPt(o.status)}`,
      callback_data: `O_${o.id}`
    }]);

    const nav = [];
    nav.push({ text:'⬅️ Voltar', callback_data:'HOME' });
    nav.push({ text:'◀️', callback_data: `ORDERS_PAGE_${Math.max(1, data.page - 1)}` });
    nav.push({ text:`📄 ${data.page}/${data.total_pages}`, callback_data:'ORDERS_NOP' });
    nav.push({ text:'▶️', callback_data: `ORDERS_PAGE_${Math.min(data.total_pages, data.page + 1)}` });

    await editCaption(chatId, msgId, '<b>Meus pedidos:</b>', { inline_keyboard: [...rows, nav] });

    const st = state.get(chatId)||{};
    state.set(chatId, { ...st, ordersPage: data.page, ordersTotalPages: data.total_pages });
  } catch (e) {
    log.err?.('showOrders: '+(e?.message||e));
    const msgId = await ensurePhotoMessage(chatId);
    await editCaption(chatId, msgId, '⚠️ Não foi possível listar seus pedidos.', {
      inline_keyboard:[[{ text:'⬅️ Voltar', callback_data:'HOME'}]]
    });
  }
}

/* ========= Watcher pagamento ========= */
function startPaidWatcher(chatId, orderId, messageId){
  const old = state.get(chatId)?.pollTimer;
  if (old) clearInterval(old);

  const t0 = Date.now();
  const timer = setInterval(async ()=>{
    const os = await orderStatusById(orderId).catch(()=>null);
    if (os && (os.status==='paid' || os.status==='delivered')) {
      try {
        const current = state.get(chatId)?.msgId || messageId;
        if (current) await bot.deleteMessage(chatId, current);
      } catch {}

      if (os.media_url) {
        const caption = orderCaptionWithCode(orderId, 'delivered', os.code_text);
        try {
          const buf = await fetchImageBuffer(os.media_url).catch(()=>null);
          const sent = buf
            ? await sendPhotoSafe(chatId, buf, { caption, parse_mode:'HTML' })
            : await bot.sendPhoto(chatId, os.media_url, { caption, parse_mode:'HTML' });
          if (sent?.message_id) reactConfetti(chatId, sent.message_id);
        } catch (e) {
          log.err?.('entrega: '+(e?.message||e));
        }
      }

      await showOperators(chatId); // volta para operadoras

      clearInterval(timer);
      state.set(chatId, { ...(state.get(chatId)||{}), pollTimer:null });
      return;
    }
    if (Date.now() - t0 > 10*60*1000) {
      clearInterval(timer);
      state.set(chatId, { ...(state.get(chatId)||{}), pollTimer:null });
    }
  }, 7000);

  state.set(chatId, { ...(state.get(chatId)||{}), pollTimer: timer });
}

/* ========= Fluxo compra ========= */
async function iniciarCompra(chatId, productId, esimId){
  try {
    const res = await createOrder(productId, chatId, state.get(chatId)?.coupon || undefined, esimId);
    const orderId = res.order_id;
    const txid = res.mxv_txid || null;
    state.set(chatId, { ...(state.get(chatId)||{}), orderId, txid, lastPurchaseAt: Date.now() });

    let cents = 0;
    if (typeof res.final_price_cents === 'number') cents = res.final_price_cents;
    else if (typeof res.price_cents === 'number') cents = res.price_cents;
    else if (res.amount) cents = Math.round(Number(String(res.amount).replace(',','.'))*100);
    const amountBRL = (cents/100).toFixed(2);

    const kb = { inline_keyboard: [[{ text:'⬅️ Voltar às operadoras', callback_data:'BUY' }]] };
    const msgId = await ensurePhotoMessage(chatId);

    let qrBuf = null;
    if (res.qrcode) qrBuf = await generatePixPng(res.qrcode).catch(()=>null);
    else if (res.qr_code_image_url) qrBuf = await fetchImageBuffer(res.qr_code_image_url).catch(()=>null);

    const cap = pixCaption({ orderId, txid, brcode: res.qrcode, amountBRL });

    if (qrBuf) {
      await replaceWithBufferPhoto(chatId, msgId, qrBuf, cap, kb);
    } else {
      await editCaption(chatId, msgId, cap, kb);
    }

    startPaidWatcher(chatId, orderId, state.get(chatId)?.msgId || msgId);
  } catch (e) {
    log.err?.('Falha ao criar pedido: '+(e?.message||e));
    const msgId = await ensurePhotoMessage(chatId);
    await editCaption(chatId, msgId, '⚠️ Não foi possível criar o pedido.', mainKeyboard());
  }
}

/* ========= Handlers ========= */
bot.onText(/^\/start$/, async (msg)=>{
  const chatId = msg.chat.id;
  const now = Date.now();
  const st = state.get(chatId) || {};
  if (st.lastStartAt && (now - st.lastStartAt) < 1000) return;
  state.set(chatId, { ...st, lastStartAt: now, username: msg.from?.username || null, ordersPage: 1, ordersTotalPages: 1 });

  await showHome(chatId);
});

bot.on('callback_query', async (q)=>{
  const chatId = q.message.chat.id;
  const data = q.data || '';
  try {
    if (data === 'HOME')   { await showHome(chatId);    return bot.answerCallbackQuery(q.id); }
    if (data === 'BUY')    { await showOperators(chatId);return bot.answerCallbackQuery(q.id); }
    if (data === 'ABOUT')  {
      const msgId = await ensurePhotoMessage(chatId);
      await editCaption(chatId, msgId, `<b>${esc(BRAND)}</b>\nWebsite: ${esc(BRAND_URL)}`, mainKeyboard());
      return bot.answerCallbackQuery(q.id);
    }
    if (data === 'ORDERS') {
      const p = (state.get(chatId)||{}).ordersPage || 1;
      await showOrders(chatId, p);
      return bot.answerCallbackQuery(q.id);
    }
    if (data.startsWith('ORDERS_PAGE_')){
      const p = parseInt(data.split('_').pop(), 10) || 1;
      await showOrders(chatId, p);
      const st = state.get(chatId)||{}; state.set(chatId, { ...st, ordersPage: p });
      return bot.answerCallbackQuery(q.id);
    }
    if (data.startsWith('OP_')) {
      const parts = data.split('_');
      const pid = parseInt(parts[1],10);
      const page = parseInt(parts[2]||'1',10);
      await showStock(chatId, pid, page);
      return bot.answerCallbackQuery(q.id);
    }
    if (data.startsWith('BUY_ESIM_')) {
      const parts = data.split('_');
      const pid = parseInt(parts[2],10);
      const eid = parseInt(parts[3],10);
      const gate = canCreateOrderNow(chatId);
      if (!gate.ok) {
        const secs = Math.ceil(gate.waitMs / 1000);
        await bot.answerCallbackQuery(q.id, { text: `Aguarde ${secs}s para gerar um novo PIX.`, show_alert: true });
        return;
      }
      await iniciarCompra(chatId, pid, eid);
      return bot.answerCallbackQuery(q.id);
    }
    if (data.startsWith('O_')) {
      const oid = parseInt(data.split('_')[1],10);
      const os = await orderStatusById(oid).catch(()=>null);
      if (os && (os.status==='paid'||os.status==='delivered') && os.media_url) {
        const caption = orderCaptionWithCode(oid, os.status, os.code_text);
        try {
          const buf = await fetchImageBuffer(os.media_url).catch(()=>null);
          const sent = buf
            ? await sendPhotoSafe(chatId, buf, { caption, parse_mode:'HTML' })
            : await bot.sendPhoto(chatId, os.media_url, { caption, parse_mode:'HTML' });
          if (sent?.message_id) reactConfetti(chatId, sent.message_id);
        } catch (e) {
          await bot.sendMessage(chatId, caption, { parse_mode:'HTML' });
        }
      } else {
        const caption = orderCaptionWithCode(oid, os?.status, os?.code_text);
        await bot.sendMessage(chatId, caption, { parse_mode:'HTML' });
      }
      return bot.answerCallbackQuery(q.id);
    }
    if (data === 'CHECKPAY') {
      return bot.answerCallbackQuery(q.id, { text:'Pagamento agora é automático. ✅' });
    }
    return bot.answerCallbackQuery(q.id);
  } catch (e) {
    log.err?.('callback error: '+(e?.message||e));
    try { await bot.answerCallbackQuery(q.id, { text:'Erro' }); } catch {}
  }
});

process.on('unhandledRejection', console.error);
process.on('uncaughtException', console.error);
