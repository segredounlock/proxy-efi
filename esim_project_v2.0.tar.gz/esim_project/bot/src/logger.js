// src/logger.js — logger simples com cores e timestamps

const C = {
  reset: '\x1b[0m',
  dim: '\x1b[2m',
  bold: '\x1b[1m',
  fg: {
    gray:  '\x1b[90m',
    blue:  '\x1b[34m',
    cyan:  '\x1b[36m',
    green: '\x1b[32m',
    yellow:'\x1b[33m',
    red:   '\x1b[31m',
    mag:   '\x1b[35m',
    white: '\x1b[37m'
  }
};

function ts() {
  const d = new Date();
  const pad = (n)=> String(n).padStart(2,'0');
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${String(d.getMilliseconds()).padStart(3,'0')}`;
}

function line(prefixColor, icon, msg) {
  console.log(
    `${C.fg.gray}${ts()}${C.reset} ${prefixColor}${icon}${C.reset} ${msg}`
  );
}

export default {
  ok:   (msg)=> line(C.fg.green, '✔', msg),
  info: (msg)=> line(C.fg.cyan,  'ℹ', msg),
  warn: (msg)=> line(C.fg.yellow,'⚠', msg),
  err:  (msg)=> line(C.fg.red,   '✖', msg),

  // extras “bonitos”
  banner(title, kv = {}) {
    const top = '─'.repeat(48);
    console.log(`${C.fg.mag}${'╭'}${top}${'╮'}${C.reset}`);
    console.log(`${C.fg.mag}│${C.reset} ${C.bold}${title}${C.reset}`);
    Object.entries(kv).forEach(([k,v])=>{
      console.log(`${C.fg.mag}│${C.reset} ${C.fg.gray}${k}:${C.reset} ${v}`);
    });
    console.log(`${C.fg.mag}${'╰'}${top}${'╯'}${C.reset}`);
  },

  orderCreated({userId, orderId, productId, priceCents}) {
    const reais = (priceCents/100).toFixed(2);
    this.banner('🧾 PEDIDO NOVO', {
      'user': C.fg.cyan + userId + C.reset,
      'order': C.fg.green + orderId + C.reset,
      'product': productId,
      'valor': C.fg.green + `R$ ${reais}` + C.reset
    });
  },

  orderPaid({orderId, status}) {
    this.banner('✅ PAGAMENTO CONFIRMADO', {
      'order': C.fg.green + orderId + C.reset,
      'status': C.fg.green + status.toUpperCase() + C.reset
    });
  },

  delivered({orderId, code}) {
    this.banner('📦 ENTREGUE', {
      'order': C.fg.green + orderId + C.reset,
      'code':  C.fg.cyan + (code || '-') + C.reset
    });
  },
};
