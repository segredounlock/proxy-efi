const axios = require('axios');
require('dotenv').config();
const { MXV_API_BASE='https://mxvpay.com', MXV_QR_ENDPOINT='/api/qrcode-pix', MXV_TOKEN, MXV_SECRET, PIX_DEFAULT_CPF='00000000191' } = process.env;

async function createCharge(amount, callbackUrl, cpf){
  const url = MXV_API_BASE.replace(/\/$/,'') + MXV_QR_ENDPOINT;
  const body = { token:MXV_TOKEN, secret:MXV_SECRET, amount:String(amount), cpf:(cpf||PIX_DEFAULT_CPF).replace(/\D/g,''), url_callback:callbackUrl, paymentType:'pix' };
  const { data } = await axios.post(url, body, { timeout:20000 });
  if (!data.status) throw new Error(data.message || 'MXV createCharge failed');
  return { idTransaction:String(data.idTransaction), qrcode:data.qrcode, qr_code_image_url:data.qr_code_image_url };
}
module.exports = { createCharge };
