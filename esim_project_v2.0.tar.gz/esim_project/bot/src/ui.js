export function kbHome(){
  const brand = process.env.BRAND_URL;
  const supportUrl = process.env.SUPPORT_URL;
  const supportUser = process.env.SUPPORT_USERNAME || 'support';

  const row1 = [{ text: '🛒 Comprar eSIM', callback_data: 'HOME_COMPRAR' }];
  const row2 = [{ text: '📦 Meus Pedidos', callback_data: 'HOME_PEDIDOS' }];

  const row3 = [];
  if (brand) row3.push({ text: '🌐 Visitar loja', url: brand });
  row3.push({ text: 'ℹ️ Sobre', callback_data: 'HOME_SOBRE' });

  const row4 = [
    supportUrl
      ? { text: '🧑‍💻 Suporte', url: supportUrl }
      : { text: '🧑‍💻 Suporte', url: 'https://t.me/' + supportUser }
  ];

  return {
    reply_markup: {
      inline_keyboard: [row1, row2, row3, row4]
    }
  };
}


export function kbProdutos(produtos){
  const rows = produtos.map(p => ([{
    text: `${p.name} · R$ ${(p.price_cents/100).toFixed(2).replace('.',',')}`,
    callback_data: 'PRD_' + p.id
  }]));
  rows.push([{ text: '⬅️ Voltar', callback_data: 'BACK_HOME' }]);
  return { reply_markup: { inline_keyboard: rows } };
}

export function kbPagamento(orderId){
  return {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'PIX ⚡', callback_data: 'PAY_PIX_' + orderId }],
        [{ text: '⬅️ Voltar', callback_data: 'BACK_PRODUTOS' }]
      ]
    }
  };
}

export function kbAguardar(orderId){
  return {
    reply_markup: {
      inline_keyboard: [
        [{ text: '🔄 Verificar pagamento', callback_data: 'CHK_' + orderId }],
        [{ text: '⬅️ Voltar ao início', callback_data: 'BACK_HOME' }]
      ]
    }
  };
}
