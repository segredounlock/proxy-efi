# 🌐 Sistema eSIM Completo

Sistema completo de venda de eSIM via Telegram com pagamento PIX

## 📋 Visão Geral

- **Bot Telegram** (Node.js) - Interface de vendas
- **Backend PHP** - API + Painel Admin
- **MySQL** - Banco de dados
- **MXVPay** - Gateway PIX
- **Auto-entrega** - eSIM enviado automaticamente

---

## 🚀 Início Rápido

### 1️⃣ Banco de Dados
```bash
mysql -u root -p < database/esim.sql
```

### 2️⃣ Backend PHP
```bash
cd backend
# Configurar config.php com suas credenciais
```

### 3️⃣ Bot Telegram
```bash
cd bot
npm install
npm start
```

---

## 📁 Estrutura

```
esim_project/
├── bot/                # Bot Telegram (Node.js)
│   ├── src/           # Código fonte
│   ├── .env           # Configurações
│   └── package.json
├── backend/           # API + Admin (PHP)
│   ├── admin/         # Painel administrativo
│   ├── api/           # Endpoints API
│   ├── mxvpay/        # Callback PIX
│   └── config.php     # Configurações
├── database/          # Schema MySQL
│   └── esim.sql
├── docs/              # Documentação
└── scripts/           # Utilitários
```

---

## ⚙️ Configuração

### Bot (.env)
```env
BOT_TOKEN=seu_token_aqui
API_BASE=https://seu-dominio.com/api
MXVPAY_TOKEN=seu_token_mxvpay
```

### Backend (config.php)
```php
DB_HOST=localhost
DB_NAME=u740956130_esim
DB_USER=seu_usuario
DB_PASS=sua_senha
```

---

## 🔧 Funcionalidades

### ✅ Bot Telegram
- Menu de operadoras
- Visualização de estoque
- Compra via PIX
- QR Code automático
- Entrega instantânea

### ✅ Painel Admin
- Gestão de eSIM
- Controle de estoque
- Visualização de pedidos
- Gestão de cupons
- Sistema de notificações

### ✅ API
- Criação de pedidos
- Consulta de estoque
- Webhook MXVPay
- Track de usuários

---

## 📊 Banco de Dados

### Tabelas principais:
- `users` - Usuários do bot
- `products` - Produtos (operadoras)
- `esims` - Estoque de eSIM
- `orders` - Pedidos
- `coupons` - Cupons de desconto

---

## 🔐 Segurança

- Senhas hasheadas
- Tokens protegidos
- Validação de entrada
- Rate limiting
- Logs auditáveis

---

## 📱 Admin

**URL:** `/admin`  
**User:** admin  
**Pass:** @Segredo1994

---

## 🎯 Próximos Passos

1. ✅ Projeto organizado
2. ⏳ Melhorias de código
3. ⏳ Documentação completa
4. ⏳ Testes automatizados
5. ⏳ Docker setup

---

**Versão:** 2.0  
**Data:** 2025-11-23
