<?php
// callback_diag.php — teste rápido na raiz: /mxvpay/callback_diag.php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
$dir = __DIR__ . '/../logs'; if (!is_dir($dir)) @mkdir($dir, 0777, true);
$raw = file_get_contents('php://input');
@file_put_contents($dir.'/mxvpay_callback_raw.log', date('Y-m-d H:i:s ').'RAW='.$raw.PHP_EOL, FILE_APPEND);
http_response_code(200);
echo json_encode(['ok'=>true,'diag'=>true,'len'=>strlen((string)$raw)]);
