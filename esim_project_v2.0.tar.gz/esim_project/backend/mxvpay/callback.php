<?php
// /mxvpay/callback.php — raiz do domínio
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors','0');

function cb_log(string $file, string $msg): void {
  $dir = __DIR__ . '/../logs';
  if (!is_dir($dir)) @mkdir($dir, 0777, true);
  @file_put_contents($dir.'/'.$file, date('Y-m-d H:i:s ').$msg.PHP_EOL, FILE_APPEND);
}

try { require_once __DIR__ . '/../config.php'; }
catch (Throwable $e) { cb_log('mxvpay_callback_error.log','FATAL include config: '.$e->getMessage()); http_response_code(200); echo '{"ok":false}'; exit; }

$secret_env = getenv('MXVPAY_CALLBACK_SECRET') ?: (defined('CALLBACK_SECRET') ? CALLBACK_SECRET : '');
if ($secret_env !== '') {
  $q = $_GET['s'] ?? $_GET['secret'] ?? '';
  if (!hash_equals($secret_env, (string)$q)) { cb_log('mxvpay_callback.log','Secret inválido'); http_response_code(200); echo '{"ok":false}'; exit; }
}

$raw = file_get_contents('php://input'); cb_log('mxvpay_callback_raw.log','RAW='.$raw);
$in  = json_decode($raw, true); if (!is_array($in)) $in = [];
$tx  = (string)($in['idTransaction'] ?? $in['txid'] ?? $in['id'] ?? '');
$st  = strtolower((string)($in['status'] ?? ''));
$ok  = in_array($st, ['paid','approved','confirmado','confirmed','success','sucesso','concluido'], true);

try {
  if (!empty($in['qr_code_image_url']) && $tx!=='') {
    $pdo = db();
    $stmt=$pdo->prepare("UPDATE orders SET media_url=:m, updated_at=NOW() WHERE mxv_txid=:tx AND (media_url IS NULL OR media_url='')");
    $stmt->execute([':m'=>$in['qr_code_image_url'], ':tx'=>$tx]);
  }
} catch (Throwable $e) { cb_log('mxvpay_callback_error.log','save media_url: '.$e->getMessage()); }

$result=['ok'=>false];
if ($ok && $tx!=='') {
  $base = rtrim((defined('BASE_URL')?BASE_URL:('https://'.($_SERVER['HTTP_HOST']??'localhost'))), '/');
  $url = $base . '/api/orders_confirm.php';
  $ch = curl_init($url);
  curl_setopt_array($ch,[
    CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true,
    CURLOPT_HTTPHEADER=>['Content-Type: application/json'],
    CURLOPT_POSTFIELDS=>json_encode(['txid'=>$tx]), CURLOPT_TIMEOUT=>20,
  ]);
  $res = curl_exec($ch); curl_close($ch);
  cb_log('mxvpay_callback.log',"CONFIRM TX={$tx} RES={$res}");
  $jr = json_decode((string)$res, true); if (is_array($jr)) $result=$jr;
} else { cb_log('mxvpay_callback.log',"IGNORED status='{$st}' tx='{$tx}'"); }

http_response_code(200);
echo json_encode(['ok'=> (bool)($result['ok']??false), 'txid'=>$tx, 'status'=>$st]);