<?php
/**
 * rescue_bootstrap.php
 * Coloque este arquivo na raiz do painel (ex.: /esim/rescue_bootstrap.php)
 * e acesse: https://seu-dominio/rescue_bootstrap.php?file=admin/index.php
 * Ele força exibição de erros e registra logs para diagnosticar o 500.
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('log_errors', '1');
$logDir = __DIR__ . '/logs';
if (!is_dir($logDir)) { @mkdir($logDir, 0775, true); }
ini_set('error_log', $logDir . '/rescue-php-' . date('Ymd') . '.log');

set_error_handler(function($severity, $message, $file, $line){
    echo "<pre>PHP ERROR [$severity] $message in $file:$line</pre>";
    return false;
});
set_exception_handler(function($e){
    echo "<pre>UNCAUGHT: " . $e->getMessage() . "\n" . $e->getTraceAsString() . "</pre>";
});

$target = isset($_GET['file']) ? $_GET['file'] : 'index.php';
$path = realpath(__DIR__ . '/' . $target);
if (!$path || !file_exists($path)) {
    http_response_code(404);
    echo "<h3>Arquivo alvo não encontrado:</h3><code>{$target}</code>";
    exit;
}

echo "<small>Rescue loader → {$target}</small><hr>";
require $path;
