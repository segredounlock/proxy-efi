<?php
declare(strict_types=1);

/**
 * Universal Healthcheck eSIM Admin
 * - Pode ficar em: /public_html/  OU  /public_html/esim/
 * - Não usa caminhos hard-coded com "/esim". Calcula prefixo automaticamente.
 */

@header('Content-Type: text/html; charset=utf-8');

// -------------- helpers --------------
function ok($b){ return $b ? 'OK ✅' : 'Falhou ❌'; }
function icon($b){ return $b ? '✅' : '❌'; }
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

function base_dir(): string {
  return rtrim(str_replace('\\','/', dirname(__FILE__)), '/');
}
function doc_root(): string {
  $root = $_SERVER['DOCUMENT_ROOT'] ?? base_dir();
  return rtrim(str_replace('\\','/', $root), '/');
}
function base_url(): string {
  $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? null) == 443);
  $scheme = $https ? 'https://' : 'http://';
  $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
  return $scheme . $host;
}
/** retorna "" ou "/esim" etc, dependendo de onde este arquivo está */
function this_web_prefix(): string {
  $doc = doc_root();
  $dir = base_dir();
  if (strpos($dir, $doc) === 0) {
    $rel = substr($dir, strlen($doc));
    return rtrim($rel, '/'); // "" ou "/esim"
  }
  return '';
}
function url_here(string $rel): string {
  $prefix = this_web_prefix();
  return rtrim(base_url() . $prefix, '/') . '/' . ltrim($rel, '/');
}
function has_ext(string $e): bool { return extension_loaded($e); }

function http_get_ok(string $url, int $timeout=8): bool {
  if (!function_exists('curl_init')) return false;
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_TIMEOUT => $timeout,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_HEADER => true,
    CURLOPT_NOBODY => false,
    CURLOPT_USERAGENT => 'eSIM-Healthcheck/1.0',
  ]);
  $resp = curl_exec($ch);
  $err  = curl_error($ch);
  $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  return !$err && $code >= 200 && $code < 400 && $resp !== false;
}
function can_write(string $path): bool {
  if (!is_dir($path)) return false;
  $tmp = rtrim($path, '/').'/.__wtest_'.uniqid().'.tmp';
  $ok = @file_put_contents($tmp, 'x') !== false;
  if ($ok) @unlink($tmp);
  return $ok;
}

function try_load_config(): bool {
  $cands = [
    base_dir().'/config.php',
    dirname(base_dir()).'/config.php',
    base_dir().'/esim/config.php',
  ];
  foreach ($cands as $c) {
    if (is_file($c)) { require_once $c; return true; }
  }
  return false;
}

// -------------- checks --------------
$phpVersion = PHP_VERSION;
$ext_pdo      = has_ext('pdo');
$ext_pdomysql = has_ext('pdo_mysql');
$ext_curl     = has_ext('curl');
$ext_json     = has_ext('json');
$ext_mbstring = has_ext('mbstring');
$ext_openssl  = has_ext('openssl');

$config_ok = try_load_config();
$db_ok = false; $pdo = null; $db_name = '';
if ($config_ok && function_exists('db')) {
  try {
    $pdo = db();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db_ok = true;
    $db_name = $pdo->query('select database() as db')->fetch(PDO::FETCH_ASSOC)['db'] ?? '';
  } catch (Throwable $e) {
    $db_ok = false;
  }
}

// tabelas/colunas
$tbl_products = $tbl_esims = $tbl_orders = false;
$col_products_category = $col_orders_notified = $col_orders_coupon = false;
$col_orders_discount_cents = $col_orders_final_price_cents = false;

if ($db_ok) {
  try { $tbl_products = (bool)$pdo->query("SHOW TABLES LIKE 'products'")->fetch(); } catch(Throwable $e){}
  try { $tbl_esims    = (bool)$pdo->query("SHOW TABLES LIKE 'esims'")->fetch(); } catch(Throwable $e){}
  try { $tbl_orders   = (bool)$pdo->query("SHOW TABLES LIKE 'orders'")->fetch(); } catch(Throwable $e){}

  $cols_products = []; $cols_orders = [];
  if ($tbl_products) { $cols_products = $pdo->query("SHOW COLUMNS FROM products")->fetchAll(PDO::FETCH_COLUMN); }
  if ($tbl_orders)   { $cols_orders   = $pdo->query("SHOW COLUMNS FROM orders")->fetchAll(PDO::FETCH_COLUMN); }

  $col_products_category       = in_array('category', $cols_products, true);
  $col_orders_notified         = in_array('notified', $cols_orders, true);
  $col_orders_coupon           = in_array('coupon_code', $cols_orders, true);
  $col_orders_discount_cents   = in_array('discount_cents', $cols_orders, true);
  $col_orders_final_price_cents= in_array('final_price_cents', $cols_orders, true);
}

// pastas/permissões: preferir paths relativos à pasta onde este arquivo está
$here = base_dir();
$uploads = $here.'/uploads/qr';
$logs    = $here.'/logs';
$dir_detected = $here;
$dir_uploads_ok = is_dir($uploads);
$write_uploads_ok = $dir_uploads_ok ? can_write($uploads) : false;
$dir_logs_ok = is_dir($logs) || @mkdir($logs, 0775, true);
$write_logs_ok = $dir_logs_ok ? can_write($logs) : false;

// endpoints
$base = rtrim(base_url().this_web_prefix(), '/');
$ok_products = http_get_ok($base.'/api/products.php');
$ok_create   = http_get_ok($base.'/api/orders_create.php');
$ok_status   = http_get_ok($base.'/api/order_status.php?txid=TESTE');
$ok_cb       = http_get_ok($base.'/mxvpay/callback.php');

// -------------- output --------------
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Healthcheck eSIM Admin</title>
  <style>
    body { font-family: system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,'Open Sans','Helvetica Neue',Arial,sans-serif; background:#0f1620; color:#e9eef6; }
    .wrap { max-width: 980px; margin: 24px auto; padding: 16px; background:#0b1220; border-radius:12px; box-shadow: 0 6px 22px rgba(0,0,0,.35); }
    h1 { margin:0 0 12px; font-size: 22px; }
    code { background:#1a2332; color:#cde3ff; padding:2px 6px; border-radius:6px; }
    ul { line-height: 1.7; }
    .ok { color:#30d158; } .bad { color:#ff453a; }
    .muted { color:#9bb0c9; font-size: 13px; }
    .box { background:#0e1726; padding:12px 16px; border-radius:10px; margin-top:12px; }
  </style>
</head>
<body>
  <div class="wrap">
    <h1>Healthcheck eSIM Admin</h1>
    <div class="muted">Diretório detectado: <code><?=h($dir_detected)?></code></div>
    <ul>
      <li>PHP: <b><?=h($phpVersion)?></b></li>
      <li>Extensão pdo: <b class="<?=$ext_pdo?'ok':'bad'?>"><?=ok($ext_pdo)?></b></li>
      <li>Extensão pdo_mysql: <b class="<?=$ext_pdomysql?'ok':'bad'?>"><?=ok($ext_pdomysql)?></b></li>
      <li>Extensão curl: <b class="<?=$ext_curl?'ok':'bad'?>"><?=ok($ext_curl)?></b></li>
      <li>Extensão json: <b class="<?=$ext_json?'ok':'bad'?>"><?=ok($ext_json)?></b></li>
      <li>Extensão mbstring: <b class="<?=$ext_mbstring?'ok':'bad'?>"><?=ok($ext_mbstring)?></b></li>
      <li>Extensão openssl: <b class="<?=$ext_openssl?'ok':'bad'?>"><?=ok($ext_openssl)?></b></li>
      <li>config.php: <b class="<?=$config_ok?'ok':'bad'?>"><?=ok($config_ok)?></b></li>
      <li>Conexão MySQL (<?=h($db_name?:'desconhecido')?>): <b class="<?=$db_ok?'ok':'bad'?>"><?=ok($db_ok)?></b></li>
      <li>Tabela products: <b class="<?=$tbl_products?'ok':'bad'?>"><?=ok($tbl_products)?></b></li>
      <li>Tabela esims: <b class="<?=$tbl_esims?'ok':'bad'?>"><?=ok($tbl_esims)?></b></li>
      <li>Tabela orders: <b class="<?=$tbl_orders?'ok':'bad'?>"><?=ok($tbl_orders)?></b></li>
      <li>Coluna products.category: <b class="<?=$col_products_category?'ok':'bad'?>"><?=ok($col_products_category)?></b></li>
      <li>Coluna orders.notified: <b class="<?=$col_orders_notified?'ok':'bad'?>"><?=ok($col_orders_notified)?></b></li>
      <li>Coluna orders.coupon_code: <b class="<?=$col_orders_coupon?'ok':'bad'?>"><?=ok($col_orders_coupon)?></b></li>
      <li>Coluna orders.discount_cents: <b class="<?=$col_orders_discount_cents?'ok':'bad'?>"><?=ok($col_orders_discount_cents)?></b></li>
      <li>Coluna orders.final_price_cents: <b class="<?=$col_orders_final_price_cents?'ok':'bad'?>"><?=ok($col_orders_final_price_cents)?></b></li>
      <li>Pasta uploads/qr: <b class="<?=$dir_uploads_ok?'ok':'bad'?>"><?=ok($dir_uploads_ok)?></b></li>
      <li>Escrita em uploads/qr: <b class="<?=$write_uploads_ok?'ok':'bad'?>"><?=ok($write_uploads_ok)?></b></li>
      <li>Pasta logs: <b class="<?=$dir_logs_ok?'ok':'bad'?>"><?=ok($dir_logs_ok)?></b></li>
      <li>Escrita em logs: <b class="<?=$write_logs_ok?'ok':'bad'?>"><?=ok($write_logs_ok)?></b></li>
      <li>GET <?=h($base.'/api/products.php')?>: <b class="<?=$ok_products?'ok':'bad'?>"><?=ok($ok_products)?></b></li>
      <li>GET <?=h($base.'/api/orders_create.php')?>: <b class="<?=$ok_create?'ok':'bad'?>"><?=ok($ok_create)?></b></li>
      <li>GET <?=h($base.'/api/order_status.php?txid=TESTE')?>: <b class="<?=$ok_status?'ok':'bad'?>"><?=ok($ok_status)?></b></li>
      <li>GET <?=h($base.'/mxvpay/callback.php')?>: <b class="<?=$ok_cb?'ok':'bad'?>"><?=ok($ok_cb)?></b></li>
    </ul>
    <div class="box">✅ Tudo pronto!<br><span class="muted">Se aparecer HTTP 500, verifique o arquivo <code>.htaccess</code> (remova linhas <code>php_value</code> se o host não permitir).</span></div>
  </div>
</body>
</html>
