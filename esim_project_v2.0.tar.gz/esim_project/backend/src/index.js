
const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const log = require('./logger');

const BOT_TOKEN = process.env.BOT_TOKEN;
const API_BASE = process.env.API_BASE || 'https://esim.buscalotter.com/api';
const HEADER_IMAGE_URL = process.env.HEADER_IMAGE_URL || ''; // optional

if (!BOT_TOKEN) {
  console.error('BOT_TOKEN ausente no .env'); process.exit(1);
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });
log.banner();
log.ok('Bot conectado (polling habilitado)');
log.info(`API_BASE: ${API_BASE}`);

async function fetchImageBuffer(url){
  try{
    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 8000, maxContentLength: 10*1024*1024 });
    const ctype = (res.headers['content-type']||'').toLowerCase();
    if (!ctype.startsWith('image/')) {
      throw new Error(`content-type não é imagem: ${ctype}`);
    }
    const ext = ctype.split('/')[1].split(';')[0] || 'jpg';
    return { buffer: Buffer.from(res.data), filename: `header.${ext}` };
  }catch(e){
    throw e;
  }
}

async function apiGet(path){
  const url = `${API_BASE}${path}`;
  const res = await axios.get(url, { timeout: 8000 });
  return res.data;
}

function homeKeyboard(){
  return {
    reply_markup: {
      inline_keyboard: [
        [{ text: '🛍️ Ver produtos', callback_data: 'products' }],
        [{ text: '🔁 Atualizar', callback_data: 'refresh' }]
      ]
    },
    parse_mode: 'HTML',
    disable_web_page_preview: true
  };
}

async function showHome(chatId){
  log.warn(`showHome ${JSON.stringify({chatId, messageId: null})}`);
  const caption = '<b>Bem-vindo!</b>\nEscolha uma opção abaixo.';
  if (HEADER_IMAGE_URL){
    try{
      const img = await fetchImageBuffer(HEADER_IMAGE_URL);
      await bot.sendPhoto(chatId, img.buffer, { caption, parse_mode: 'HTML', ...homeKeyboard() }, { filename: img.filename, contentType: 'application/octet-stream' });
      return;
    }catch(e){
      log.err(`Header image falhou: ${e.message}`);
    }
  }
  // fallback
  await bot.sendMessage(chatId, caption, homeKeyboard());
}

async function showProdutos(chatId, messageId){
  log.warn(`showProdutos ${JSON.stringify({chatId, messageId})}`);
  try{
    const data = await apiGet('/products.php');
    if (!data.ok) throw new Error(data.message || 'falha products');
    const items = data.products || [];
    if (items.length === 0){
      return bot.sendMessage(chatId, 'Não há produtos disponíveis no momento.', { reply_markup: { inline_keyboard: [[{ text:'↩️ Voltar', callback_data:'home'}]] } });
    }
    const rows = [];
    items.forEach(p => {
      const label = `${p.name} — R$ ${(p.price_cents/100).toFixed(2)} (${p.stock} em estoque)`;
      rows.push([{ text: label, callback_data: `buy:${p.id}` }]);
    });
    rows.push([{ text:'↩️ Voltar', callback_data:'home'}]);
    if (messageId){
      await bot.editMessageText('Selecione um produto:', { chat_id: chatId, message_id: messageId, reply_markup: { inline_keyboard: rows } });
    } else {
      await bot.sendMessage(chatId, 'Selecione um produto:', { reply_markup: { inline_keyboard: rows } });
    }
  }catch(e){
    log.err(`Erro carregando produtos: ${e.message}`);
    await bot.sendMessage(chatId, '⚠️ Erro ao carregar produtos. Tente novamente.', { reply_markup: { inline_keyboard: [[{ text:'↩️ Voltar', callback_data:'home'}]] } });
  }
}

bot.onText(/\/start|menu|home/i, async (msg)=>{
  await showHome(msg.chat.id);
});

bot.on('callback_query', async (q)=>{
  try{
    const chatId = q.message.chat.id;
    const msgId = q.message.message_id;
    const data = q.data || '';
    if (data === 'home'){ await showHome(chatId); return; }
    if (data === 'refresh'){ await showProdutos(chatId, msgId); return; }
    if (data === 'products'){ await showProdutos(chatId, msgId); return; }
    // outros handlers (comprar etc.) aqui…
    await bot.answerCallbackQuery(q.id);
  }catch(e){
    log.err(`Unhandled callback: ${e.message}`);
  }
});
