
const chalk = require('chalk');
const ts = () => new Date().toISOString().replace('T',' ').replace('Z','');
module.exports = {
  ok: (m)=> console.log(chalk.green(`✔ ${ts()} ${m}`)),
  info: (m)=> console.log(chalk.cyan(`ℹ ${ts()} ${m}`)),
  warn: (m)=> console.log(chalk.yellow(`◆ ${ts()} ${m}`)),
  err: (m)=> console.log(chalk.red(`✖ ${ts()} ${m}`)),
  banner: ()=> {
    console.log('┌──────────────────────────────────────────────────────────────┐');
    console.log('│  Node Bot MXVPay Inline v1.0.0                             │');
    console.log('│  node-telegram-bot-api loaded                               │');
    console.log('└──────────────────────────────────────────────────────────────┘');
  }
};
