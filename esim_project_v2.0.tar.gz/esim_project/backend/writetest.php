<?php
$dir = __DIR__ . '/uploads/qr';
@mkdir($dir, 0777, true);
$f = $dir . '/_writetest_' . uniqid() . '.txt';
$w = @file_put_contents($f, 'ok '.date('c'));
echo $w !== false ? "OK: $f" : "ERRO: sem permissão em $dir";
