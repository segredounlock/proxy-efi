<?php
require_once __DIR__ . '/../auth.php';
require_login();

if (!function_exists('esc')) {
  function esc($s) { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}

function admin_url(string $path = ''): string {
  return base_url() . '/admin' . ($path ? '/' . ltrim($path, '/') : '');
}
