<?php
// admin/products.php (stub opcional)
// Caso sua instalação não tenha esta página, este stub garante que o link funcione.
// Se você já possui products.php, pode ignorar este arquivo.
require_once __DIR__ . '/_bootstrap.php';
require_once __DIR__ . '/_header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h3 mb-0">Produtos</h1>
</div>
<div class="alert alert-info">
  Esta é uma página de placeholder. Se sua instalação já possui <code>products.php</code>, mantenha a versão original.
</div>
<?php require_once __DIR__ . '/_footer.php'; ?>
