<?php
declare(strict_types=1);

/**
 * admin/notify_worker.php
 * - Worker acionado por AJAX a cada ~2s
 * - Envia até ~ (TPS * 2) mensagens por chamada, respeitando delay de (1000/TPS) ms
 * POST/GET: id (notification_id)
 */

require_once __DIR__ . '/../config.php';
if (!function_exists('require_login')) {
  require_once __DIR__ . '/_bootstrap.php';
}
require_login();

header('Content-Type: application/json; charset=utf-8');

$id = isset($_REQUEST['id']) ? (int)$_REQUEST['id'] : 0;
if ($id <= 0) { echo json_encode(['ok'=>false,'err'=>'id inválido']); exit; }

$pdo = db();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

function tg_send_message_curl(string $token, string $chatId, string $text, string $parse='HTML'): array {
  $endpoint = "https://api.telegram.org/bot{$token}/sendMessage";
  $payload = [
    'chat_id' => $chatId,
    'text' => $text,
    'parse_mode' => $parse,
    'disable_web_page_preview' => true,
  ];
  $ch = curl_init($endpoint);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_TIMEOUT => 20,
  ]);
  $res = curl_exec($ch);
  $err = curl_error($ch);
  curl_close($ch);

  if ($err) return ['ok'=>false,'error'=>$err,'raw'=>null];
  $j = json_decode((string)$res, true);
  if (!is_array($j)) return ['ok'=>false,'error'=>'invalid_json','raw'=>$res];
  return $j;
}

// carrega notificação
$N = $pdo->query("SELECT * FROM notifications WHERE id={$id}")->fetch(PDO::FETCH_ASSOC);
if (!$N) { echo json_encode(['ok'=>false,'err'=>'notificação não encontrada']); exit; }

if ((string)$N['status'] === 'finished') {
  echo json_encode(['ok'=>true,'done'=>true]); exit;
}

$BOT_TOKEN = getenv('BOT_TOKEN') ?: '';
if (!$BOT_TOKEN) { echo json_encode(['ok'=>false,'err'=>'BOT_TOKEN ausente']); exit; }

$tps  = max(1, min(30, (int)($N['tps'] ?? 15)));
$delayMs = (int)floor(1000 / $tps);
$maxToSend = $tps * 2; // por chamada (~2s)

$pdo->beginTransaction();

// marca started_at se ainda não
if ($N['started_at'] === null) {
  $pdo->prepare("UPDATE notifications SET started_at=NOW(), status='running', updated_at=NOW() WHERE id=:id")
      ->execute([':id'=>$id]);
}

// busca próximos recipients “queued”
$rec = $pdo->prepare("
  SELECT id, chat_id
  FROM notifications_recipients
  WHERE notification_id=:nid AND status='queued'
  ORDER BY id ASC
  LIMIT {$maxToSend}
");
$rec->execute([':nid'=>$id]);
$rows = $rec->fetchAll(PDO::FETCH_ASSOC);

$pdo->commit();

if (!$rows) {
  // terminou?
  $sent = (int)$pdo->query("SELECT COUNT(*) FROM notifications_recipients WHERE notification_id={$id} AND status='sent'")->fetchColumn();
  $fail = (int)$pdo->query("SELECT COUNT(*) FROM notifications_recipients WHERE notification_id={$id} AND status='failed'")->fetchColumn();
  $pdo->prepare("UPDATE notifications SET sent=:s, fail=:f, status='finished', finished_at=NOW(), updated_at=NOW() WHERE id=:id")
      ->execute([':s'=>$sent, ':f'=>$fail, ':id'=>$id]);

  echo json_encode(['ok'=>true,'done'=>true]); exit;
}

// pega texto/parse_mode no ato (pode ter sido alterado)
$stMsg = $pdo->prepare("SELECT message, parse_mode FROM notifications WHERE id=:id");
$stMsg->execute([':id'=>$id]);
$CFG = $stMsg->fetch(PDO::FETCH_ASSOC);
$text = (string)$CFG['message'];
$parse= (string)$CFG['parse_mode'] ?: 'HTML';

$sentCount = 0; $failCount = 0;

foreach ($rows as $r) {
  $rid = (int)$r['id'];
  $cid = (string)$r['chat_id'];

  // marca como "sending" para evitar corrida
  $pdo->prepare("UPDATE notifications_recipients SET status='sending', attempt=attempt+1, updated_at=NOW() WHERE id=:rid AND status='queued'")
      ->execute([':rid'=>$rid]);

  // envia
  $jr = tg_send_message_curl($BOT_TOKEN, $cid, $text, $parse);

  if (!empty($jr['ok'])) {
    $sentCount++;
    $pdo->prepare("UPDATE notifications_recipients SET status='sent', sent_at=NOW(), updated_at=NOW() WHERE id=:rid")
        ->execute([':rid'=>$rid]);
  } else {
    $failCount++;
    $desc = '';
    if (isset($jr['description'])) $desc = (string)$jr['description'];
    elseif (isset($jr['error'])) $desc = (string)$jr['error'];
    else $desc = json_encode($jr, JSON_UNESCAPED_UNICODE);

    $pdo->prepare("UPDATE notifications_recipients SET status='failed', last_error=:e, updated_at=NOW() WHERE id=:rid")
        ->execute([':e'=>$desc, ':rid'=>$rid]);
  }

  // sleep entre envios para respeitar TPS
  usleep($delayMs * 1000);
}

// atualiza counters agregados
$stAgg = $pdo->prepare("
  UPDATE notifications n
  SET
    sent = (SELECT COUNT(*) FROM notifications_recipients WHERE notification_id=n.id AND status='sent'),
    fail = (SELECT COUNT(*) FROM notifications_recipients WHERE notification_id=n.id AND status='failed'),
    updated_at = NOW()
  WHERE n.id=:id
");
$stAgg->execute([':id'=>$id]);

echo json_encode(['ok'=>true,'sent_now'=>$sentCount,'fail_now'=>$failCount]);
