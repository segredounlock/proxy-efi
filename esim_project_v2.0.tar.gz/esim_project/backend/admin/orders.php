<?php
// admin/orders.php
declare(strict_types=1);
require_once __DIR__ . '/../config.php';
require_login();

$pdo = db();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// ---------- filtros ----------
$q   = trim($_GET['q'] ?? '');
$st  = trim($_GET['status'] ?? ''); // '', pending, paid, delivered, completed, concluidos

$where = [];
$bind  = [];

// busca por id, chat_id ou cupom
if ($q !== '') {
  $where[] = '(o.id = :qid OR o.chat_id LIKE :qchat OR o.coupon_code LIKE :qcup)';
  $bind[':qid']   = ctype_digit($q) ? (int)$q : 0;
  $bind[':qchat'] = "%{$q}%";
  $bind[':qcup']  = "%{$q}%";
}

// mapa de status
if ($st !== '') {
  if ($st === 'concluidos') {
    $where[] = "o.status IN ('delivered','completed')";
  } elseif (in_array($st, ['pending','paid','delivered','completed'], true)) {
    $where[] = 'o.status = :st';
    $bind[':st'] = $st;
  }
}

$wsql = $where ? ('WHERE '.implode(' AND ', $where)) : '';

// ---------- contadores do topo ----------
$total = (int)$pdo->query("SELECT COUNT(*) FROM orders o")->fetchColumn();

$paid  = (int)$pdo->query("SELECT COUNT(*) FROM orders o WHERE o.status='paid'")->fetchColumn();

// “Entregues” passa a considerar delivered + completed
$deliv = (int)$pdo->query("SELECT COUNT(*) FROM orders o WHERE o.status IN ('delivered','completed')")->fetchColumn();

// Receita considera paid + delivered + completed
$reais = (int)$pdo->query("
  SELECT COALESCE(SUM(CASE 
    WHEN o.final_price_cents IS NOT NULL AND o.final_price_cents > 0 THEN o.final_price_cents 
    ELSE o.price_cents END), 0)
  FROM orders o
  WHERE o.status IN ('paid','delivered','completed')
")->fetchColumn();
$reais_fmt = 'R$ '.number_format($reais/100, 2, ',', '.');

// ---------- consulta da lista ----------
$sql = "
  SELECT o.*, p.name AS product_name
  FROM orders o
  LEFT JOIN products p ON p.id = o.product_id
  $wsql
  ORDER BY o.id DESC
  LIMIT 200
";
$stt = $pdo->prepare($sql);
$stt->execute($bind);
$rows = $stt->fetchAll(PDO::FETCH_ASSOC);

// helpers
if (!function_exists('esc')) {
  function esc($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
}
function fmt_money_cents($c){ return 'R$ '.number_format(((int)$c)/100,2,',','.'); }
function badge($status){
  $map = [
    'pending'   => ['text'=>'PENDENTE','class'=>'badge-soft-warning'],
    'paid'      => ['text'=>'PAGO','class'=>'badge-soft-primary'],
    'delivered' => ['text'=>'ENTREGUE','class'=>'badge-soft-success'],
    'completed' => ['text'=>'COMPLETADO','class'=>'badge-soft-success'],
  ];
  $s = strtolower((string)$status);
  $m = $map[$s] ?? ['text'=>strtoupper($s),'class'=>'badge-soft-secondary'];
  return '<span class="badge '.$m['class'].'">'.$m['text'].'</span>';
}

$active = 'orders';
include __DIR__ . '/_header.php';
?>

<style>
  /* mesma paleta do dashboard */
  .stat-card{background:#0c141f;border:1px solid rgba(255,255,255,.06);border-radius:14px;padding:22px}
  .stat-title{color:#9fb3c8;font-weight:600;margin-bottom:6px}
  .stat-value{font-size:28px;font-weight:800;letter-spacing:.3px}
  .stat-orange{border-color:#f59e0b33} .stat-orange .stat-value{color:#f59e0b}
  .stat-blue{border-color:#3b82f633}   .stat-blue .stat-value{color:#60a5fa}
  .stat-green{border-color:#10b98133}  .stat-green .stat-value{color:#34d399}
  .stat-purple{border-color:#8b5cf633} .stat-purple .stat-value{color:#a78bfa}

  .badge-soft-warning{background:rgba(245,158,11,.15);color:#f59e0b;border:1px solid rgba(245,158,11,.25)}
  .badge-soft-primary{background:rgba(59,130,246,.15);color:#60a5fa;border:1px solid rgba(59,130,246,.25)}
  .badge-soft-success{background:rgba(16,185,129,.15);color:#34d399;border:1px solid rgba(16,185,129,.25)}
  .badge-soft-secondary{background:rgba(148,163,184,.15);color:#cbd5e1;border:1px solid rgba(148,163,184,.25)}

  .form-control, .form-select{background:#0f1722;border-color:#1e293b;color:#cbd5e1}
  .table thead th{color:#9fb3c8;font-weight:700;border-bottom:1px solid #1f2a37}
  .table tbody td{vertical-align:middle;border-color:#15202e}
  .btn-filter{background:linear-gradient(90deg,#74a2ff,#b18cff);border:0}
  .btn-clear{background:#0f1722;border:1px solid #243244;color:#9fb3c8}
</style>

<div class="container-page">
  <!-- TOP CARDS -->
  <div class="row g-3 mb-4">
    <div class="col-12 col-md-3">
      <div class="stat-card stat-orange">
        <div class="stat-title">Pedidos (listados)</div>
        <div class="stat-value"><?= esc($total) ?></div>
      </div>
    </div>
    <div class="col-12 col-md-3">
      <div class="stat-card stat-blue">
        <div class="stat-title">Pagos</div>
        <div class="stat-value"><?= esc($deliv) ?></div>
      </div>
    </div>
    <div class="col-12 col-md-3">
      <div class="stat-card stat-purple">
        <div class="stat-title">Entregues</div>
        <div class="stat-value"><?= esc($deliv) ?></div>
      </div>
    </div>
    <div class="col-12 col-md-3">
      <div class="stat-card stat-green">
        <div class="stat-title">Receita (lista)</div>
        <div class="stat-value"><?= esc($reais_fmt) ?></div>
      </div>
    </div>
  </div>

  <!-- FILTROS -->
  <form class="row g-2 align-items-end mb-3" method="get">
    <div class="col-12 col-md-6">
      <label class="form-label small text-secondary">ID, chat_id ou cupom...</label>
      <input type="text" name="q" value="<?= esc($q) ?>" class="form-control" placeholder="Ex.: 123 | 1901426549 | CUPOM10">
    </div>
    <div class="col-12 col-md-3">
      <label class="form-label small text-secondary">Status (todos)</label>
      <select name="status" class="form-select">
        <?php
          $opts = [
            ''            => 'Todos',
            'pending'     => 'pending',
            'delivered'        => 'delivered',
            'delivered'   => 'delivered',
            'completed'   => 'completed',
            'concluidos'  => 'concluídos (entregues + completados)',
          ];
          foreach($opts as $k=>$v){
            $sel = ($st===$k)?' selected':'';
            echo "<option value=\"".esc($k)."\"{$sel}>".esc($v)."</option>";
          }
        ?>
      </select>
    </div>
    <div class="col-12 col-md-3 d-flex gap-2">
      <button class="btn btn-filter w-50">Filtrar</button>
      <a class="btn btn-clear w-50" href="/admin/orders.php">Limpar</a>
    </div>
  </form>

  <!-- LISTA -->
  <div class="table-responsive">
    <table class="table table-dark table-hover align-middle">
      <thead>
        <tr>
          <th>ID</th>
          <th>Produto</th>
          <th>Cliente</th>
          <th>Status</th>
          <th>Valor</th>
          <th>Cupom</th>
          <th>Pago em</th>
          <th>Mídia</th>
          <th class="text-end">Ações</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="9" class="text-center text-secondary py-4">Nenhum pedido encontrado.</td></tr>
      <?php else: foreach($rows as $r): ?>
        <tr>
          <td>#<?= (int)$r['id'] ?></td>
          <td><?= esc($r['product_name'] ?? $r['product_id']) ?></td>
          <td><?= 'chat: '.esc($r['chat_id']) ?></td>
          <td><?= badge($r['status']) ?></td>
          <td><?= fmt_money_cents($r['final_price_cents'] ?? $r['price_cents']) ?></td>
          <td><?= $r['coupon_code'] ? esc($r['coupon_code']) : '—' ?></td>
          <td><?= $r['paid_at'] ? esc($r['paid_at']) : '—' ?></td>
          <td>
            <?php
              $media = $r['media_url'] ?? $r['qr_url'] ?? $r['file_path'] ?? $r['qr_path'] ?? null;
              echo $media ? '<a href="'.esc($media).'" target="_blank">abrir</a>' : '—';
            ?>
          </td>
          <td class="text-end">
            <!-- exemplo: endpoint opcional p/ reenviar tg -->
            <a class="btn btn-sm btn-primary" href="/api/resend_telegram.php?order_id=<?= (int)$r['id'] ?>">Reenviar TG</a>
          </td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
