<?php
declare(strict_types=1);
require_once __DIR__ . '/_bootstrap.php';
require_once __DIR__ . '/_header.php'; // mantém o tema/includes

$pdo = db();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Detecta se há coluna created_at em users
$has_created_at = false;
try {
  $chk = $pdo->query("SHOW COLUMNS FROM `users` LIKE 'created_at'")->fetch();
  $has_created_at = (bool)$chk;
} catch (Throwable $e) { $has_created_at = false; }

// Inputs
$q         = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
$date_from = isset($_GET['from']) ? trim((string)$_GET['from']) : '';
$date_to   = isset($_GET['to']) ? trim((string)$_GET['to']) : '';
$per_page  = isset($_GET['pp']) ? max(5, min(200, (int)$_GET['pp'])) : 25;
$page      = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;

// WHERE seguro (id/chat_id/username)
$where = "WHERE 1";
$params = [];

if ($q !== '') {
  if (preg_match('~^[0-9]+$~', $q)) {
    $where .= " AND (u.id = :qid OR u.chat_id = :qid)";
    $params[':qid'] = (int)$q;
  } else {
    $where .= " AND (u.username LIKE :qname)";
    $params[':qname'] = '%'.$q.'%';
  }
}

if ($has_created_at) {
  if ($date_from !== '') {
    $df = $date_from;
    if (preg_match('~^(\d{2})/(\d{2})/(\d{4})$~', $df, $m)) $df = "{$m[3]}-{$m[2]}-{$m[1]}";
    $where .= " AND u.created_at >= :dfrom";
    $params[':dfrom'] = $df . " 00:00:00";
  }
  if ($date_to !== '') {
    $dt = $date_to;
    if (preg_match('~^(\d{2})/(\d{2})/(\d{4})$~', $dt, $m)) $dt = "{$m[3]}-{$m[2]}-{$m[1]}";
    $where .= " AND u.created_at <= :dto";
    $params[':dto'] = $dt . " 23:59:59";
  }
}

// Total
$sql_count = "SELECT COUNT(*) FROM users u $where";
$stc = $pdo->prepare($sql_count);
$stc->execute($params);
$total = (int)$stc->fetchColumn();

$pages = max(1, (int)ceil($total / $per_page));
if ($page > $pages) $page = $pages;
$offset = ($page - 1) * $per_page;

// Linhas
$sql = "SELECT u.* FROM users u $where ORDER BY u.id DESC LIMIT :lim OFFSET :off";
$st = $pdo->prepare($sql);
foreach ($params as $k=>$v) $st->bindValue($k, $v);
$st->bindValue(':lim', $per_page, PDO::PARAM_INT);
$st->bindValue(':off', $offset, PDO::PARAM_INT);
$st->execute();
$rows = $st->fetchAll(PDO::FETCH_ASSOC);

// helper
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
?>
<main class="container-fluid py-3"><!-- container local, não mexe na navbar -->
  <h2>Usuários</h2>
  <form class="row gy-2 gx-2 align-items-end mb-3" method="get" action="">
    <div class="col-sm-4">
      <label class="form-label">ID, chat_id ou @username</label>
      <input type="text" name="q" value="<?=h($q)?>" class="form-control" placeholder="Ex: 123 | 1901426549 | @usuario">
    </div>
    <div class="col-sm-2">
      <label class="form-label">De</label>
      <input type="text" name="from" value="<?=h($date_from)?>" class="form-control" placeholder="dd/mm/aaaa" <?= $has_created_at?'':'disabled'?>>
    </div>
    <div class="col-sm-2">
      <label class="form-label">Até</label>
      <input type="text" name="to" value="<?=h($date_to)?>" class="form-control" placeholder="dd/mm/aaaa" <?= $has_created_at?'':'disabled'?>>
    </div>
    <div class="col-sm-2">
      <label class="form-label">Por página</label>
      <input type="number" name="pp" min="5" max="200" value="<?=h((string)$per_page)?>" class="form-control">
    </div>
    <div class="col-sm-2">
      <button class="btn btn-primary w-100">Filtrar</button>
    </div>
  </form>

  <div class="card">
    <div class="card-body p-0">
      <div class="table-responsive">
        <table class="table table-dark table-hover mb-0 align-middle">
          <thead>
            <tr>
              <th style="width:90px">ID</th>
              <th style="width:220px">Username</th>
              <th style="width:220px">Chat</th>
              <?php if ($has_created_at): ?><th style="width:220px">Criado</th><?php endif; ?>
            </tr>
          </thead>
          <tbody>
          <?php if (!$rows): ?>
            <tr><td colspan="<?= $has_created_at?4:3 ?>" class="text-center py-4">Nenhum registro.</td></tr>
          <?php else: foreach ($rows as $r): ?>
            <tr>
              <td>#<?=h($r['id'])?></td>
              <td><?= !empty($r['username']) ? '@'.h($r['username']) : '—' ?></td>
              <td><code><?=h($r['chat_id'] ?? '')?></code></td>
              <?php if ($has_created_at): ?><td><?=h($r['created_at'])?></td><?php endif; ?>
            </tr>
          <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <?php
    // Paginação – mantém query string
    $base = $_GET;
    $base['p'] = 1; $first = '?'.http_build_query($base);
    $base['p'] = max(1,$page-1); $prev = '?'.http_build_query($base);
    $base['p'] = min($pages,$page+1); $next = '?'.http_build_query($base);
    $base['p'] = $pages; $last = '?'.http_build_query($base);
  ?>
  <nav class="mt-3">
    <ul class="pagination">
      <li class="page-item <?= $page<=1?'disabled':'' ?>"><a class="page-link" href="<?=$first?>">« Primeira</a></li>
      <li class="page-item <?= $page<=1?'disabled':'' ?>"><a class="page-link" href="<?=$prev?>">‹ Anterior</a></li>
      <li class="page-item disabled"><span class="page-link">Página <?=$page?>/<?=$pages?></span></li>
      <li class="page-item <?= $page>=$pages?'disabled':'' ?>"><a class="page-link" href="<?=$next?>">Próxima ›</a></li>
      <li class="page-item <?= $page>=$pages?'disabled':'' ?>"><a class="page-link" href="<?=$last?>">Última »</a></li>
    </ul>
  </nav>
  
</main>


<?php require_once __DIR__ . '/_footer.php'; ?>
