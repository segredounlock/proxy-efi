<?php
require_once __DIR__ . '/../config.php'; require_login(); $pdo = db();
$id = (int)($_POST['id'] ?? 0);
$pdo->exec("UPDATE coupons SET active = 1 - active WHERE id = $id");
header('Location: /admin/coupons.php');
