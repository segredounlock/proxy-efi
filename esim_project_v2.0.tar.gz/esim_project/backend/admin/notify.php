<?php
declare(strict_types=1);

/**
 * admin/notify.php — Broadcast com contagem igual ao painel:
 * - Mostra "Usuários (linhas na users)" e "Destinatários (DISTINCT chat_id)".
 * - Envia apenas para DISTINCT chat_id (evita duplicados).
 * - TPS configurável; preview.
 * - Resumo com sucessos/falhas.
 */

require_once __DIR__ . '/../config.php';
if (!function_exists('require_login')) {
  require_once __DIR__ . '/_bootstrap.php';
}
require_login();

function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

function tg_send_message(string $token, string $chatId, string $text, string $parse = 'HTML'): array {
  $endpoint = "https://api.telegram.org/bot{$token}/sendMessage";
  $payload = [
    'chat_id' => $chatId,
    'text' => $text,
    'parse_mode' => $parse,
    'disable_web_page_preview' => true,
  ];
  $ch = curl_init($endpoint);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_CONNECTTIMEOUT => 15,
    CURLOPT_TIMEOUT => 25,
  ]);
  $res = curl_exec($ch);
  $err = curl_error($ch);
  curl_close($ch);

  if ($err) return ['ok'=>false,'error'=>'curl_error','description'=>$err];
  $j = json_decode((string)$res, true);
  if (!is_array($j)) return ['ok'=>false,'error'=>'invalid_json','description'=>(string)$res];
  return $j;
}

function log_line(string $line): void {
  $dir = __DIR__ . '/../logs';
  if (!is_dir($dir)) @mkdir($dir, 0775, true);
  @file_put_contents($dir . '/notify_' . date('Ymd') . '.log', '['.date('H:i:s').'] ' . $line . PHP_EOL, FILE_APPEND);
}

$BOT_TOKEN = getenv('BOT_TOKEN') ?: '';
if (!$BOT_TOKEN) {
  http_response_code(500);
  echo '<div style="padding:20px;color:#fff;background:#900">BOT_TOKEN ausente. Configure no .env ou config.php.</div>';
  exit;
}

$pdo = db();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

/* ===== Contagens exibidas no topo ===== */
$k_users   = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(); // igual ao card de Produtos
$k_distinct = (int)$pdo->query("SELECT COUNT(DISTINCT chat_id) FROM users WHERE chat_id IS NOT NULL AND chat_id <> ''")->fetchColumn();

$step   = 'form';
$result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $text = trim((string)($_POST['message'] ?? ''));
  $tps  = max(1, min(30, (int)($_POST['tps'] ?? 15))); // 15 é seguro
  $preview = isset($_POST['preview']) && $_POST['preview'] === '1';

  if ($text === '') {
    $result = ['ok'=>false,'msg'=>'Digite uma mensagem para enviar.'];
    $step = 'form';
  } else {
    // Destinatários (DISTINCT chat_id)
    $rows = $pdo->query("SELECT DISTINCT chat_id FROM users WHERE chat_id IS NOT NULL AND chat_id <> ''")
                ->fetchAll(PDO::FETCH_COLUMN);
    $targets = array_values(array_filter(array_map('strval', $rows)));
    $total = count($targets);

    $sent  = 0; $fail = 0; $fails = [];

    if ($preview) {
      $one = $targets[0] ?? null;
      if ($one) {
        $r  = tg_send_message($BOT_TOKEN, $one, $text, 'HTML');
        $ok = isset($r['ok']) ? (bool)$r['ok'] : false;
        if ($ok) $sent = 1; else { $fail = 1; $fails[] = ['chat_id'=>$one, 'resp'=>$r]; }
        log_line("PREVIEW to {$one}: ".json_encode($r, JSON_UNESCAPED_UNICODE));
      }
      $result = [
        'ok'=>true, 'preview'=>true,
        'users_total'=>$k_users,
        'targets_total'=>$total,
        'sent'=>$sent, 'fail'=>$fail, 'fails'=>$fails, 'message'=>$text,
        'tps'=>$tps
      ];
      $step = 'done';
    } else {
      // throttle: dorme a cada mensagem para respeitar TPS
      $sleepMs = (int)floor(1000 / max(1, $tps)); // ex.: 15 tps => ~66ms
      set_time_limit(0);

      foreach ($targets as $chatId) {
        $r  = tg_send_message($BOT_TOKEN, $chatId, $text, 'HTML');
        $ok = isset($r['ok']) ? (bool)$r['ok'] : false;
        if ($ok) $sent++; else { $fail++; $fails[] = ['chat_id'=>$chatId, 'resp'=>$r]; }
        log_line("SEND to {$chatId}: ".json_encode($r, JSON_UNESCAPED_UNICODE));
        usleep($sleepMs * 1000);
      }

      $result = [
        'ok'=>true,
        'users_total'=>$k_users,
        'targets_total'=>$total,
        'sent'=>$sent, 'fail'=>$fail, 'fails'=>$fails, 'message'=>$text,
        'tps'=>$tps
      ];
      $step = 'done';
    }
  }
}

include __DIR__ . '/_header.php';
?>
<style>
  .notify-wrap .card{background:#0f1726;border-color:#1e2a44}
  .notify-wrap .mono{font-family:ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace}
  .notify-wrap pre{background:#0b1220;color:#cfe3ff;border:1px solid #1e2a44;border-radius:10px;padding:12px}
  .badge-soft{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);border-radius:8px;padding:.25rem .5rem}
  .ok-chip{background:#09391f;color:#86efac;border:1px solid #14532d;border-radius:8px;padding:.25rem .5rem}
  .danger-chip{background:#3a0d0d;color:#fecaca;border:1px solid #7f1d1d;border-radius:8px;padding:.25rem .5rem}
</style>

<div class="container notify-wrap py-3">
  <h3 class="mb-3">📣 Notificar todos os usuários</h3>

  <div class="mb-3">
    <span class="badge-soft">Usuários (linhas em <code>users</code>): <b><?= (int)$k_users ?></b></span>
    <span class="badge-soft ms-2">Destinatários (DISTINCT <code>chat_id</code>): <b><?= (int)$k_distinct ?></b></span>
  </div>

  <?php if ($step === 'form'): ?>
    <div class="card shadow-sm mb-3">
      <div class="card-body">
        <b>Exemplo de HTML suportado pelo Telegram:</b>
        <pre class="mono" style="white-space:pre-wrap;">
<strong>Negrito</strong>, <em>itálico</em>, <u>sublinhado</u>, <s>tachado</s>, <span class="tg-spoiler">spoiler</span>,
<code>código inline</code>,

<pre>bloco de código</pre>

<a href="https://segredounlock.com">link</a>,
<a href="tg://user?id=123456789">menção_por_ID</a>.
        </pre>
        <small class="text-muted">Use apenas tags permitidas pelo Telegram e feche-as corretamente.</small>
      </div>
    </div>

    <form method="post" class="card shadow-sm">
      <div class="card-body">
        <div class="mb-3">
          <label class="form-label">Mensagem</label>
          <textarea name="message" class="form-control" rows="7" placeholder="Escreva sua mensagem aqui..."></textarea>
        </div>

        <div class="mb-3">
          <label class="form-label">TPS (msgs/seg) — <span class="text-muted">seguro: 15</span></label>
          <input type="number" name="tps" class="form-control" value="15" min="1" max="30" style="max-width:220px">
        </div>

        <div class="d-flex flex-wrap gap-2">
          <button class="btn btn-outline-info" name="preview" value="1" type="submit">🔍 Enviar preview (1 usuário)</button>
          <button class="btn btn-primary" type="submit">🚀 Enviar para todos</button>
          <a href="index.php" class="btn btn-secondary">Voltar</a>
        </div>

        <?php if (isset($result) && !$result['ok']): ?>
          <div class="alert alert-danger mt-3 mb-0"><?= h($result['msg'] ?? 'Erro') ?></div>
        <?php endif; ?>
      </div>
    </form>
  <?php endif; ?>

  <?php if ($step === 'done' && $result): ?>
    <div class="card shadow-sm mt-3">
      <div class="card-body">
        <div class="d-flex align-items-center gap-2 mb-2">
          <?php if (!empty($result['preview'])): ?>
            <span class="ok-chip">✓ Preview enviado</span>
          <?php else: ?>
            <span class="ok-chip">✓ Envio concluído</span>
          <?php endif; ?>
          <span class="badge-soft">TPS: <b><?= (int)$result['tps'] ?></b></span>
        </div>

        <div class="d-flex flex-wrap gap-2 mb-2">
          <span class="badge-soft">Usuários (linhas): <b><?= (int)$result['users_total'] ?></b></span>
          <span class="badge-soft">Destinatários (DISTINCT): <b><?= (int)$result['targets_total'] ?></b></span>
          <span class="ok-chip">Sucessos: <b><?= (int)$result['sent'] ?></b></span>
          <span class="<?= ($result['fail']??0) ? 'danger-chip' : 'ok-chip' ?>">Falhas: <b><?= (int)$result['fail'] ?></b></span>
        </div>

        <?php if (!empty($result['message'])): ?>
          <div class="mt-2">
            <div class="text-muted small mb-1">Mensagem enviada:</div>
            <pre class="mono"><?= h($result['message']) ?></pre>
          </div>
        <?php endif; ?>

        <?php if (!empty($result['fails'])): ?>
          <hr>
          <b>Falhas</b>
          <div class="row g-2 mt-1">
            <?php foreach ($result['fails'] as $f):
              $cid = (string)($f['chat_id'] ?? '');
              $desc = $f['resp']['description'] ?? ($f['resp']['error'] ?? json_encode($f['resp'], JSON_UNESCAPED_UNICODE));
            ?>
              <div class="col-md-6">
                <div class="card" style="border-left:4px solid #f87171">
                  <div class="card-body py-2">
                    <div class="d-flex justify-content-between align-items-center">
                      <div class="mono">Chat: <b><?= h($cid) ?></b></div>
                      <span class="danger-chip">falha</span>
                    </div>
                    <div class="text-muted small mt-1"><?= h($desc) ?></div>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <div class="d-flex gap-2 mt-3">
          <a class="btn btn-secondary" href="notify.php">Novo envio</a>
          <a class="btn btn-outline-light" href="index.php">Voltar</a>
        </div>
      </div>
    </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/_footer.php';
