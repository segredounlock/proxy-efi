<?php
require_once __DIR__ . '/../config.php'; require_login(); $pdo = db();
$code = strtoupper(trim($_POST['code'] ?? ''));
$desc = $_POST['description'] ?? '';
$type = $_POST['discount_type'] ?? 'percent';
$val  = floatval($_POST['value'] ?? '0');
$max  = strlen($_POST['uses_max'] ?? '') ? intval($_POST['uses_max']) : null;
$exp  = $_POST['expires_at'] ?? null;
$pdo->prepare("INSERT INTO coupons (code, description, discount_type, value, uses_max, expires_at) VALUES (?,?,?,?,?,?)")
    ->execute([$code,$desc,$type,$val,$max,$exp]);
header('Location: /admin/coupons.php');
