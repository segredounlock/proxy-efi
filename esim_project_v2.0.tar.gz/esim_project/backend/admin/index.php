<?php
// admin/index.php (safe + KPIs animadas)
declare(strict_types=1);
require_once __DIR__ . '/../config.php';
require_login();
include __DIR__ . '/_header.php';

$k_users = $k_orders = $k_revenue = $k_sold = 0.0;
try {
  $pdo = db();
  $k_users  = (int)($pdo->query("SELECT COUNT(DISTINCT chat_id) AS n FROM orders")->fetch()['n'] ?? 0);
  $k_orders = (int)($pdo->query("SELECT COUNT(*) AS n FROM orders")->fetch()['n'] ?? 0);
  $k_revenue = (float)($pdo->query("SELECT COALESCE(SUM(COALESCE(final_price_cents, price_cents))/100,0) AS s FROM orders WHERE status IN ('delivered','completed','paid')")->fetch()['s'] ?? 0);
  $k_sold = (int)($pdo->query("SELECT COUNT(*) AS n FROM orders WHERE status IN ('delivered','completed','paid')")->fetch()['n'] ?? 0);
} catch (Throwable $e) {
  if (function_exists('write_log')) write_log('admin_index', ['error'=>$e->getMessage()]);
  echo '<div class="alert alert-danger">Erro ao carregar métricas: '.htmlspecialchars($e->getMessage()).'</div>';
}
?>
<div class="row g-3 mb-3">
  <div class="col-md-3">
    <div class="kpi users">
      <div class="label"><i class="bi bi-people-fill me-1"></i> Usuários</div>
      <div class="value" data-countup="<?= (int)$k_users ?>">0</div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="kpi orders">
      <div class="label"><i class="bi bi-bag-check-fill me-1"></i> Pedidos</div>
      <div class="value" data-countup="<?= (int)$k_orders ?>">0</div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="kpi money">
      <div class="label"><i class="bi bi-cash-coin me-1"></i> Receita (sucesso)</div>
      <div class="value" data-countup-money="<?= number_format((float)$k_revenue,2,'.','') ?>">R$ 0,00</div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="kpi sold">
      <div class="label"><i class="bi bi-qr-code-scan me-1"></i> eSIM vendidos</div>
      <div class="value" data-countup="<?= (int)$k_sold ?>">0</div>
    </div>
  </div>
</div>
<div class="mb-3 d-flex gap-2">
  <a class="btn btn-neon btn-sm" href="/admin/uploader.php">+ Adicionar estoque (upload)</a>
  <a class="btn btn-outline-light btn-sm" href="/admin/esims.php">Abrir Estoque</a>
  <a class="btn btn-outline-light btn-sm" href="/admin/sales.php">Últimas vendas</a>
</div>

<script>
// Animação de contagem (inteiros e dinheiro)
(function(){
  const ease = t => 1- Math.pow(1-t, 3);
  const dur = 900; // ms
  const start = performance.now();

  // inteiros
  document.querySelectorAll('[data-countup]').forEach(el=>{
    const target = parseInt(el.getAttribute('data-countup')||'0',10);
    if (isNaN(target)) return;
    function step(ts){
      const p = Math.min(1, (ts-start)/dur);
      el.textContent = Math.round(target * ease(p));
      if (p<1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  });
  // dinheiro
  document.querySelectorAll('[data-countup-money]').forEach(el=>{
    const target = parseFloat(el.getAttribute('data-countup-money')||'0');
    function step(ts){
      const p = Math.min(1, (ts-start)/dur);
      const v = target * ease(p);
      el.textContent = 'R$ ' + v.toLocaleString('pt-BR', {minimumFractionDigits:2, maximumFractionDigits:2});
      if (p<1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  });
})();
</script>

<?php include __DIR__ . '/_footer.php'; ?>
