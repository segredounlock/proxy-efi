<?php // admin/partials/nav.php
?>
<nav class="navbar navbar-expand-lg sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold" href="<?= BASE_URL ?>/admin/index.php"><?= esc(STORE_TITLE) ?></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="adminNav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/admin/index.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/admin/products.php">Produtos</a></li>
        <li class="nav-item"><a class="nav-link active" href="<?= BASE_URL ?>/admin/orders.php">Pedidos</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/admin/esims.php">Estoque (eSIM)</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/admin/coupons.php">Cupons</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/admin/users.php">Usuários</a></li>
      </ul>
      <a href="<?= BASE_URL ?>/admin/logout.php" class="btn btn-sm btn-outline-light">Sair</a>
    </div>
  </div>
</nav>
