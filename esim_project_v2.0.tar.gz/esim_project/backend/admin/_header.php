<?php /* admin/_header.php (Glow + Icons, seguro) */ ?>
<?php
  if (!function_exists('nav_active')) {
    function nav_active(string $needle): string {
      $path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
      return (strpos($path, $needle) === 0) ? 'active' : '';
    }
  }
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>eSIM Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <style>
    :root{
      --bg:#0b1220; --nav:#0f172a; --card:#0e1626; --card-border:#1e293b;
      --text:#e2e8f0; --muted:#94a3b8; --accent:#60a5fa; --glow: 0 0 12px rgba(96,165,250,.35);
      --success:#22c55e; --money:#16a34a; --orders:#3b82f6; --users:#f59e0b; --sold:#a78bfa;
    }
    @keyframes fadeIn {from{opacity:0; transform:translateY(6px)} to{opacity:1; transform:none}}
    body { background:var(--bg); color:var(--text); padding-top:72px }
    .navbar{ background:var(--nav); box-shadow:0 2px 12px rgba(0,0,0,.25) }
    .navbar .nav-link { color:#cbd5e1; transition:color .15s ease }
    .navbar .nav-link:hover { color:#fff }
    .navbar .nav-link.active { color:#fff; position:relative }
    .navbar .nav-link.active::after{
      content:''; position:absolute; left:8px; right:8px; bottom:-8px; height:3px;
      background: linear-gradient(90deg, #38bdf8, #a78bfa);
      border-radius:8px; box-shadow: var(--glow);
    }
    .card{ background:var(--card); border-color:var(--card-border); animation: fadeIn .25s ease both }
    .kpi{ border:1px solid var(--card-border); border-radius:16px; padding:16px; position:relative; overflow:hidden }
    .kpi .label{ font-size:.9rem; color:var(--muted) }
    .kpi .value{ font-size:1.8rem; font-weight:700 }
    .kpi::before{ content:''; position:absolute; inset:-1px; border-radius:16px; pointer-events:none;
      background: conic-gradient(from 180deg at 50% 50%, transparent 0 75%, rgba(255,255,255,.06) 80% 100%);
      mask: linear-gradient(#000,#000) content-box, linear-gradient(#000,#000);
      -webkit-mask-composite: xor; mask-composite: exclude; padding:1px; }
    .kpi.money{ border-color: rgba(22,163,74,.35) } .kpi.money .value{ color: var(--money) }
    .kpi.orders{ border-color: rgba(59,130,246,.35) } .kpi.orders .value{ color: var(--orders) }
    .kpi.users{ border-color: rgba(245,158,11,.35) } .kpi.users .value{ color: var(--users) }
    .kpi.sold{ border-color: rgba(167,139,250,.35) } .kpi.sold .value{ color: var(--sold) }
    .btn-neon{ background: linear-gradient(90deg, #22d3ee, #34d399, #60a5fa); color:#0b1220; border:none; font-weight:600;
      box-shadow:0 0 14px rgba(52,211,153,.35); transition: transform .15s ease, filter .15s ease, box-shadow .2s ease; }
    .btn-neon:hover{ transform: translateY(-1px); filter:brightness(1.05); box-shadow:0 0 22px rgba(96,165,250,.45) }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand fw-semibold" href="<?= base_url() ?>/admin/index.php">eSIM Admin</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarsExample">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link <?= nav_active('/admin/index.php') ?>" href="<?= base_url() ?>/admin/index.php">Produtos</a></li>
        <li class="nav-item"><a class="nav-link <?= nav_active('/admin/esims.php') ?>" href="<?= base_url() ?>/admin/esims.php">Estoque (eSIM)</a></li>
        <li class="nav-item"><a class="nav-link <?= nav_active('/admin/uploader.php') ?>" href="<?= base_url() ?>/admin/uploader.php">Upload</a></li>
        <li class="nav-item"><a class="nav-link <?= nav_active('/admin/orders.php') ?>" href="<?= base_url() ?>/admin/orders.php">Pedidos</a></li>
        <li class="nav-item"><a class="nav-link <?= nav_active('/admin/sales.php') ?>" href="<?= base_url() ?>/admin/sales.php">Últimas vendas</a></li>
        <li class="nav-item"><a class="nav-link <?= nav_active('/admin/users.php') ?>" href="<?= base_url() ?>/admin/users.php">Usuários</a></li>
        <li class="nav-item"><a class="nav-link <?= nav_active('/admin/coupons.php') ?>" href="<?= base_url() ?>/admin/coupons.php">Cupons</a></li>
        <li class="nav-item"><a class="nav-link <?= nav_active('/admin/notify.php') ?>" href="<?= base_url() ?>/admin/notify.php">Notificar</a></li>
        
      </ul>
      <span class="navbar-text"><a class="btn btn-sm btn-outline-light" href="<?= base_url() ?>/admin/logout.php">Sair</a></span>
    </div>
  </div>

<script>
(function(){
  var toggler = document.querySelector('.navbar-toggler');
  var target  = document.getElementById('navbarsExample');
  if (toggler && target && typeof bootstrap !== 'undefined') {
    var bs = bootstrap.Collapse.getOrCreateInstance(target, { toggle: false });
    toggler.addEventListener('click', function(ev){
      ev.preventDefault();
      bs.toggle();
    }, { passive:true });
    // Fecha ao clicar em qualquer link do menu (útil no mobile)
    target.querySelectorAll('a.nav-link').forEach(function(a){
      a.addEventListener('click', function(){
        if (getComputedStyle(toggler).display !== 'none') { bs.hide(); }
      }, { passive:true });
    });
  }
})();
</script>

</nav>
<div class="container my-4">
<script>
(function(){
  const path = location.pathname;
  document.querySelectorAll('.navbar .nav-link').forEach(a=>{
    if(a.getAttribute('href')===path){ a.classList.add('active'); }
  });
})();
</script>
