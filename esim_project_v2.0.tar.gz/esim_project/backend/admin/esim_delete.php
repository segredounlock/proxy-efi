<?php
require_once __DIR__ . '/../config.php'; require_login(); $pdo = db();
$id = (int)($_GET['id'] ?? 0);
if ($id) {
  // delete only if not assigned
  $st = $pdo->prepare("SELECT qr_path FROM esims WHERE id=? AND assigned_order_id IS NULL");
  $st->execute([$id]);
  if ($row = $st->fetch()) {
    $pdo->prepare("DELETE FROM esims WHERE id=?")->execute([$id]);
    // optional: remove file
    if (!empty($row['qr_path']) && strpos($row['qr_path'],'/uploads/')===0) {
      @unlink(__DIR__ . '/../' . ltrim($row['qr_path'],'/'));
    }
  }
}
header('Location: /admin/esims.php');
