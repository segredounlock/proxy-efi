<?php
require_once __DIR__ . '/../config.php'; require_login();
$pdo = db();
$products = $pdo->query("SELECT id, name FROM products ORDER BY name")->fetchAll();
include __DIR__ . '/_header.php';
?>
<style>
.neon-box{background:#0b1220;border:1px solid #1f2937;border-radius:16px;padding:24px;box-shadow:0 0 20px rgba(0,255,255,0.08) inset}
.dropzone{border:2px dashed #34d399;border-radius:12px;padding:28px;text-align:center;color:#a7f3d0;transition:.2s}
.dropzone.dragover{background:rgba(20,83,45,.2);border-color:#10b981;color:#d1fae5}
.progress-wrap{margin-top:16px;background:#0f172a;border-radius:12px;overflow:hidden;border:1px solid #374151}
.progress-bar{height:14px;width:0%;background:linear-gradient(90deg,#00e1ff,#00ffa3,#00e1ff);box-shadow:0 0 12px #00ffa3;transition:width .15s ease}
.progress-text{margin-top:8px;color:#93c5fd;font-weight:600;font-family:monospace;text-align:center}
.badge-soft{background:#1f2937;border:1px solid #374151;color:#9ca3af}
</style>

<div class="row">
  <div class="col-lg-6">
    <div class="card neon-box">
      <h4 class="mb-3">Adicionar estoque (eSIM QR)</h4>
      <div class="mb-3">
        <label class="form-label">Produto</label>
        <select id="product" class="form-select">
          <?php foreach($products as $p): ?>
            <option value="<?= $p['id'] ?>"><?= esc($p['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="mb-3">
        <label class="form-label">Texto/Código (opcional)</label>
        <textarea id="code_text" class="form-control" rows="2" placeholder="Cole aqui um código ou notas do eSIM (opcional)"></textarea>
      </div>
      <div id="dz" class="dropzone">
        Arraste e solte a imagem do QR aqui<br>ou clique para selecionar
        <input id="file" type="file" accept="image/*" style="display:none">
      </div>
      <div class="progress-wrap">
        <div id="bar" class="progress-bar"></div>
      </div>
      <div id="pt" class="progress-text">Aguardando arquivo…</div>
      <div class="mt-3 d-flex gap-2">
        <button id="btnUpload" class="btn btn-success">Enviar</button>
        <a href="/admin/esims.php" class="btn btn-outline-light">Ver Estoque</a>
      </div>
      <div id="msg" class="mt-3"></div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card neon-box">
      <h4 class="mb-3">Dicas</h4>
      <ul>
        <li>Você pode enviar várias vezes para adicionar múltiplas unidades.</li>
        <li>Formatos aceitos: PNG, JPG. Tamanho recomendado: &lt; 3MB.</li>
        <li>O arquivo é salvo em <code>/uploads/qr/</code> e referenciado em <code>esims.qr_path</code>.</li>
      </ul>
      <span class="badge badge-soft">Logs em tempo real são gravados em <code>/logs/upload_YYYYMMDD.log</code></span>
    </div>
  </div>
</div>

<script>
const dz = document.getElementById('dz');
const fileInput = document.getElementById('file');
const btn = document.getElementById('btnUpload');
const bar = document.getElementById('bar');
const pt  = document.getElementById('pt');
const msg = document.getElementById('msg');

let file;

dz.addEventListener('click', ()=> fileInput.click());
dz.addEventListener('dragover', e=>{ e.preventDefault(); dz.classList.add('dragover'); });
dz.addEventListener('dragleave', e=> dz.classList.remove('dragover'));
dz.addEventListener('drop', e=>{
  e.preventDefault(); dz.classList.remove('dragover');
  if (e.dataTransfer.files && e.dataTransfer.files[0]){
    file = e.dataTransfer.files[0];
    pt.textContent = 'Arquivo pronto: ' + file.name;
  }
});
fileInput.addEventListener('change', e=>{
  file = e.target.files[0];
  if (file) pt.textContent = 'Arquivo pronto: ' + file.name;
});

function setProgress(p){
  bar.style.width = p + '%';
  pt.textContent = 'Enviando: ' + p + '%';
}

btn.addEventListener('click', ()=>{
  if (!file){ msg.innerHTML = '<div class="text-warning">Selecione um arquivo primeiro.</div>'; return; }
  const product = document.getElementById('product').value;
  const code_text = document.getElementById('code_text').value;

  const fd = new FormData();
  fd.append('product_id', product);
  fd.append('code_text', code_text);
  fd.append('file', file);

  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/api/upload_esim.php');
  xhr.upload.onprogress = e=>{
    if (e.lengthComputable){
      const p = Math.round((e.loaded/e.total)*100);
      setProgress(p);
    }
  };
  xhr.onload = ()=>{
    try{
      const r = JSON.parse(xhr.responseText||'{}');
      if (xhr.status===200 && r.ok){
        setProgress(100);
        msg.innerHTML = '<div class="text-success">✅ Enviado! ID: '+r.id+' — <a class="link-light" href="'+r.qr_url+'" target="_blank">abrir imagem</a></div>';
      } else {
        msg.innerHTML = '<div class="text-danger">❌ Erro: '+(r.message||'falha')+'</div>';
      }
    }catch(e){
      msg.innerHTML = '<div class="text-danger">❌ Resposta inválida do servidor.</div>';
    }
  };
  xhr.onerror = ()=> msg.innerHTML = '<div class="text-danger">❌ Falha de rede.</div>';
  xhr.send(fd);
});
</script>

<?php include __DIR__ . '/_footer.php'; ?>
