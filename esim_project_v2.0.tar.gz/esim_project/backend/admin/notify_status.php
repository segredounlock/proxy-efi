<?php
declare(strict_types=1);

/**
 * admin/notify_status.php
 * - Retorna progresso + últimos logs para a UI (JSON)
 * GET: id (notification_id), last (ultimo log_id já visto)
 */

require_once __DIR__ . '/../config.php';
if (!function_exists('require_login')) {
  require_once __DIR__ . '/_bootstrap.php';
}
require_login();

header('Content-Type: application/json; charset=utf-8');

$id   = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$last = isset($_GET['last']) ? (int)$_GET['last'] : 0;
if ($id <= 0) { echo json_encode(['ok'=>false,'err'=>'id inválido']); exit; }

$pdo = db();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// situação geral
$st = $pdo->prepare("SELECT id, total, sent, fail, status FROM notifications WHERE id=:id LIMIT 1");
$st->execute([':id'=>$id]);
$N = $st->fetch(PDO::FETCH_ASSOC);
if (!$N) { echo json_encode(['ok'=>false,'err'=>'não encontrado']); exit; }

$total = (int)$N['total'];
$sent  = (int)$N['sent'];
$fail  = (int)$N['fail'];
$status= (string)$N['status'];

$pct = $total>0 ? round((($sent+$fail)/$total)*100, 1) : 0.0;

// logs “recentes” (usamos a própria tabela de recipients com um auto-id)
$logs = [];
$last_log_id = $last;

// Pegamos 50 mais recentes maiores que "last"
$q = $pdo->prepare("
  SELECT id, chat_id, status, last_error
  FROM notifications_recipients
  WHERE notification_id=:nid AND id>:last AND (status='sent' OR status='failed')
  ORDER BY id ASC
  LIMIT 50
");
$q->execute([':nid'=>$id, ':last'=>$last]);
while ($r = $q->fetch(PDO::FETCH_ASSOC)) {
  $cid = (string)$r['chat_id'];
  if ($r['status']==='sent') {
    $logs[] = '[✓] ' . $cid . ' -> ENVIADO';
  } else {
    $logs[] = '[x] ' . $cid . ' -> ERRO: ' . (string)$r['last_error'];
  }
  $last_log_id = (int)$r['id'];
}

echo json_encode([
  'ok'=>true,
  'total'=>$total,
  'sent'=>$sent,
  'fail'=>$fail,
  'status'=>$status,
  'pct'=>$pct,
  'logs'=>$logs,
  'last_log_id'=>$last_log_id
], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
