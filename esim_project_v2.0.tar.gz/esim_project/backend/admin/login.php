<?php
require_once __DIR__ . '/../config.php';
if (isset($_GET['force'])) { do_logout(); }
if (isset($_GET['force'])) { do_logout(); }
if (is_logged_in()) { header('Location: ' . base_url() . '/admin/index.php'); exit; }
$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['user'] ?? '');
    $p = trim($_POST['pass'] ?? '');
    if (do_login($u, $p)) { header('Location: ' . base_url() . '/admin/index.php'); exit; }
    $error = 'Usuário ou senha inválidos.';
}
?><!doctype html>
<html lang="pt-br"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login | Painel eSIM</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head><body class="bg-dark d-flex align-items-center" style="min-height:100vh;">
<div class="container"><div class="row justify-content-center"><div class="col-sm-10 col-md-6 col-lg-4">
<div class="card shadow-lg border-0"><div class="card-body p-4">
<h5 class="mb-3 text-center">Painel eSIM — Login</h5>
<?php if ($error): ?><div class="alert alert-danger py-2"><?=htmlspecialchars($error)?></div><?php endif; ?>
<form method="post" autocomplete="off">
  <div class="mb-3"><label class="form-label">Usuário</label><input name="user" class="form-control" required></div>
  <div class="mb-3"><label class="form-label">Senha</label><input name="pass" type="password" class="form-control" required></div>
  <button class="btn btn-primary w-100">Entrar</button>
</form>
<p class="mt-3 text-muted small text-center">Padrão: admin / admin123 (altere em auth.php)</p>
</div></div></div></div></div>
</body></html>