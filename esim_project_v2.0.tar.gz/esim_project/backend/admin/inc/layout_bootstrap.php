<?php
// inc/layout_bootstrap.php
declare(strict_types=1);

function _include_first(array $candidates): bool {
    foreach ($candidates as $f) {
        if (is_file($f)) { include_once $f; return true; }
    }
    return false;
}

function layout_header(string $title = 'Admin', string $section = ''): void {
    $base = dirname(__DIR__);
    $ok = _include_first([
        $base . '/inc/_auth.php',
    ]);
    $ok = _include_first([
        $base . '/inc/_header.php',
        $base . '/_header.php',
        $base . '/header.php',
    ]) || $ok;

    if (!$ok) {
        echo "<!doctype html><html lang='pt-BR'><head><meta charset='utf-8'>".
             "<meta name='viewport' content='width=device-width, initial-scale=1'>".
             "<title>".htmlspecialchars($title)."</title>".
             "<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css'>".
             "<style>body{background:#0b1220;color:#dbe7ff}.navbar{background:#0f1730}.container{max-width:1140px}</style>".
             "</head><body><nav class='navbar navbar-dark'><div class='container'><span class='navbar-brand'>eSIM Admin</span></div></nav><div class='container my-4'>";
    }

    $GLOBALS['PAGE_TITLE']  = $title;
    $GLOBALS['PAGE_SECTION']= $section;
}

function layout_footer(): void {
    $base = dirname(__DIR__);
    if (!_include_first([
        $base . '/inc/_footer.php',
        $base . '/_footer.php',
        $base . '/footer.php',
    ])) {
        echo "</div></body></html>";
    }
}
