<?php
require_once __DIR__ . '/../config.php'; require_login();
$pdo = db();
$op = $_POST['operator'] ?? ''; $name = $_POST['name'] ?? ''; $desc = $_POST['description'] ?? '';
$category = $_POST['category'] ?? 'ESIM'; $price = $_POST['price'] ?? '0';
$price_cents = (int)round(str_replace([',','.'],['','.'], $price)); // simples: 12,34 -> 1234
$stmt = $pdo->prepare("INSERT INTO products (operator,name,description,price_cents,category) VALUES (?,?,?,?,?)");
$stmt->execute([$op,$name,$desc,$price_cents,$category]);
header('Location: /admin/index.php');
