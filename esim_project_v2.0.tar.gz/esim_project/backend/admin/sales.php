<?php
// admin/sales.php — Listagem de vendas com busca (ID/chat_id/cupom), filtro de status e paginação,
// preservando o visual existente (usa os includes _header.php / _footer.php).

declare(strict_types=1);

require_once __DIR__ . '/../config.php'; require_login();


function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

// ------- parâmetros -------
$q       = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
$status  = isset($_GET['status']) ? trim((string)$_GET['status']) : '';
$page    = max(1, (int)($_GET['page'] ?? 1));
$per     = max(5, min(100, (int)($_GET['per'] ?? 25)));

// ------- SQL base -------
$pdo = db();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$where = [];
$params = [];

// Busca flexível: ID, chat_id ou cupom
if ($q !== '') {
  if (ctype_digit($q)) {
    // Numérico: pode ser id do pedido OU chat_id
    $where[] = '(o.id = :qid OR o.chat_id = :qchat)';
    $params[':qid'] = (int)$q;
    $params[':qchat'] = $q;
  } else {
    $where[] = '(o.coupon_code LIKE :qcup)';
    $params[':qcup'] = '%' . $q . '%';
  }
}

// Status (opcional)
$validStatuses = ['pending','paid','delivered','cancelled'];
if ($status !== '' && in_array($status, $validStatuses, true)) {
  $where[] = 'o.status = :st';
  $params[':st'] = $status;
}

$wsql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

// Contagem e total
$cntSql  = "SELECT COUNT(*) AS n, COALESCE(SUM(COALESCE(o.final_price_cents,o.price_cents,0)),0) AS cents
            FROM orders o
            JOIN products p ON p.id = o.product_id
            $wsql";
$tot = $pdo->prepare($cntSql);
$tot->execute($params);
$meta = $tot->fetch(PDO::FETCH_ASSOC) ?: ['n'=>0,'cents'=>0];
$totalRows   = (int)$meta['n'];
$totalAmount = (int)$meta['cents'];

$totalPages = max(1, (int)ceil($totalRows / $per));
$page = min($page, $totalPages);
$off = ($page - 1) * $per;

// Página de dados
$listSql = "SELECT o.*, p.name AS product_name
            FROM orders o
            JOIN products p ON p.id = o.product_id
            $wsql
            ORDER BY o.id DESC
            LIMIT :lim OFFSET :off";
$qry = $pdo->prepare($listSql);
foreach ($params as $k=>$v){
  $qry->bindValue($k, $v);
}
$qry->bindValue(':lim', $per, PDO::PARAM_INT);
$qry->bindValue(':off', $off, PDO::PARAM_INT);
$qry->execute();
$rows = $qry->fetchAll(PDO::FETCH_ASSOC);

// helper de status
function status_pt($s){
  if ($s === 'delivered') return 'ENTREGUE';
  if ($s === 'paid')      return 'PAGO';
  if ($s === 'pending')   return 'PENDENTE';
  return strtoupper((string)$s);
}

include __DIR__ . '/_header.php';
?>
<style>
.form-grid{display:grid;grid-template-columns: 1fr 220px 120px 100px;gap:10px;align-items:center;margin-bottom:12px}
@media (max-width: 720px){.form-grid{grid-template-columns:1fr}}
.badge{display:inline-block;padding:3px 8px;border-radius:8px;background:#223;color:#d0d6e0;font-size:12px}
.table th,.table td{vertical-align:middle}
</style>

<h2>Vendas</h2>

<form method="get" class="mb-3">
  <div class="form-grid">
    <input class="form-control" type="text" name="q"
           placeholder="ID, chat_id ou CUPOM..."
           value="<?php echo e($q); ?>">

    <select class="form-select" name="status" aria-label="Status">
      <option value="">Status (todos)</option>
      <?php
        foreach (['pending'=>'Pendente','paid'=>'Pago','delivered'=>'Entregue','cancelled'=>'Cancelado'] as $k=>$v){
          $sel = $status===$k ? ' selected' : '';
          echo "<option value='".e($k)."'$sel>".e($v)."</option>";
        }
      ?>
    </select>

    <button class="btn btn-primary" type="submit">Filtrar</button>
    <a class="btn btn-secondary" href="?">Limpar</a>
  </div>
</form>

<p><strong>Total de vendas:</strong> R$ <?php echo number_format($totalAmount/100,2,',','.'); ?></p>
<p class="text-muted">Registros: <?php echo (int)$totalRows; ?></p>

<div class="table-responsive">
<table class="table table-dark table-striped align-middle">
  <thead>
    <tr>
      <th>ID</th>
      <th>Produto</th>
      <th>Chat</th>
      <th>Valor</th>
      <th>Status</th>
      <th>Criado</th>
    </tr>
  </thead>
  <tbody>
  <?php if (!$rows): ?>
    <tr><td colspan="6" class="text-center text-muted">Nenhum registro.</td></tr>
  <?php else: foreach ($rows as $r): ?>
    <tr>
      <td>#<?php echo (int)$r['id']; ?></td>
      <td><?php echo e($r['product_name'] ?? '—'); ?></td>
      <td><?php echo e($r['chat_id'] ?? '—'); ?></td>
      <td>R$ <?php
        $cents = (int)($r['final_price_cents'] ?? $r['price_cents'] ?? 0);
        echo number_format($cents/100, 2, ',', '.');
      ?></td>
      <td><span class="badge"><?php echo e(status_pt($r['status'] ?? '')); ?></span></td>
      <td><?php echo e($r['created_at'] ?? ''); ?></td>
    </tr>
  <?php endforeach; endif; ?>
  </tbody>
</table>
</div>

<?php
// paginação
$base = '?'.http_build_query(array_merge($_GET, ['page'=>null]));
function page_link($p,$label,$disabled=false){
  global $base;
  $cls = 'btn btn-sm '.($disabled?'btn-secondary disabled':'btn-outline-light');
  $href = $disabled ? '#' : $base.'page='.$p;
  echo '<a class="'.$cls.'" href="'.e($href).'">'.e($label).'</a>';
}
?>
<div class="d-flex gap-2 align-items-center">
  <?php page_link(1, '« Primeira', $page<=1); ?>
  <?php page_link(max(1,$page-1), '‹ Anterior', $page<=1); ?>
  <span class="mx-2">Página <?php echo (int)$page; ?> / <?php echo (int)$totalPages; ?></span>
  <?php page_link(min($totalPages,$page+1), 'Próxima ›', $page>=$totalPages); ?>
  <?php page_link($totalPages, 'Última »', $page>=$totalPages); ?>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
