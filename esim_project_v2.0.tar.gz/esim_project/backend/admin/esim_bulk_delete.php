<?php
require_once __DIR__ . '/../config.php'; require_login(); $pdo = db();
$ids = $_POST['ids'] ?? [];
if ($ids && is_array($ids)) {
  $ids = array_map('intval',$ids);
  $in  = implode(',', array_fill(0, count($ids), '?'));
  // limit delete to not assigned
  $q = $pdo->prepare("SELECT id, qr_path FROM esims WHERE assigned_order_id IS NULL AND id IN ($in)");
  $q->execute($ids);
  $rows = $q->fetchAll();
  if ($rows) {
    $del = $pdo->prepare("DELETE FROM esims WHERE id IN ($in)");
    $del->execute($ids);
    foreach ($rows as $r) {
      if (!empty($r['qr_path']) && strpos($r['qr_path'],'/uploads/')===0) {
        @unlink(__DIR__ . '/../' . ltrim($r['qr_path'],'/'));
      }
    }
  }
}
header('Location: /admin/esims.php');
