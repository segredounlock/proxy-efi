<?php
require_once __DIR__ . '/../config.php'; require_login();
$pdo = db();
$id = (int)($_POST['id'] ?? 0); $name = $_POST['name'] ?? ''; $op = $_POST['operator'] ?? ''; $desc = $_POST['description'] ?? '';
$category = $_POST['category'] ?? 'ESIM';
$price = $_POST['price'] ?? '0'; $price_cents = (int)round(str_replace([',','.'],['','.'], $price));
$pdo->prepare("UPDATE products SET operator=?, name=?, description=?, price_cents=?, category=? WHERE id=?")->execute([$op,$name,$desc,$price_cents,$category,$id]);
header('Location: /admin/index.php');
