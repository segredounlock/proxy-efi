<?php
declare(strict_types=1);
require_once __DIR__ . '/../config.php';
if (!function_exists('require_login')) require_once __DIR__ . '/_bootstrap.php';
require_login();

header('Content-Type: application/json; charset=utf-8');

try{
  $pdo = db();
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $message    = trim((string)($_POST['message'] ?? ''));
  $parse_mode = ($_POST['parse_mode'] ?? 'HTML') === 'MarkdownV2' ? 'MarkdownV2' : 'HTML';
  $tps        = max(1, min(30, (int)($_POST['tps'] ?? 15)));
  $batch      = max(50, min(2000, (int)($_POST['batch'] ?? 500)));

  if($message==='') throw new Exception('Mensagem vazia.');

  // total distinct users
  $total = (int)$pdo->query("SELECT COUNT(DISTINCT chat_id) FROM users WHERE chat_id IS NOT NULL AND chat_id<>''")->fetchColumn();

  $pdo->beginTransaction();
  $st = $pdo->prepare("INSERT INTO notifications (message, parse_mode, total, sent, fail, status, started_at, created_at, updated_at)
                       VALUES (:m, :pm, :t, 0, 0, 'queued', NULL, NOW(), NOW())");
  $st->execute([':m'=>$message, ':pm'=>$parse_mode, ':t'=>$total]);
  $nid = (int)$pdo->lastInsertId();

  // enfileira destinatários em massa
  $pdo->exec("INSERT INTO notifications_recipients (notification_id, chat_id, status, attempt, created_at)
              SELECT {$nid}, u.chat_id, 'queued', 0, NOW()
              FROM (SELECT DISTINCT chat_id FROM users WHERE chat_id IS NOT NULL AND chat_id<>'') u");

  // salva parâmetros de execução na tabela notifications (opcional: guardamos nos campos extras via JSON)
  $pdo->exec("UPDATE notifications SET last_error=JSON_OBJECT('tps',$tps,'batch',$batch), updated_at=NOW() WHERE id={$nid}");
  $pdo->commit();

  // dispara o worker em background
  $php = PHP_BINARY ?: 'php';
  $cmd = escapeshellcmd($php).' '.escapeshellarg(__DIR__.'/notify_worker.php').' '.escapeshellarg((string)$nid).' > /dev/null 2>&1 &';
  @exec($cmd);

  echo json_encode(['ok'=>true,'notification_id'=>$nid,'total'=>$total]);
}catch(Throwable $e){
  if(!empty($pdo) && $pdo->inTransaction()) $pdo->rollBack();
  http_response_code(200);
  echo json_encode(['ok'=>false,'message'=>$e->getMessage()]);
}
