<?php
require_once __DIR__ . '/_bootstrap.php';
include __DIR__ . '/_header.php';
?>

<!-- fix: robust navbar toggle just for this page -->
<script>
(function(){
  var toggler = document.querySelector('.navbar-toggler');
  var target  = document.getElementById('navbarsExample');
  if (toggler && target && typeof bootstrap !== 'undefined') {
    var bs = bootstrap.Collapse.getOrCreateInstance(target, { toggle: false });
    toggler.addEventListener('click', function(ev){ ev.preventDefault(); bs.toggle(); }, { passive:true });
    target.querySelectorAll('a.nav-link').forEach(function(a){
      a.addEventListener('click', function(){ if (getComputedStyle(toggler).display !== 'none') { bs.hide(); } }, { passive:true });
    });
  }
})();
</script>

<?php
// ===== Back to PHP for data layer =====
$pdo = db();
try{
  $pdo->exec("CREATE TABLE IF NOT EXISTS coupons(
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(64) UNIQUE NOT NULL,
    discount_percent INT NULL,
    discount_cents INT NULL,
    max_uses INT DEFAULT 0,
    usage_count INT DEFAULT 0,
    active TINYINT(1) DEFAULT 1,
    expires_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
}catch(Throwable $e){}

$rows = $pdo->query("SELECT * FROM coupons ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container my-4">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <h4 class="mb-0">Cupons</h4>
    <button class="btn btn-neon btn-sm" data-bs-toggle="modal" data-bs-target="#couponModal">+ Novo Cupom</button>
  </div>

  <div class="card">
    <div class="table-responsive">
      <table class="table table-dark table-hover mb-0 align-middle">
        <thead>
          <tr>
            <th style="width:80px">ID</th>
            <th>Código</th>
            <th style="width:160px">Desconto</th>
            <th style="width:100px">Usos</th>
            <th style="width:120px">Status</th>
            <th style="width:160px">Expira</th>
            <th style="width:160px" class="text-end">Ações</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!$rows): ?>
            <tr><td colspan="7" class="text-center text-muted py-4">Nenhum cupom cadastrado.</td></tr>
          <?php else: foreach ($rows as $r): 
              $desc = $r['discount_percent'] !== null ? ($r['discount_percent'].'%') : (
                      $r['discount_cents'] !== null ? ('R$ '.number_format($r['discount_cents']/100, 2, ',', '.')) : '-'
              );
              $uses = ($r['usage_count'] ?? 0) . ($r['max_uses'] ? ' / '.$r['max_uses'] : '');
              $exp  = $r['expires_at'] ? date('d/m/Y H:i', strtotime($r['expires_at'])) : '—';
              $badge = $r['active'] ? '<span class="badge text-bg-success">Ativo</span>' : '<span class="badge text-bg-secondary">Inativo</span>';
          ?>
            <tr>
              <td>#<?= (int)$r['id'] ?></td>
              <td><code class="fw-semibold"><?= esc($r['code']) ?></code></td>
              <td><?= $desc ?></td>
              <td><?= $uses ?></td>
              <td><?= $badge ?></td>
              <td><?= $exp ?></td>
              <td class="text-end">
                <button class="btn btn-sm btn-outline-warning me-1" onclick="toggleCupom(<?= (int)$r['id'] ?>)">
                  <?= $r['active'] ? 'Desativar' : 'Ativar' ?>
                </button>
                <button class="btn btn-sm btn-outline-danger" onclick="delCupom(<?= (int)$r['id'] ?>)">Excluir</button>
              </td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal Novo Cupom -->
<div class="modal fade" id="couponModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content bg-dark text-light">
      <div class="modal-header border-0">
        <h5 class="modal-title">Novo Cupom</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="row g-3">
          <div class="col-12">
            <label class="form-label">Código</label>
            <input id="cCode" class="form-control" placeholder="PROMO10" maxlength="64">
          </div>
          <div class="col-md-6">
            <label class="form-label">Desconto (%)</label>
            <input id="cPercent" type="number" min="0" max="100" class="form-control" placeholder="ex.: 10">
            <div class="form-text">Deixe vazio se for em reais.</div>
          </div>
          <div class="col-md-6">
            <label class="form-label">Desconto (R$)</label>
            <input id="cValue" type="number" min="0" step="0.01" class="form-control" placeholder="ex.: 5,00">
            <div class="form-text">Deixe vazio se for percentual.</div>
          </div>
          <div class="col-md-6">
            <label class="form-label">Máx. usos</label>
            <input id="cMax" type="number" min="0" class="form-control" placeholder="0 = ilimitado">
          </div>
          <div class="col-md-6">
            <label class="form-label">Expira em</label>
            <input id="cExpires" type="datetime-local" class="form-control">
          </div>
          <div class="col-12 form-check mt-1">
            <input id="cActive" class="form-check-input" type="checkbox" checked>
            <label class="form-check-label">Ativo</label>
          </div>
        </div>
      </div>
      <div class="modal-footer border-0">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-neon" onclick="saveCupom()">Salvar</button>
      </div>
    </div>
  </div>
</div>

<script>
async function saveCupom(){
  const p = parseFloat((document.getElementById('cPercent').value||'').replace(',','.'));
  const v = parseFloat((document.getElementById('cValue').value||'').replace(',','.'));
  const body = {
    code: (document.getElementById('cCode').value||'').trim(),
    discount_percent: isFinite(p) ? Math.round(p) : null,
    discount_cents:  isFinite(v) ? Math.round(v * 100) : null,
    max_uses: parseInt(document.getElementById('cMax').value||'0', 10) || 0,
    active: document.getElementById('cActive').checked ? 1 : 0,
    expires_at: document.getElementById('cExpires').value || null
  };
  try{
    const r = await fetch('<?= BASE_URL ?>/api/coupons_save.php', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)
    });
    const j = await r.json();
    if(j.ok){ location.reload(); } else { alert(j.message||'Erro ao salvar'); }
  }catch(e){ alert('Falha ao salvar'); }
}

async function toggleCupom(id){
  try{
    const r = await fetch('<?= BASE_URL ?>/api/coupons_toggle.php', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({id})
    });
    const j = await r.json();
    if(j.ok){ location.reload(); } else { alert(j.message||'Falhou ao alternar'); }
  }catch(e){ alert('Falha ao alternar'); }
}

async function delCupom(id){
  if(!confirm('Excluir cupom?')) return;
  try{
    const r = await fetch('<?= BASE_URL ?>/api/coupons_delete.php', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({id})
    });
    const j = await r.json();
    if(j.ok){ location.reload(); } else { alert(j.message||'Falhou ao excluir'); }
  }catch(e){ alert('Falha ao excluir'); }
}
</script>

<?php include __DIR__ . '/_footer.php'; ?>
