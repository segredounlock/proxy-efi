<?php
// admin/header.php — navbar padronizada
if (!function_exists('esc')) {
  function esc($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
}
$uri = $_SERVER['REQUEST_URI'] ?? '';
function isActive(string $needle, string $uri): string {
  return (strpos($uri, $needle) !== false) ? 'active' : '';
}
?>
<!doctype html>
<html lang="pt-br" data-bs-theme="dark">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>eSIM Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    :root{
      --bg:#0b1220; --nav:#0f172a; --card:#0e1626; --card-border:#1e293b;
      --text:#e2e8f0; --muted:#94a3b8; --accent:#60a5fa; --glow: 0 0 12px rgba(96,165,250,.35);
      --success:#22c55e; --money:#16a34a; --orders:#3b82f6; --users:#f59e0b; --sold:#a78bfa;
    }
    @keyframes fadeIn {from{opacity:0; transform:translateY(6px)} to{opacity:1; transform:none}}
    body { background:var(--bg); color:var(--text); padding-top:72px }
    .navbar{ background:var(--nav); box-shadow:0 2px 12px rgba(0,0,0,.25) }
    .navbar .nav-link { color:#cbd5e1; transition:color .15s ease }
    .navbar .nav-link:hover { color:#fff }
    .navbar .nav-link.active { color:#fff; position:relative }
    .navbar .nav-link.active::after{
      content:''; position:absolute; left:8px; right:8px; bottom:-8px; height:3px;
      background: linear-gradient(90deg, #38bdf8, #a78bfa);
      border-radius:8px; box-shadow: var(--glow);
    }
    .card{ background:var(--card); border-color:var(--card-border); animation: fadeIn .25s ease both }
    .kpi{ border:1px solid var(--card-border); border-radius:16px; padding:16px; position:relative; overflow:hidden }
    .kpi .label{ font-size:.9rem; color:var(--muted) }
    .kpi .value{ font-size:1.8rem; font-weight:700 }
    .kpi::before{ content:''; position:absolute; inset:-1px; border-radius:16px; pointer-events:none;
      background: conic-gradient(from 180deg at 50% 50%, transparent 0 75%, rgba(255,255,255,.06) 80% 100%);
      mask: linear-gradient(#000,#000) content-box, linear-gradient(#000,#000);
      -webkit-mask-composite: xor; mask-composite: exclude; padding:1px; }
    .kpi.money{ border-color: rgba(22,163,74,.35) } .kpi.money .value{ color: var(--money) }
    .kpi.orders{ border-color: rgba(59,130,246,.35) } .kpi.orders .value{ color: var(--orders) }
    .kpi.users{ border-color: rgba(245,158,11,.35) } .kpi.users .value{ color: var(--users) }
    .kpi.sold{ border-color: rgba(167,139,250,.35) } .kpi.sold .value{ color: var(--sold) }
    .btn-neon{ background: linear-gradient(90deg, #22d3ee, #34d399, #60a5fa); color:#0b1220; border:none; font-weight:600;
      box-shadow:0 0 14px rgba(52,211,153,.35); transition: transform .15s ease, filter .15s ease, box-shadow .2s ease; }
    .btn-neon:hover{ transform: translateY(-1px); filter:brightness(1.05); box-shadow:0 0 22px rgba(96,165,250,.45) }
  </style>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand fw-semibold" href="/admin/index.php">eSIM Admin</a>
    
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link " href="/admin/products.php">Produtos</a></li>
        <li class="nav-item"><a class="nav-link " href="/admin/esims.php">Estoque (eSIM)</a></li>
        <li class="nav-item"><a class="nav-link " href="/admin/uploader.php">Upload</a></li>
        <li class="nav-item"><a class="nav-link active" href="/admin/orders.php">Pedidos</a></li>
        <li class="nav-item"><a class="nav-link " href="/admin/sales.php">Últimas vendas</a></li>
        <li class="nav-item"><a class="nav-link " href="/admin/users.php">Usuários</a></li>
        <li class="nav-item"><a class="nav-link " href="/admin/coupons.php">Cupons</a></li>
        <li class="nav-item"><a class="nav-link" href="notify.php">Notificar</a></li>

      </ul>
      <a href="/admin/logout.php" class="btn btn-outline-light btn-sm">Sair</a>
    </div>
  </div>
</nav>

    <main class="container my-4 container-page">

<style>
  /* mesma paleta do dashboard */
  .stat-card{background:#0c141f;border:1px solid rgba(255,255,255,.06);border-radius:14px;padding:22px}
  .stat-title{color:#9fb3c8;font-weight:600;margin-bottom:6px}
  .stat-value{font-size:28px;font-weight:800;letter-spacing:.3px}
  .stat-orange{border-color:#f59e0b33} .stat-orange .stat-value{color:#f59e0b}
  .stat-blue{border-color:#3b82f633}   .stat-blue .stat-value{color:#60a5fa}
  .stat-green{border-color:#10b98133}  .stat-green .stat-value{color:#34d399}
  .stat-purple{border-color:#8b5cf633} .stat-purple .stat-value{color:#a78bfa}

  .badge-soft-warning{background:rgba(245,158,11,.15);color:#f59e0b;border:1px solid rgba(245,158,11,.25)}
  .badge-soft-primary{background:rgba(59,130,246,.15);color:#60a5fa;border:1px solid rgba(59,130,246,.25)}
  .badge-soft-success{background:rgba(16,185,129,.15);color:#34d399;border:1px solid rgba(16,185,129,.25)}
  .badge-soft-secondary{background:rgba(148,163,184,.15);color:#cbd5e1;border:1px solid rgba(148,163,184,.25)}

  .form-control, .form-select{background:#0f1722;border-color:#1e293b;color:#cbd5e1}
  .table thead th{color:#9fb3c8;font-weight:700;border-bottom:1px solid #1f2a37}
  .table tbody td{vertical-align:middle;border-color:#15202e}
  .btn-filter{background:linear-gradient(90deg,#74a2ff,#b18cff);border:0}
  .btn-clear{background:#0f1722;border:1px solid #243244;color:#9fb3c8}
</style>

  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand fw-semibold" href="/admin/index.php">eSIM Admin</a>
    
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link <?= isActive('products',$uri) ?>" href="/admin/products.php">Produtos</a></li>
        <li class="nav-item"><a class="nav-link <?= isActive('esims',$uri) ?>" href="/admin/esims.php">Estoque (eSIM)</a></li>
        <li class="nav-item"><a class="nav-link <?= isActive('uploader',$uri) ?>" href="/admin/uploader.php">Upload</a></li>
        <li class="nav-item"><a class="nav-link <?= isActive('orders',$uri) ?>" href="/admin/orders.php">Pedidos</a></li>
        <li class="nav-item"><a class="nav-link <?= isActive('sales',$uri) ?>" href="/admin/sales.php">Últimas vendas</a></li>
        <li class="nav-item"><a class="nav-link <?= isActive('users',$uri) ?>" href="/admin/users.php">Usuários</a></li>
        <li class="nav-item"><a class="nav-link <?= isActive('coupons',$uri) ?>" href="/admin/coupons.php">Cupons</a></li>
      </ul>
      <a href="/admin/logout.php" class="btn btn-outline-light btn-sm">Sair</a>
    </div>
  </div>
</nav>

    <main class="container my-4 container-page">
