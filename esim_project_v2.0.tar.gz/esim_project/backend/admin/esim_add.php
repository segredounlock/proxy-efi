<?php
require_once __DIR__ . '/../config.php'; require_login();
$pdo = db();
$pid = (int)($_POST['product_id'] ?? 0);
$code = $_POST['code_text'] ?? null;
$qr_path = null;
if (!empty($_FILES['qr']['name'])) {
    $ext = pathinfo($_FILES['qr']['name'], PATHINFO_EXTENSION) ?: 'png';
    $fname = 'qr_' . time() . '_' . rand(1000,9999) . '.' . $ext;
    $dest = __DIR__ . '/../uploads/qr/' . $fname;
    @move_uploaded_file($_FILES['qr']['tmp_name'], $dest);
    $qr_path = '/uploads/qr/' . $fname;
}
$pdo->prepare("INSERT INTO esims (product_id, qr_path, code_text) VALUES (?,?,?)")->execute([$pid, $qr_path, $code]);
header('Location: /admin/index.php');
