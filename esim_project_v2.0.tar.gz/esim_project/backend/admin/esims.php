<?php 
declare(strict_types=1);
require_once __DIR__ . '/../config.php'; require_login();

// Página: Estoque (eSIM) — com busca + paginação preservando o visual
$title = 'Estoque (eSIM)';

// Helpers
function h(?string $s): string { return htmlspecialchars((string)$s ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function has_col(PDO $pdo, string $table, string $col): bool {
  try {
    $st = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE :c");
    $st->execute([':c'=>$col]);
    return (bool)$st->fetch(PDO::FETCH_ASSOC);
  } catch (Throwable $e) { return false; }
}

$pdo = db();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Carrega lista de produtos para o filtro
$products = [];
try {
  $r = $pdo->query("SELECT id, name FROM products ORDER BY name ASC");
  $products = $r->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $products = []; }

// Entrada (GET)
$q         = trim((string)($_GET['q'] ?? ''));              // id, code_text, nota etc.
$productId = (int)($_GET['product_id'] ?? 0);
$status    = trim((string)($_GET['status'] ?? ''));         // '', 'free', 'allocated'
$perPage   = max(5, min(200, (int)($_GET['per_page'] ?? 25)));
$page      = max(1, (int)($_GET['page'] ?? 1));

// WHERE dinâmico
$where = [];
$params = [];

if ($productId > 0) {
  $where[] = 'e.product_id = :pid';
  $params[':pid'] = $productId;
}
if ($q !== '') {
  // procura por ID exato, ou code_text/nota/qr_path "like"
  if (ctype_digit($q)) {
    $where[] = '(e.id = :idq OR e.assigned_order_id = :ido)';
    $params[':idq'] = (int)$q;
    $params[':ido'] = (int)$q;
  } else {
    // tenta em code_text, qr_path (se existirem)
    if (has_col($pdo,'esims','code_text')) {
      $where[] = 'e.code_text LIKE :q';
      $params[':q'] = '%'.$q.'%';
    } else if (has_col($pdo,'esims','note')) {
      $where[] = 'e.note LIKE :q';
      $params[':q'] = '%'.$q.'%';
    }
  }
}
if ($status === 'free') {
  $where[] = 'e.assigned_order_id IS NULL';
} else if ($status === 'allocated') {
  $where[] = 'e.assigned_order_id IS NOT NULL';
}

$wsql = $where ? ('WHERE '.implode(' AND ', $where)) : '';

// Total
$sqlCount = "SELECT COUNT(*) FROM esims e $wsql";
$stc = $pdo->prepare($sqlCount); $stc->execute($params);
$total = (int)$stc->fetchColumn();

$totalPages = max(1, (int)ceil($total / $perPage));
$page = min($page, $totalPages);
$offset = ($page-1)*$perPage;

// Query principal (inclui descrição do produto)
$sql = "SELECT e.*, p.name AS product_name, p.description AS product_description
        FROM esims e
        JOIN products p ON p.id = e.product_id
        $wsql
        ORDER BY e.id DESC
        LIMIT :lim OFFSET :off";
$st = $pdo->prepare($sql);
foreach ($params as $k=>$v) $st->bindValue($k, $v);
$st->bindValue(':lim', $perPage, PDO::PARAM_INT);
$st->bindValue(':off', $offset, PDO::PARAM_INT);
$st->execute();
$rows = $st->fetchAll(PDO::FETCH_ASSOC);

// Util para montar URL preservando filtros
function urlWith(array $merge): string {
  $base = $_GET;
  foreach ($merge as $k=>$v) {
    if ($v === null) unset($base[$k]); else $base[$k] = $v;
  }
  return '?'.http_build_query($base);
}

include __DIR__ . '/_header.php';
?>

<div class="container mt-3">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0">Estoque (eSIM)</h3>
    <a class="btn btn-sm btn-outline-secondary" href="esims.php">Limpar</a>
  </div>

  <form class="row g-2 mb-3" method="get" action="">
    <div class="col-md-5">
      <label class="form-label text-muted small">ID / Pedido / Código</label>
      <input type="text" class="form-control" name="q" value="<?=h($q)?>" placeholder="Ex.: 123 | 987 | ABC123">
    </div>
    <div class="col-md-3">
      <label class="form-label text-muted small">Produto</label>
      <select class="form-select" name="product_id">
        <option value="0">Todos</option>
        <?php foreach ($products as $p): ?>
          <option value="<?=$p['id']?>" <?= $productId===(int)$p['id']?'selected':''?>><?=h($p['name'])?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-2">
      <label class="form-label text-muted small">Status</label>
      <select class="form-select" name="status">
        <option value="" <?= $status===''?'selected':''?>>Todos</option>
        <option value="free" <?= $status==='free'?'selected':''?>>Livre</option>
        <option value="allocated" <?= $status==='allocated'?'selected':''?>>Alocado</option>
      </select>
    </div>
    <div class="col-md-2">
      <label class="form-label text-muted small">Por página</label>
      <input type="number" min="5" max="200" class="form-control" name="per_page" value="<?=h((string)$perPage)?>">
    </div>
    <div class="col-12">
      <button class="btn btn-primary me-2" type="submit">Filtrar</button>
      <a class="btn btn-outline-light" href="esims.php">Limpar</a>
    </div>
  </form>

  <div class="d-flex justify-content-between align-items-center mb-2">
    <div class="text-muted">Registros: <?=$total?> — Página <?=$page?>/<?=$totalPages?></div>
    <div class="btn-group">
      <a class="btn btn-sm btn-outline-light <?= $page<=1?'disabled':''?>" href="<?= $page<=1 ? '#' : urlWith(['page'=>1])?>">« Primeira</a>
      <a class="btn btn-sm btn-outline-light <?= $page<=1?'disabled':''?>" href="<?= $page<=1 ? '#' : urlWith(['page'=>$page-1])?>">‹ Anterior</a>
      <a class="btn btn-sm btn-outline-light <?= $page>=$totalPages?'disabled':''?>" href="<?= $page>=$totalPages ? '#' : urlWith(['page'=>$page+1])?>">Próxima ›</a>
      <a class="btn btn-sm btn-outline-light <?= $page>=$totalPages?'disabled':''?>" href="<?= $page>=$totalPages ? '#' : urlWith(['page'=>$totalPages])?>">Última »</a>
    </div>
  </div>

  <div class="table-responsive">
    <table class="table table-dark table-hover align-middle">
      <thead>
        <tr>
          <th style="width:90px">ID</th>
          <th>Produto</th>
          <th style="width:220px">Preview</th>
          <th>Code/Text</th>
          <th style="width:120px">Status</th>
          <th style="width:110px">Pedido</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$rows): ?>
          <tr><td colspan="6" class="text-center text-muted py-4">Nada encontrado</td></tr>
        <?php else: foreach ($rows as $r):
          $isAllocated = !empty($r['assigned_order_id']);
          $statusBadge = $isAllocated
            ? '<span class="badge bg-secondary">Alocado</span>'
            : '<span class="badge bg-success">Livre</span>';
          $qr = '';
          if (!empty($r['qr_path'])) {
            $qrUrl = '/'.ltrim($r['qr_path'],'/');
            $qr = '<img src="'.h($qrUrl).'" class="img-fluid rounded border" style="max-height:200px">';
          }
        ?>
        <tr>
          <td>#<?= (int)$r['id'] ?></td>
          <td>
            <div><strong><?= h($r['product_name'] ?? '') ?></strong></div>
            <?php if (!empty($r['product_description'])): ?>
              <div class="text-muted small"><?= h($r['product_description']) ?></div>
            <?php endif; ?>
          </td>
          <td><?= $qr ?></td>
          <td><?= h($r['code_text'] ?? ($r['note'] ?? '')) ?></td>
          <td><?= $statusBadge ?></td>
          <td><?= $isAllocated ? ('#'.(int)$r['assigned_order_id']) : '—' ?></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <div class="d-flex justify-content-between align-items-center mt-2">
    <div class="text-muted">Registros: <?=$total?> — Página <?=$page?>/<?=$totalPages?></div>
    <div class="btn-group">
      <a class="btn btn-sm btn-outline-light <?= $page<=1?'disabled':''?>" href="<?= $page<=1 ? '#' : urlWith(['page'=>1])?>">« Primeira</a>
      <a class="btn btn-sm btn-outline-light <?= $page<=1?'disabled':''?>" href="<?= $page<=1 ? '#' : urlWith(['page'=>$page-1])?>">‹ Anterior</a>
      <a class="btn btn-sm btn-outline-light <?= $page>=$totalPages?'disabled':''?>" href="<?= $page>=$totalPages ? '#' : urlWith(['page'=>$page+1])?>">Próxima ›</a>
      <a class="btn btn-sm btn-outline-light <?= $page>=$totalPages?'disabled':''?>" href="<?= $page>=$totalPages ? '#' : urlWith(['page'=>$totalPages])?>">Última »</a>
    </div>
  </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>
