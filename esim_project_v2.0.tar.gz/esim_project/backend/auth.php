<?php
// auth.php — apenas checa login, sem duplicar funções
require_once __DIR__ . '/config.php';

// não redireciona aqui; as páginas chamam require_login() explicitamente
