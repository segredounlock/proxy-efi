<?php
// tools/error_probe.php — mostra erros e testa DB
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
echo "<h2>Error Probe</h2>";
echo "<p>Se aparecer algo abaixo, é o erro real do PHP.</p>";
require_once __DIR__ . '/../config.php';
try {
  $pdo = db();
  echo "<div>DB OK</div>";
} catch (Throwable $e) {
  echo "<div style='color:#f66'>DB ERROR: ".htmlspecialchars($e->getMessage())."</div>";
}
echo '<hr><a href="/phpinfo.php" target="_blank">Abrir phpinfo()</a>';
