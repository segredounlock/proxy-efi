<?php
declare(strict_types=1);
require_once __DIR__ . '/../config.php';

function jpost(string $url, array $body): array {
  $ch=curl_init($url);
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,
    CURLOPT_HTTPHEADER=>['Content-Type: application/json'],
    CURLOPT_POSTFIELDS=>json_encode($body, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
    CURLOPT_TIMEOUT=>20, CURLOPT_CONNECTTIMEOUT=>10]);
  $res=curl_exec($ch); $err=curl_error($ch); curl_close($ch);
  if($err) throw new Exception($err);
  $jr=json_decode((string)$res,true); return is_array($jr)?$jr:[];
}

$endpoint = getenv('MXVPAY_STATUS_ENDPOINT') ?: 'https://mxvpay.com/api/transaction-status';
$mxvToken = getenv('MXVPAY_TOKEN'); $mxvSecret = getenv('MXVPAY_SECRET');
$base = rtrim((defined('BASE_URL')?BASE_URL:('https://'.($_SERVER['HTTP_HOST']??'localhost'))), '/');

$pdo=db();
$rows=$pdo->query("SELECT id, mxv_txid FROM orders WHERE status='pending' AND mxv_txid IS NOT NULL AND created_at >= (NOW()-INTERVAL 48 HOUR) ORDER BY id ASC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
foreach($rows as $r){
  $tx=$r['mxv_txid']; if(!$tx) continue;
  try{
    $jr=jpost($endpoint, ['token'=>$mxvToken,'secret'=>$mxvSecret,'idTransaction'=>$tx]);
    $st=strtolower((string)($jr['status']??''));
    if(in_array($st,['approved','confirmed','success','sucesso','paid','pago','concluido'],true)){
      jpost($base.'/api/orders_confirm.php', ['txid'=>$tx]);
    }
  }catch(Throwable $e){
    @file_put_contents(__DIR__.'/../logs/cron_reconcile_error.log', date('c')." TX={$tx} ERR=".$e->getMessage()."\n", FILE_APPEND);
  }
}
echo "ok\n";