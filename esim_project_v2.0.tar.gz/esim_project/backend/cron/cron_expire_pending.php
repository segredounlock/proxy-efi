<?php
declare(strict_types=1);
require_once __DIR__ . '/../config.php';
$minutes = (int)(getenv('ORDER_EXPIRE_MINUTES') ?: 120);
$pdo = db();
$st = $pdo->prepare("UPDATE orders SET status='expired', updated_at=NOW() WHERE status='pending' AND created_at < (NOW() - INTERVAL :m MINUTE)");
$st->execute([':m'=>$minutes]);
echo "expired_ok\n";