<?php
error_reporting(E_ALL); ini_set('display_errors','1');
echo "<pre>Healthcheck Lite\n\n";
try {
  require_once __DIR__ . '/config.php';
  echo "config.php: OK\n";
  $pdo = db();
  $row = $pdo->query("SELECT 1")->fetch();
  echo "DB: OK (" . implode(',', $row) . ")\n";
  echo "BOT_TOKEN len: " . strlen(BOT_TOKEN) . "\n";
  echo "API_BASE: " . API_BASE . "\n";
} catch (Throwable $e) {
  echo "ERRO: " . $e->getMessage() . "\n";
}
$log = __DIR__ . '/logs/php_error.log';
if (file_exists($log)) {
  echo "\n-- Últimas linhas do php_error.log --\n";
  $tail = @file($log);
  if ($tail) echo implode('', array_slice($tail, -30));
}
echo "</pre>";
