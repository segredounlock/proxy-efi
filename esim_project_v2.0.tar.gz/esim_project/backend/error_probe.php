<?php
/**
 * error_probe.php
 * Exibe rapidamente se a stack PHP/DB está ok e força um teste de include/require.
 */
header('Content-Type: text/plain; charset=utf-8');
echo "PHP: " . PHP_VERSION . "\n";
echo "Extensions: pdo=".(extension_loaded('pdo')?'yes':'no').", pdo_mysql=".(extension_loaded('pdo_mysql')?'yes':'no')."\n";

$okDb = false;
try {
  require_once __DIR__ . '/config.php';
  $pdo = db();
  $pdo->query('SELECT 1');
  $okDb = true;
} catch (Throwable $e) {
  echo "DB ERROR: " . $e->getMessage() . "\n";
}
echo "DB OK: " . ($okDb ? "yes" : "no") . "\n";

$files = ['index.php','admin/index.php','api/products.php','api/order_status.php','mxvpay/callback.php'];
foreach ($files as $f) {
  $p = __DIR__ . '/' . $f;
  echo $f . ': ' . (file_exists($p) ? 'found' : 'missing') . "\n";
}
