<?php
/**
 * config_patch_min.php
 * Ultra-conservador: NÃO mexe em nada do seu config.
 * Pode ser INCLUÍDO via require_once OU colado no FINAL do seu config.php existente.
 * Apenas garante TELEGRAM_BOT_TOKEN.
 */

if (!defined('TELEGRAM_BOT_TOKEN')) {
    $bot = getenv('BOT_TOKEN');
    if (!$bot || $bot === '') {
        // fallback – substitua se quiser pegar só do .env
        $bot = '8200009531:AAG9aRrqafER5DZjid4r9E3ZOGZDTHzrc2Q';
    }
    define('TELEGRAM_BOT_TOKEN', $bot);
}
