<?php
@ini_set('display_errors','0'); @ini_set('log_errors','1');
$__LOG_DIR = __DIR__ . '/logs'; if(!is_dir($__LOG_DIR)) @mkdir($__LOG_DIR,0777,true);
@ini_set('error_log',$__LOG_DIR.'/php_error.log');

if(!function_exists('__cfg_def')){ function __cfg_def($n,$v){ if(!defined($n)) define($n,$v); } }

/* === DB === */
__cfg_def('DB_HOST','localhost');
__cfg_def('DB_NAME','u740956130_esim');
__cfg_def('DB_USER','u740956130_esim');
__cfg_def('DB_PASS','@Segredo1994');
if(!isset($db_host)) $db_host=DB_HOST;
if(!isset($db_name)) $db_name=DB_NAME;
if(!isset($db_user)) $db_user=DB_USER;
if(!isset($db_pass)) $db_pass=DB_PASS;

if(!function_exists('db')){
  function db(){
    static $pdo=null; if($pdo instanceof PDO) return $pdo;
    $dsn='mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4';
    $pdo=new PDO($dsn,DB_USER,DB_PASS,[
      PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC
    ]);
    return $pdo;
  }
}
if(!function_exists('base_url')){
  function base_url(){
    $scheme=(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off')?'https':'http';
    $host=$_SERVER['HTTP_HOST'] ?? 'localhost';
    return rtrim("$scheme://$host",'/');
  }
}

# === NOVO: garante que BASE_URL existe como constante também ===
if (!defined('BASE_URL')) {
    define('BASE_URL', base_url());
}


/* === Telegram/Bot === */
__cfg_def('BOT_TOKEN','8200009531:AAG9aRrqafER5DZjid4r9E3ZOGZDTHzrc2Q');
@putenv('BOT_TOKEN='.BOT_TOKEN); $_ENV['BOT_TOKEN']=$_ENV['BOT_TOKEN'] ?? BOT_TOKEN;

/* === API & Branding === */
__cfg_def('API_BASE', base_url().'/api');
__cfg_def('STORE_TITLE','SEGREDOUNLOCK.COM');
__cfg_def('BRAND_URL','https://segredounlock.com');
__cfg_def('SUPPORT_URL','https://t.me/segredounlocker');
__cfg_def('HEADER_IMAGE_URL','https://www.pontobyte.com/wp-content/uploads/2024/12/Copia-de-byte-35.png');
__cfg_def('OPERADORAS','Claro - Cobertura nacional;TIM - 4G/5G de alta velocidade;Vivo - Melhor custo-benefício');

/* === MXVPay === */

// ===== MXVPay (PIX) =====
define('MXV_TOKEN',  'L1j7v3h904H6o101U8M2hChwi'); // <<< token que você já usava
define('MXV_SECRET', '91H7b3S9j4E691K1Y8V2qE0rx'); // <<< secret que você já usava
define('MXV_ENDPOINT', 'https://mxvpay.com/api/qrcode-pix');

// CPF fallback para pagador (se não for enviado pelo bot)
define('PAYER_CPF', '86070593510'); // <<< use um CPF válido se a conta MXV exigir

// Callback (usado na criação do PIX)
define('CALLBACK_URL', 'https://esim.buscalotter.com/mxvpay/callback.php');

// ===== Outras configs =====
date_default_timezone_set('America/Sao_Paulo');

/* === Guards (evita 500 se páginas esquecerem includes) === */
if (!function_exists('esc')) {
  function esc($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
  }
}
if (!function_exists('is_logged_in')) {
  function is_logged_in(): bool {
    if (session_status() === PHP_SESSION_NONE) { @session_start(); }
    return !empty($_SESSION['admin_logged']) && $_SESSION['admin_logged'] === true;
  }
}
if (!function_exists('require_login')) {
  function require_login(): void {
    if (!is_logged_in()) {
        header('Location: ' . base_url() . '/admin/login.php');
        exit;
    }
  }
}
if (!function_exists('do_login')) {
  function do_login(string $user, string $pass): bool {
    if (session_status() === PHP_SESSION_NONE) { @session_start(); }
    if ($user === 'admin' && $pass === '@Segredo1994') {
      $_SESSION['admin_logged'] = true;
      $_SESSION['admin_user']   = $user;
      return true;
    }
    return false;
  }
}
if (!function_exists('do_logout')) {
  function do_logout(): void {
    if (session_status() === PHP_SESSION_NONE) { @session_start(); }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
      $params = session_get_cookie_params();
      setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    @session_destroy();
  }
}
