<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');
write_log('coupons_valid', ['in'=>$_REQUEST, 'raw'=>file_get_contents('php://input')]);
$pdo = db();
$code = strtoupper(trim($_GET['code'] ?? ($_POST['code'] ?? '')));
$product_id = (int)($_GET['product_id'] ?? ($_POST['product_id'] ?? 0));
if (!$code || !$product_id){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'missing params']); exit; }

$c = $pdo->prepare("SELECT * FROM coupons WHERE code=?");
$c->execute([$code]);
$cup = $c->fetch();
if (!$cup || !$cup['active']) { echo json_encode(['ok'=>true,'valid'=>false,'reason'=>'inactive']); exit; }
if ($cup['expires_at'] && strtotime($cup['expires_at']) < time()) { echo json_encode(['ok'=>true,'valid'=>false,'reason'=>'expired']); exit; }
if ($cup['uses_max'] && $cup['uses_count'] >= $cup['uses_max']) { echo json_encode(['ok'=>true,'valid'=>false,'reason'=>'limit']); exit; }

$p = $pdo->prepare("SELECT price_cents FROM products WHERE id=?");
$p->execute([$product_id]);
$prod = $p->fetch();
if (!$prod) { http_response_code(404); echo json_encode(['ok'=>false,'error'=>'product not found']); exit; }

$price = (int)$prod['price_cents'];
$discount_cents = 0;
if ($cup['discount_type'] === 'percent') {
  $discount_cents = (int)round($price * (floatval($cup['value'])/100));
} else {
  $discount_cents = (int)round(floatval($cup['value'])*100);
}
$final_price_cents = max(0, $price - $discount_cents);
echo json_encode(['ok'=>true,'valid'=>true,'discount_cents'=>$discount_cents,'final_price_cents'=>$final_price_cents,'type'=>$cup['discount_type'],'value'=>$cup['value'],'code'=>$code]);

<?php /* end */ ?>