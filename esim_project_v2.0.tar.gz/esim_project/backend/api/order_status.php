<?php
// /api/order_status.php — seguro (sem recursion/loops) e inclui code_text do eSIM
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', '0');

function j($x){ return json_encode($x, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); }

try {
  // importa apenas a config (precisa expor função db())
  require_once __DIR__ . '/../config.php';
} catch (Throwable $e) {
  http_response_code(500);
  echo j(['ok'=>false,'message'=>'Falha ao incluir config.php']);
  exit;
}

try {
  $orderId = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
  if ($orderId <= 0) {
    http_response_code(400);
    echo j(['ok'=>false,'message'=>'order_id inválido']);
    exit;
  }

  $pdo = db();
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // Busca pedido + code_text do eSIM alocado
  $sql = "SELECT 
            o.id, o.status, o.product_id, o.chat_id, o.media_url, 
            o.paid_at, o.delivered,
            e.code_text
          FROM orders o
          LEFT JOIN esims e ON e.assigned_order_id = o.id
          WHERE o.id = :id
          LIMIT 1";
  $st = $pdo->prepare($sql);
  $st->execute([':id' => $orderId]);
  $row = $st->fetch(PDO::FETCH_ASSOC);

  if (!$row) {
    http_response_code(404);
    echo j(['ok'=>false,'message'=>'Pedido não encontrado']);
    exit;
  }

  $out = [
    'ok'         => true,
    'status'     => (string)$row['status'],
    'order_id'   => (int)$row['id'],
    'product_id' => (int)$row['product_id'],
    'chat_id'    => (string)$row['chat_id'],
    'media_url'  => $row['media_url'] ?: null,
    'paid_at'    => $row['paid_at'] ? date('Y-m-d H:i:s', strtotime($row['paid_at'])) : null,
    'delivered'  => (bool)$row['delivered'],
  ];
  if (!empty($row['code_text'])) {
    $out['code_text'] = $row['code_text']; // para o bot mostrar “Code/Text” no balão
  }

  echo j($out);
} catch (Throwable $e) {
  http_response_code(500);
  echo j(['ok'=>false,'message'=>$e->getMessage()]);
}
