<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';
try {
  $pdo = db();
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $raw = file_get_contents('php://input') ?: '';
  $b = json_decode($raw, true);
  if (!is_array($b)) $b = $_POST ?: $_GET;

  $orderId = isset($b['order_id']) ? (int)$b['order_id'] : 0;
  if (!$orderId) { echo json_encode(['ok'=>false,'message'=>'order_id obrigatório']); exit; }

  $pdo->prepare("UPDATE orders SET delivered=1, delivered_at=NOW() WHERE id=:id")->execute([':id'=>$orderId]);
  echo json_encode(['ok'=>true,'order_id'=>$orderId]);
} catch (Throwable $e) {
  echo json_encode(['ok'=>false,'message'=>$e->getMessage()]);
}
