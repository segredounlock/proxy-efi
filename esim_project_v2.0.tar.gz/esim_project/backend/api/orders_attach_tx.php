<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';
date_default_timezone_set('America/Sao_Paulo');

function api_log(string $msg): void {
    $dir = realpath(__DIR__ . '/../logs');
    if (!$dir) {
        @mkdir(__DIR__ . '/../logs', 0775, true);
        $dir = realpath(__DIR__ . '/../logs');
    }
    $file = $dir . '/api-' . date('Ymd') . '.log';
    @file_put_contents($file, '[' . date('H:i:s') . '] ' . $msg . PHP_EOL, FILE_APPEND);
}

function ensure_column(PDO $pdo, string $table, string $col, string $def): bool {
    $st = $pdo->prepare("SHOW COLUMNS FROM `{$table}` LIKE :c");
    $st->execute([':c' => $col]);
    if ($st->fetch()) return true;
    try {
        $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN {$def}");
        return true;
    } catch (Throwable $e) {
        api_log("ALTER TABLE falhou: " . $e->getMessage());
        return false;
    }
}

try {
    $pdo = db();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $raw  = file_get_contents('php://input') ?: '';
    $body = json_decode($raw, true);
    if (!is_array($body)) $body = $_POST ?: $_GET;

    $orderId = isset($body['order_id']) ? (int)$body['order_id'] : null;
    $txid    = isset($body['txid']) ? trim((string)$body['txid']) : null;

    if (!$orderId || !$txid) {
        echo json_encode(['ok'=>false,'message'=>'Parâmetros obrigatórios: order_id e txid']);
        exit;
    }

    if (!ensure_column($pdo, 'orders', 'mxv_txid', "`mxv_txid` VARCHAR(64) NULL UNIQUE")) {
        echo json_encode(['ok'=>false,'message'=>'Coluna mxv_txid ausente e não foi possível criar.']);
        exit;
    }

    $s = $pdo->prepare("SELECT id, mxv_txid FROM orders WHERE id=:id LIMIT 1");
    $s->execute([':id'=>$orderId]);
    $order = $s->fetch(PDO::FETCH_ASSOC);
    if (!$order) {
        echo json_encode(['ok'=>false,'message'=>'Pedido não encontrado']);
        exit;
    }

    if (!empty($order['mxv_txid'])) {
        if ($order['mxv_txid'] === $txid) {
            api_log("attach_tx: pedido {$orderId} já possui txid {$txid} (idempotente)");
            echo json_encode(['ok'=>true,'order_id'=>$orderId,'mxv_txid'=>$txid,'attached'=>false,'message'=>'Já anexado']);
            exit;
        }
        echo json_encode(['ok'=>false,'message'=>'Este pedido já possui outro txid associado']);
        exit;
    }

    $u = $pdo->prepare("UPDATE orders SET mxv_txid=:tx WHERE id=:id");
    $u->execute([':tx'=>$txid, ':id'=>$orderId]);

    api_log("attach_tx: pedido {$orderId} <- txid {$txid}");
    echo json_encode(['ok'=>true,'order_id'=>$orderId,'mxv_txid'=>$txid,'attached'=>true]);

} catch (Throwable $e) {
    api_log('EXCEPTION attach_tx: ' . $e->getMessage());
    echo json_encode(['ok'=>false,'message'=>'Erro interno: '.$e->getMessage()]);
}
