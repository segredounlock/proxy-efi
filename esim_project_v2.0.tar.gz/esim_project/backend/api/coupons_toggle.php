<?php
header('Content-Type: application/json; charset=utf-8');
\1require_once __DIR__ . '/../auth.php'; require_login(); $pdo = db();
function jsonBody(){
  $raw=file_get_contents('php://input');
  $j=json_decode($raw,true);
  return is_array($j)?$j:[];
}

try{
  $b=jsonBody(); $id=(int)($b['id']??0); if($id<=0){ echo json_encode(['ok'=>false,'message'=>'id invalido']); exit; }
  $st=$pdo->prepare("UPDATE coupons SET active=1-active WHERE id=:id");
  $st->execute([':id'=>$id]);
  echo json_encode(['ok'=>true]);
}catch(Throwable $e){ echo json_encode(['ok'=>false,'message'=>$e->getMessage()]); }
