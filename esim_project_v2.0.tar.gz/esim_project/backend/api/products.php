<?php
// /api/products.php — hotfix robusto
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';

$out = ['ok' => false, 'products' => []];

try {
    $pdo = db();

    // Consulta segura: traz id, name, operator, price_cents, category, stock atual
    $sql = "SELECT p.id, p.name, p.operator, p.price_cents, p.category,
                   COALESCE(SUM(CASE WHEN e.assigned_order_id IS NULL THEN 1 ELSE 0 END), 0) AS stock
            FROM products p
            LEFT JOIN esims e ON e.product_id = p.id
            GROUP BY p.id, p.name, p.operator, p.price_cents, p.category
            ORDER BY p.id ASC";
    $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

    $out['ok'] = true;
    $out['products'] = array_map(function($r){
        return [
            'id' => (int)$r['id'],
            'name' => $r['name'],
            'operator' => $r['operator'],
            'category' => $r['category'] ?: 'ESIM',
            'price_cents' => (int)$r['price_cents'],
            'stock' => (int)$r['stock'],
        ];
    }, $rows);

    if (function_exists('write_log')) write_log('products', ['count' => count($out['products'])]);
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    if (function_exists('write_log')) write_log('products', ['error' => $e->getMessage()]);
    http_response_code(500);
    echo json_encode(['ok'=>false, 'message'=>'erro interno'], JSON_UNESCAPED_UNICODE);
}
