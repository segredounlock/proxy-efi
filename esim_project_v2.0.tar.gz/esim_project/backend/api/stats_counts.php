<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';

/**
 * Retorna contagens para o dashboard: users, orders, revenue (paid), sold_esims.
 * Útil se quiser alimentar via ajax.
 */
try {
  $pdo = db();
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // garante tabela users
  $pdo->exec("CREATE TABLE IF NOT EXISTS `users` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `chat_id` VARCHAR(32) NOT NULL,
    `username` VARCHAR(64) NULL,
    `first_name` VARCHAR(64) NULL,
    `last_name` VARCHAR(64) NULL,
    `language_code` VARCHAR(16) NULL,
    `first_seen` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `last_seen` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_users_chat` (`chat_id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

  $users = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
  $orders = (int)$pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
  $revenue = (int)$pdo->query("SELECT COALESCE(SUM(final_price_cents),0) FROM orders WHERE status='paid'")->fetchColumn();
  $sold = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status='paid'")->fetchColumn();

  echo json_encode([
    'ok'=>true,
    'users'=>$users,
    'orders'=>$orders,
    'revenue_cents'=>$revenue,
    'sold_esims'=>$sold
  ]);

} catch (Throwable $e) {
  echo json_encode(['ok'=>false,'message'=>$e->getMessage()]);
}
