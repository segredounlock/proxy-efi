<?php
// /api/upload_esim.php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';
$out = ['ok'=>false];

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405); echo json_encode(['ok'=>false,'message'=>'method not allowed']); exit;
    }
    $pdo = db();
    $product_id = (int)($_POST['product_id'] ?? 0);
    $code_text  = trim($_POST['code_text'] ?? '');
    if (!$product_id) { throw new Exception('product_id obrigatório'); }

    // check product exists
    $st = $pdo->prepare("SELECT id FROM products WHERE id=?");
    $st->execute([$product_id]);
    if (!$st->fetch()) throw new Exception('Produto inválido');

    // file handling
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('Arquivo ausente ou com erro');
    }
    $f = $_FILES['file'];
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['png','jpg','jpeg'])) throw new Exception('Formato inválido');
    $name = uniqid('qr_', true).'.'.$ext;
    $destRel = '/uploads/qr/'.$name;
    $destAbs = __DIR__ . '/../uploads/qr/'.$name;
    if (!is_dir(dirname($destAbs))) @mkdir(dirname($destAbs), 0775, true);
    if (!move_uploaded_file($f['tmp_name'], $destAbs)) throw new Exception('Falha ao salvar arquivo');

    // insert stock row
    $q = $pdo->prepare("INSERT INTO esims (product_id, qr_path, code_text) VALUES (?,?,?)");
    $q->execute([$product_id, $destRel, $code_text]);
    $id = (int)$pdo->lastInsertId();

    if (function_exists('write_log')) write_log('upload', ['id'=>$id,'product_id'=>$product_id,'qr_path'=>$destRel]);

    $out = ['ok'=>true,'id'=>$id,'qr_path'=>$destRel,'qr_url'=> (defined('BASE_URL')? BASE_URL : '').$destRel ];
    echo json_encode($out); exit;
} catch (Throwable $e) {
    if (function_exists('write_log')) write_log('upload', ['error'=>$e->getMessage()]);
    http_response_code(400);
    echo json_encode(['ok'=>false,'message'=>$e->getMessage()]);
}
