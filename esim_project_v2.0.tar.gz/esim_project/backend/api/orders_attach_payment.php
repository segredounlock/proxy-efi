<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');
write_log('orders_attach', ['in'=>$_REQUEST, 'raw'=>file_get_contents('php://input')]);
$pdo = db();
$in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$order_id = (int)($in['order_id'] ?? 0);
$txid = (string)($in['txid'] ?? '');
$pix_code = (string)($in['pix_code'] ?? '');
$payload = json_encode($in, JSON_UNESCAPED_UNICODE);
if (!$order_id || !$txid) { http_response_code(400); echo json_encode(['ok'=>false,'error':'missing']); exit; }
$pdo->prepare("UPDATE orders SET txid=?, pix_code=?, payload_json=? WHERE id=?")->execute([$txid,$pix_code,$payload,$order_id]);
echo json_encode(['ok'=>true]);

<?php /* end */ ?>