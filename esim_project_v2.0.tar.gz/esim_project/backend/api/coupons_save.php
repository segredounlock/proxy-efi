<?php
header('Content-Type: application/json; charset=utf-8');
\1require_once __DIR__ . '/../auth.php'; require_login(); $pdo = db();
function jsonBody(){
  $raw=file_get_contents('php://input');
  $j=json_decode($raw,true);
  return is_array($j)?$j:[];
}

try{
  $b=jsonBody();
  $code=trim($b['code'] ?? '');
  if($code===''){ echo json_encode(['ok'=>false,'message'=>'Código obrigatório']); exit; }
  $percent = isset($b['discount_percent']) && $b['discount_percent']!=='' ? (int)$b['discount_percent'] : null;
  $cents   = isset($b['discount_cents'])   && $b['discount_cents']!==''   ? (int)$b['discount_cents']   : null;
  $max     = isset($b['max_uses']) ? (int)$b['max_uses'] : 0;
  $active  = !empty($b['active']) ? 1 : 0;
  $expires = !empty($b['expires_at']) ? $b['expires_at'] : null;

  $pdo->exec("CREATE TABLE IF NOT EXISTS coupons(
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(64) UNIQUE NOT NULL,
    discount_percent INT NULL,
    discount_cents INT NULL,
    max_uses INT DEFAULT 0,
    usage_count INT DEFAULT 0,
    active TINYINT(1) DEFAULT 1,
    expires_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

  $st=$pdo->prepare("INSERT INTO coupons(code,discount_percent,discount_cents,max_uses,active,expires_at)
                     VALUES(:c,:p,:v,:m,:a,:e)
                     ON DUPLICATE KEY UPDATE discount_percent=VALUES(discount_percent),
                                             discount_cents=VALUES(discount_cents),
                                             max_uses=VALUES(max_uses),
                                             active=VALUES(active),
                                             expires_at=VALUES(expires_at)");
  $st->execute([':c'=>$code,':p'=>$percent,':v'=>$cents,':m'=>$max,':a'=>$active,':e'=>$expires]);
  echo json_encode(['ok'=>true]);
}catch(Throwable $e){
  echo json_encode(['ok'=>false,'message'=>$e->getMessage()]);
}
