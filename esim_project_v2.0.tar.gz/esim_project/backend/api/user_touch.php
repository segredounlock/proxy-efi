<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';

/**
 * Endpoint para o bot "pingar" usuário no banco.
 * POST JSON: { chat_id, username?, first_name?, last_name?, language_code? }
 * - Cria o usuário se não existir
 * - Atualiza last_seen e dados básicos se já existir
 */
try {
  if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    echo json_encode(['ok'=>true,'message'=>'user_touch vivo','method'=>$_SERVER['REQUEST_METHOD'] ?? 'GET']);
    exit;
  }

  $pdo = db();
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // garante tabela users (create if not exists)
  $pdo->exec("CREATE TABLE IF NOT EXISTS `users` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `chat_id` VARCHAR(32) NOT NULL,
    `username` VARCHAR(64) NULL,
    `first_name` VARCHAR(64) NULL,
    `last_name` VARCHAR(64) NULL,
    `language_code` VARCHAR(16) NULL,
    `first_seen` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `last_seen` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_users_chat` (`chat_id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

  $raw = file_get_contents('php://input');
  $in  = json_decode($raw ?: '[]', true);
  $chat_id = isset($in['chat_id']) ? (string)$in['chat_id'] : '';
  if ($chat_id === '') { echo json_encode(['ok'=>false,'message'=>'chat_id obrigatório']); exit; }

  $username = isset($in['username']) ? (string)$in['username'] : null;
  $first    = isset($in['first_name']) ? (string)$in['first_name'] : null;
  $last     = isset($in['last_name']) ? (string)$in['last_name'] : null;
  $lang     = isset($in['language_code']) ? (string)$in['language_code'] : null;

  $stmt = $pdo->prepare("
    INSERT INTO users (chat_id, username, first_name, last_name, language_code, first_seen, last_seen)
    VALUES (:chat, :u, :f, :l, :lang, NOW(), NOW())
    ON DUPLICATE KEY UPDATE
      username = COALESCE(VALUES(username), username),
      first_name = COALESCE(VALUES(first_name), first_name),
      last_name = COALESCE(VALUES(last_name), last_name),
      language_code = COALESCE(VALUES(language_code), language_code),
      last_seen = NOW()
  ");
  $stmt->execute([':chat'=>$chat_id, ':u'=>$username, ':f'=>$first, ':l'=>$last, ':lang'=>$lang]);

  echo json_encode(['ok'=>true]);

} catch (Throwable $e) {
  echo json_encode(['ok'=>false,'message'=>$e->getMessage()]);
}
