<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config.php';

function j($x){ return json_encode($x, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); }

// extrai os 2 primeiros dígitos encontrados (DDD) do code_text
function first_ddb_from_code(?string $code): ?string {
  if (!$code) return null;
  if (preg_match('/\d{2}/', $code, $m)) return $m[0];
  return null;
}

try {
  $pdo = db();
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;
  $status     = isset($_GET['status']) ? trim((string)$_GET['status']) : 'free';
  $page       = max(1, (int)($_GET['page'] ?? 1));
  $per_page   = max(1, min(100, (int)($_GET['per_page'] ?? 5)));

  $where = [];
  $params = [];

  if ($product_id > 0) {
    $where[] = 'e.product_id = :pid';
    $params[':pid'] = $product_id;
  }
  if ($status === 'free') {
    $where[] = 'e.assigned_order_id IS NULL';
  } else if ($status === 'allocated') {
    $where[] = 'e.assigned_order_id IS NOT NULL';
  }

  $wsql = $where ? ('WHERE '.implode(' AND ', $where)) : '';

  // total para paginação
  $stc = $pdo->prepare("SELECT COUNT(*) FROM esims e $wsql");
  $stc->execute($params);
  $total = (int)$stc->fetchColumn();

  $total_pages = max(1, (int)ceil($total / $per_page));
  if ($page > $total_pages) $page = $total_pages;
  $offset = ($page - 1) * $per_page;

  // dados do produto (se filtrado por product_id)
  $product_info = null;
  if ($product_id > 0) {
    $sp = $pdo->prepare("SELECT id, name, description FROM products WHERE id = :pid LIMIT 1");
    $sp->execute([':pid' => $product_id]);
    if ($rowp = $sp->fetch(PDO::FETCH_ASSOC)) {
      $product_info = [
        'id' => (int)$rowp['id'],
        'name' => (string)($rowp['name'] ?? ''),
        'description' => (string)($rowp['description'] ?? '')
      ];
    }
  }

  // consulta principal — pode juntar com products para retornar nome/descrição também em cada item
  $sql = "SELECT e.id, e.product_id, e.code_text, e.qr_path, e.assigned_order_id
                , p.name AS product_name
                , p.description AS product_description
          FROM esims e
          LEFT JOIN products p ON p.id = e.product_id
          $wsql
          ORDER BY e.id DESC
          LIMIT :lim OFFSET :off";
  $st = $pdo->prepare($sql);
  foreach ($params as $k=>$v) $st->bindValue($k, $v);
  $st->bindValue(':lim', $per_page, PDO::PARAM_INT);
  $st->bindValue(':off', $offset, PDO::PARAM_INT);
  $st->execute();
  $rows = $st->fetchAll(PDO::FETCH_ASSOC);

  $esims = array_map(function($r){
    $assigned = array_key_exists('assigned_order_id', $r) ? $r['assigned_order_id'] : null;
    $code     = $r['code_text'] ?? null;
    return [
      'id' => (int)$r['id'],
      'product_id' => (int)$r['product_id'],
      'product_name' => $r['product_name'] ?? null,
      'product_description' => $r['product_description'] ?? null,
      'code_text' => $code,
      'ddd' => first_ddb_from_code($code), // novo campo
      'qr_path' => $r['qr_path'] ?? null,
      'assigned_order_id' => isset($assigned) ? (is_null($assigned) ? null : (int)$assigned) : null,
    ];
  }, $rows);

  echo j([
    'ok' => true,
    'product_id' => $product_id,
    'status' => $status,
    'page' => $page,
    'per_page' => $per_page,
    'total' => $total,
    'total_pages' => $total_pages,
    'product' => $product_info,   // metadata do produto quando filtrado
    'esims' => $esims,
  ]);

} catch (Throwable $e) {
  http_response_code(500);
  echo j(['ok'=>false, 'message'=>$e->getMessage()]);
}
