<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';
try {
  $raw=file_get_contents('php://input'); $in=json_decode($raw,true); if(!is_array($in)) $in=$_POST;
  $id = (int)($in['order_id'] ?? 0);
  if(!$id){ http_response_code(400); echo '{"ok":false}'; exit; }
  $pdo=db(); $st=$pdo->prepare("UPDATE orders SET notified=1, updated_at=NOW() WHERE id=:id"); $st->execute([':id'=>$id]);
  echo '{"ok":true}';
} catch (Throwable $e) { http_response_code(500); echo json_encode(['ok'=>false,'message'=>$e->getMessage()]); }