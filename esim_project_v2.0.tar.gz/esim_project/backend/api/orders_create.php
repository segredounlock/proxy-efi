<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config.php';

date_default_timezone_set('America/Sao_Paulo');

function api_log(string $msg): void {
    $dir = __DIR__ . '/../logs';
    if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
    @file_put_contents($dir.'/api-'.date('Ymd').'.log', '['.date('H:i:s')."] orders_create: {$msg}\n", FILE_APPEND);
}

function json_body(): array {
    $raw = file_get_contents('php://input') ?: '';
    $j = json_decode($raw, true);
    if (is_array($j)) return $j;
    if (!empty($_POST)) return $_POST;
    return [];
}

/* ===== Entrada ===== */
$in = json_body();
$product_id = isset($in['product_id']) ? (int)$in['product_id'] : 0;
$chat_id    = isset($in['chat_id']) ? trim((string)$in['chat_id']) : '';
$coupon     = isset($in['coupon']) ? trim((string)$in['coupon']) : null;
$splits     = isset($in['splits']) && is_array($in['splits']) ? $in['splits'] : null;

if ($product_id <= 0 || $chat_id === '') {
    http_response_code(200);
    echo json_encode(['ok'=>false,'message'=>'product_id e chat_id são obrigatórios']);
    exit;
}

try {
    $pdo = db();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Produto (usa price_cents da tabela)
    $st = $pdo->prepare("SELECT id, name, price_cents, operator, category FROM products WHERE id = :id LIMIT 1");
    $st->execute([':id'=>$product_id]);
    $prod = $st->fetch(PDO::FETCH_ASSOC);
    if (!$prod) {
        echo json_encode(['ok'=>false,'message'=>'Produto inexistente']);
        exit;
    }

    $price_cents = (int)($prod['price_cents'] ?? 0);
    if ($price_cents <= 0) $price_cents = 4000; // fallback seguro (R$ 40,00)
    $discount_cents = 0;                        // ajuste se for aplicar cupom
    $final_cents    = max(0, $price_cents - $discount_cents);

    // Cria pedido
    $pdo->beginTransaction();
    $ins = $pdo->prepare("
        INSERT INTO orders
            (chat_id, product_id, price_cents, status, created_at, updated_at, coupon_code, discount_cents, final_price_cents)
        VALUES
            (:chat, :pid, :price, 'pending', NOW(), NOW(), :coupon, :disc, :final)
    ");
    $ins->execute([
        ':chat'  => $chat_id,
        ':pid'   => $product_id,
        ':price' => $price_cents,
        ':coupon'=> $coupon,
        ':disc'  => $discount_cents,
        ':final' => $final_cents,
    ]);
    $order_id = (int)$pdo->lastInsertId();

    $amount_reais = number_format($final_cents / 100, 2, '.', ''); // "40.00"

    // Credenciais e dados obrigatórios MXVPay
    $token  = getenv('MXV_TOKEN')   ?: getenv('MXVPAY_TOKEN')   ?: 'L1j7v3h904H6o101U8M2hChwi';
    $secret = getenv('MXV_SECRET')  ?: getenv('MXVPAY_SECRET')  ?: '91H7b3S9j4E691K1Y8V2qE0rx';
    if (!$token || !$secret) {
        throw new Exception('Credenciais da MXVPay ausentes (MXV_TOKEN/MXV_SECRET).');
    }

    // CPF: use MXV_CPF no .env; fallback em CPF de teste válido "00000000191"
    $payerCpf = preg_replace('/\D+/', '', getenv('MXV_CPF') ?: getenv('PAYER_CPF') ?: '00000000191');
    if (strlen($payerCpf) !== 11) $payerCpf = '00000000191';

    $callback = getenv('CALLBACK_URL')
        ?: (rtrim(((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off')?'https':'http').'://'.($_SERVER['HTTP_HOST'] ?? 'localhost'),'/').'/mxvpay/callback.php');

    // Payload com campos que costumam ser exigidos
    $payload = [
        'token'        => $token,
        'secret'       => $secret,
        'amount'       => $amount_reais,                          // "40.00"
        'cpf'          => $payerCpf,                              // obrigatório
        'description'  => "Pedido #{$order_id} - {$prod['name']}",// ajuda a passar validação
        'reference'    => (string)$order_id,                      // referência externa
        'paymentType'  => 'pix',
        'url_callback' => $callback,
        // campos redundantes (se a API aceitar, ótimo; se ignorar, sem problemas):
        'payer_cpf'    => $payerCpf,
        'document'     => $payerCpf,
        'payer_document'=> $payerCpf,
        'payer_name'   => 'Cliente Telegram'
    ];
    if ($splits) $payload['splits'] = $splits;

    $endpoint = getenv('MXV_ENDPOINT') ?: getenv('MXVPAY_ENDPOINT') ?: 'https://mxvpay.com/api/qrcode-pix';

    // Chamada MXVPay
    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_TIMEOUT        => 25,
    ]);
    $res  = curl_exec($ch);
    $err  = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    api_log("order_id={$order_id} -> MXVPay {$code} err={$err} payload=".json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)." res={$res}");

    if ($err) throw new Exception("Erro CURL MXVPay: {$err}");

    $jr = json_decode((string)$res, true);
    if (!is_array($jr)) {
        throw new Exception("Resposta inválida da MXVPay");
    }
    if (empty($jr['status'])) {
        // Mostra mensagem de erro retornada pela MXVPay
        $msg = $jr['message'] ?? 'Falha ao gerar PIX';
        if (is_array($msg)) $msg = json_encode($msg, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        throw new Exception($msg);
    }

    $mxv_txid = (string)($jr['idTransaction']     ?? '');
    $qrcode   = (string)($jr['qrcode']            ?? '');
    $qr_img   = (string)($jr['qr_code_image_url'] ?? '');

    // Atualiza pedido
    $upd = $pdo->prepare("
        UPDATE orders
           SET mxv_txid = :tx, pix_code = :pix, payload_json = :payload, updated_at = NOW()
         WHERE id = :id
    ");
    $upd->execute([
        ':tx'      => $mxv_txid ?: null,
        ':pix'     => $qrcode   ?: null,
        ':payload' => json_encode($jr, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
        ':id'      => $order_id,
    ]);

    $pdo->commit();

    echo json_encode([
        'ok'                => true,
        'order_id'          => $order_id,
        'mxv_txid'          => $mxv_txid,
        'qrcode'            => $qrcode,
        'qr_code_image_url' => $qr_img,
        'price_cents'       => (int)$price_cents,
        'final_price_cents' => (int)$final_cents,
        'amount'            => $amount_reais,
        'status'            => 'pending',
    ], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) { $pdo->rollBack(); }
    api_log('ERRO: '.$e->getMessage());
    http_response_code(200);
    echo json_encode(['ok'=>false,'message'=>'Erro interno: '.$e->getMessage()] );
}
