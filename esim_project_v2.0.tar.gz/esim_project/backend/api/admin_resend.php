<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';
$pdo = db();
function jsonBody(){
  $raw=file_get_contents('php://input');
  $j=json_decode($raw,true);
  return is_array($j)?$j:[];
}

try{
  $b=jsonBody(); $order_id=(int)($b['order_id']??0);
  if($order_id<=0){ echo json_encode(['ok'=>false,'message'=>'order_id inválido']); exit; }
  $st=$pdo->prepare("SELECT chat_id, media_url FROM orders WHERE id=:id LIMIT 1");
  $st->execute([':id'=>$order_id]); $o=$st->fetch();
  if(!$o){ echo json_encode(['ok'=>false,'message':'pedido não encontrado']); exit; }
  if(empty($o['media_url'])){ echo json_encode(['ok'=>false,'message':'pedido não tem media_url']); exit; }
  $chat_id = $o['chat_id']; $media = $o['media_url'];

  // tenta obter token do config.php
  $tgToken = defined('TELEGRAM_BOT_TOKEN') ? TELEGRAM_BOT_TOKEN : getenv('TELEGRAM_BOT_TOKEN');
  if(!$tgToken){ echo json_encode(['ok'=>false,'message'=>'TELEGRAM_BOT_TOKEN não configurado no PHP']); exit; }

  $url="https://api.telegram.org/bot{$tgToken}/sendPhoto";
  $payload=['chat_id'=>$chat_id,'photo'=>$media,'caption'=>"Seu eSIM foi liberado!"];
  $ch=curl_init($url);
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_POSTFIELDS=>json_encode($payload)]);
  $resp=curl_exec($ch); $err=curl_error($ch); curl_close($ch);
  if($err){ echo json_encode(['ok'=>false,'message'=>$err]); exit; }
  $jr=json_decode($resp,true);
  echo json_encode(['ok'=>!empty($jr['ok']),'response'=>$jr]);
}catch(Throwable $e){ echo json_encode(['ok'=>false,'message'=>$e->getMessage()]); }
