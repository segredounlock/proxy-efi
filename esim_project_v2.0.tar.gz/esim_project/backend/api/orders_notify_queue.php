<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';
try {
  $pdo = db();
  $sql = "SELECT id, chat_id, status, media_url, qr_url, qr_path
          FROM orders
          WHERE notified = 0
            AND (status='delivered' OR (status='paid' AND (media_url IS NOT NULL OR qr_url IS NOT NULL OR qr_path IS NOT NULL)))
          ORDER BY id ASC LIMIT 50";
  $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
  $out = [];
  foreach ($rows as $r) {
    $media = $r['media_url'] ?? ($r['qr_url'] ?? null);
    if (!$media && !empty($r['qr_path'])) {
      $base = rtrim((defined('BASE_URL')?BASE_URL:('https://'.($_SERVER['HTTP_HOST']??'localhost'))), '/');
      $media = $base . '/' . ltrim($r['qr_path'],'/');
    }
    $out[] = ['order_id'=>(int)$r['id'], 'chat_id'=>(string)$r['chat_id'], 'status'=>$r['status'], 'media'=>$media];
  }
  echo json_encode(['ok'=>true, 'queue'=>$out], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) { http_response_code(500); echo json_encode(['ok'=>false,'message'=>$e->getMessage()]); }