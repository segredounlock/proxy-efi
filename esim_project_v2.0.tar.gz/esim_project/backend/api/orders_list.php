<?php
// /api/orders_list.php — lista pedidos por chat_id, com paginação opcional
// Retorna code_text a partir da tabela esims (LEFT JOIN), sem quebrar compatibilidade.

declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors','0');

function j($x){ return json_encode($x, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); }
function oc_log(string $file, string $msg): void {
  $dir = __DIR__ . '/../logs';
  if (!is_dir($dir)) @mkdir($dir, 0777, true);
  @file_put_contents($dir.'/'.$file, date('Y-m-d H:i:s ').$msg.PHP_EOL, FILE_APPEND);
}

try { require_once __DIR__ . '/../config.php'; }
catch (Throwable $e) { http_response_code(500); echo j(['ok'=>false,'message'=>'include config falhou']); exit; }

$chatId   = isset($_GET['chat_id']) ? trim((string)$_GET['chat_id']) : '';
$status   = isset($_GET['status'])   ? trim((string)$_GET['status'])   : '';
$page     = isset($_GET['page'])     ? max(1, (int)$_GET['page'])      : 1;
$perPage  = isset($_GET['per_page']) ? max(1, min(50,(int)$_GET['per_page'])) : 10;

if ($chatId === '') { http_response_code(400); echo j(['ok'=>false,'message'=>'chat_id obrigatório']); exit; }

try {
  $pdo = db();
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // Filtro base
  $where = ['o.chat_id = :chat'];
  $bind  = [':chat' => $chatId];
  if ($status !== '') { $where[] = 'o.status = :status'; $bind[':status'] = $status; }
  $whereSql = 'WHERE '.implode(' AND ', $where);

  // Total para paginação
  $sqlCount = "SELECT COUNT(*) FROM orders o {$whereSql}";
  $stc = $pdo->prepare($sqlCount);
  $stc->execute($bind);
  $total = (int)$stc->fetchColumn();

  $totalPages = (int)max(1, (int)ceil($total / $perPage));
  if ($page > $totalPages) { $page = $totalPages; }
  $offset = ($page - 1) * $perPage;

  // Lista com JOIN em products e esims
  $sql = "
    SELECT
      o.id,
      o.product_id,
      p.name AS product_name,
      o.status,
      o.media_url,
      o.price_cents,
      o.final_price_cents,
      o.paid_at,
      o.created_at,
      e.code_text AS code_text,
      e.qr_path   AS qr_path
    FROM orders o
    LEFT JOIN products p ON p.id = o.product_id
    LEFT JOIN esims    e ON e.assigned_order_id = o.id
    {$whereSql}
    ORDER BY o.id DESC
    LIMIT :limit OFFSET :offset
  ";

  $st = $pdo->prepare($sql);
  foreach ($bind as $k=>$v) { $st->bindValue($k, $v, is_int($v)?PDO::PARAM_INT:PDO::PARAM_STR); }
  $st->bindValue(':limit',  $perPage, PDO::PARAM_INT);
  $st->bindValue(':offset', $offset,  PDO::PARAM_INT);
  $st->execute();
  $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

  echo j([
    'ok'          => true,
    'page'        => $page,
    'per_page'    => $perPage,
    'total'       => $total,
    'total_pages' => $totalPages,
    'orders'      => $rows,
  ]);
} catch (Throwable $e) {
  oc_log('orders_list_error.log', $e->getMessage());
  http_response_code(500); echo j(['ok'=>false,'message'=>$e->getMessage()]);
}
