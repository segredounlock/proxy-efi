<?php
// track_user.php (exemplo)
require_once __DIR__.'/../config.php';
header('Content-Type: application/json; charset=utf-8');

$in = json_decode(file_get_contents('php://input'), true) ?: $_POST;

$chat_id = isset($in['chat_id']) ? trim((string)$in['chat_id']) : '';
if ($chat_id === '') { echo json_encode(['ok'=>false,'err'=>'chat_id vazio']); exit; }

$username = isset($in['username']) ? trim((string)$in['username']) : null;
$first    = isset($in['first_name']) ? trim((string)$in['first_name']) : null;
$last     = isset($in['last_name']) ? trim((string)$in['last_name']) : null;
$lang     = isset($in['language_code']) ? trim((string)$in['language_code']) : null;

$pdo = db();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// upsert por chat_id (UNIQUE recomendado em users.chat_id)
$pdo->prepare("
  INSERT INTO users (chat_id, username, first_name, last_name, language_code, first_seen, last_seen)
  VALUES (:chat, :user, :first, :last, :lang, NOW(), NOW())
  ON DUPLICATE KEY UPDATE
    username=VALUES(username),
    first_name=VALUES(first_name),
    last_name=VALUES(last_name),
    language_code=VALUES(language_code),
    last_seen=NOW()
")->execute([
  ':chat'=>$chat_id, ':user'=>$username, ':first'=>$first, ':last'=>$last, ':lang'=>$lang
]);

echo json_encode(['ok'=>true]);
