<?php
// /api/orders_confirm.php
// Confirma pagamento por TXID, aloca eSIM do estoque (tabela esims) e define media_url.
// NÃO envia mensagem no Telegram (removido para evitar duplicidade com o bot).

declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors','0');

function oc_log(string $file, string $msg): void {
  $dir = __DIR__ . '/../logs';
  if (!is_dir($dir)) @mkdir($dir, 0777, true);
  @file_put_contents($dir.'/'.$file, date('Y-m-d H:i:s ').$msg.PHP_EOL, FILE_APPEND);
}
function j($x){ return json_encode($x, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); }

// === Carrega .env da raiz (simples) ===
$envFile = __DIR__ . '/../.env';
if (file_exists($envFile)) {
  foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
    if ($line === false) continue;
    $line = trim($line);
    if ($line === '' || str_starts_with($line, '#')) continue;
    $parts = explode('=', $line, 2);
    if (count($parts) === 2) {
      $name = trim($parts[0]); $value = trim($parts[1]);
      if ($name !== '' && !getenv($name)) { putenv($name.'='.$value); }
    }
  }
}

try { require_once __DIR__ . '/../config.php'; }
catch (Throwable $e) {
  oc_log('orders_confirm_error.log','FATAL include config: '.$e->getMessage());
  http_response_code(500);
  echo j(['ok'=>false,'message'=>'include config falhou']);
  exit;
}

try {
  $raw = file_get_contents('php://input');
  $in  = json_decode($raw, true);
  if (!is_array($in)) $in = $_POST;

  $txid = trim((string)($in['txid'] ?? $in['idTransaction'] ?? ''));
  if ($txid === '') {
    http_response_code(400);
    echo j(['ok'=>false,'message'=>'txid ausente']);
    exit;
  }

  $pdo = db();
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // Busca pedido por TXID
  $q = $pdo->prepare("SELECT * FROM orders WHERE mxv_txid = :tx LIMIT 1");
  $q->execute([':tx'=>$txid]);
  $order = $q->fetch(PDO::FETCH_ASSOC);
  if (!$order) {
    http_response_code(404);
    echo j(['ok'=>false,'message'=>'pedido não encontrado']);
    exit;
  }

  // Idempotência: se já entregue, retorna estado atual
  if ($order['status'] === 'delivered' || (isset($order['delivered']) && (int)$order['delivered'] === 1)) {
    echo j([
      'ok'        => true,
      'id'        => (int)$order['id'],
      'status'    => $order['status'],
      'media_url' => $order['media_url'],
      'idempotent'=> true
    ]);
    exit;
  }

  $pdo->beginTransaction();

  // Marca como pago
  $pdo->prepare("UPDATE orders SET status='paid', paid_at=NOW(), updated_at=NOW() WHERE id=:id")
      ->execute([':id'=>$order['id']]);

  // Seleciona eSIM LIVRE do mesmo product_id com trava de linha
  $sel = $pdo->prepare("
    SELECT id, product_id, qr_path, code_text
    FROM esims
    WHERE product_id = :pid AND assigned_order_id IS NULL
    ORDER BY id ASC
    LIMIT 1 FOR UPDATE
  ");
  $sel->execute([':pid'=>$order['product_id']]);
  $esim = $sel->fetch(PDO::FETCH_ASSOC);

  if (!$esim) {
    $pdo->rollBack();
    http_response_code(409);
    echo j(['ok'=>false,'message'=>'Sem eSIM livre no estoque para este produto']);
    exit;
  }

  // Aloca o eSIM no pedido
  $pdo->prepare("UPDATE esims SET assigned_order_id = :oid WHERE id = :id")
      ->execute([':oid'=>$order['id'], ':id'=>$esim['id']]);

  // Monta URL do QR a partir do qr_path (NÃO usa quickchart)
  $base = rtrim(
    (defined('BASE_URL') && BASE_URL ? BASE_URL : ('https://'.($_SERVER['HTTP_HOST'] ?? 'localhost'))),
    '/'
  );
  $qr_path   = ltrim((string)$esim['qr_path'], '/');
  $media_url = $base . '/' . $qr_path;

  // Atualiza pedido -> delivered
  $pdo->prepare("
    UPDATE orders
       SET status='delivered',
           delivered=1,
           delivered_at=NOW(),
           media_url=:m,
           updated_at=NOW()
     WHERE id=:id
  ")->execute([':id'=>$order['id'], ':m'=>$media_url]);

  $pdo->commit();

  // >>> Removido o envio ao Telegram aqui para evitar DUPLICIDADE <<<
  // O bot é quem enviará a mensagem única: "Pedido #<id>\nStatus: DELIVERED"

  echo j([
    'ok'        => true,
    'id'        => (int)$order['id'],
    'status'    => 'delivered',
    'media_url' => $media_url
  ]);
} catch (Throwable $e) {
  oc_log('orders_confirm_error.log', 'EX: '.$e->getMessage());
  http_response_code(500);
  echo j(['ok'=>false,'message'=>$e->getMessage()]);
}
