<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config.php';

date_default_timezone_set('America/Sao_Paulo');

function resp($arr){ echo json_encode($arr, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }

try {
    $pdo = db();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Garantir tabela (idempotente)
    $pdo->exec("CREATE TABLE IF NOT EXISTS `users` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `chat_id` BIGINT NOT NULL UNIQUE,
        `username` VARCHAR(64) NULL,
        `first_name` VARCHAR(128) NULL,
        `last_name` VARCHAR(128) NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uniq_chat` (`chat_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Recebe JSON ou form
    $raw = file_get_contents('php://input') ?: '';
    $in = json_decode($raw, true);
    if (!is_array($in)) $in = $_POST;

    $chat_id   = isset($in['chat_id']) ? trim((string)$in['chat_id']) : '';
    $username  = isset($in['username']) ? trim((string)$in['username']) : null;
    $firstName = isset($in['first_name']) ? trim((string)$in['first_name']) : null;
    $lastName  = isset($in['last_name']) ? trim((string)$in['last_name']) : null;

    if ($chat_id === '') {
        resp(['ok'=>false,'message'=>'chat_id é obrigatório']);
    }

    // UPSERT via ON DUPLICATE KEY
    $st = $pdo->prepare("INSERT INTO users (chat_id, username, first_name, last_name)
                         VALUES (:chat_id, :username, :first_name, :last_name)
                         ON DUPLICATE KEY UPDATE
                           username = VALUES(username),
                           first_name = VALUES(first_name),
                           last_name = VALUES(last_name),
                           updated_at = CURRENT_TIMESTAMP");
    $st->execute([
        ':chat_id' => $chat_id,
        ':username'=> $username,
        ':first_name'=> $firstName,
        ':last_name'=> $lastName,
    ]);

    // Busca ID
    $q = $pdo->prepare("SELECT id FROM users WHERE chat_id = :chat LIMIT 1");
    $q->execute([':chat'=>$chat_id]);
    $row = $q->fetch(PDO::FETCH_ASSOC);
    $uid = $row ? (int)$row['id'] : null;

    resp(['ok'=>true,'user_id'=>$uid]);
} catch (Throwable $e) {
    http_response_code(200);
    resp(['ok'=>false,'message'=>'Erro: '.$e->getMessage()]);
}
