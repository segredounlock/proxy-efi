# 📦 Guia de Instalação

## Pré-requisitos

- PHP 7.4+
- MySQL 5.7+
- Node.js 16+
- Servidor web (Apache/Nginx)

---

## 1️⃣ Banco de Dados

```bash
# Criar banco
mysql -u root -p -e "CREATE DATABASE u740956130_esim CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# Criar usuário
mysql -u root -p -e "CREATE USER 'u740956130_esim'@'localhost' IDENTIFIED BY '@Segredo1994';"

# Dar permissões
mysql -u root -p -e "GRANT ALL PRIVILEGES ON u740956130_esim.* TO 'u740956130_esim'@'localhost';"

# Importar schema
mysql -u u740956130_esim -p@Segredo1994 u740956130_esim < database/esim.sql
```

---

## 2️⃣ Backend PHP

```bash
# Upload para servidor
cd backend
# Configurar permissões
chmod 755 -R .
chmod 777 logs uploads

# Editar config.php
nano config.php
# Ajustar DB_HOST, DB_NAME, DB_USER, DB_PASS
```

### Testar conexão:
```
https://seu-dominio.com/healthcheck-lite.php
```

---

## 3️⃣ Bot Telegram

```bash
cd bot

# Instalar dependências
npm install

# Configurar .env
nano .env

# Iniciar bot
npm start

# Ou com PM2 (produção)
npm install -g pm2
pm2 start src/index.js --name esim-bot
pm2 save
pm2 startup
```

---

## 4️⃣ Webhook MXVPay

Configurar callback no MXVPay:
```
https://seu-dominio.com/mxvpay/callback.php
```

---

## 5️⃣ Webhook Telegram (Opcional)

```bash
# Se usar webhook ao invés de polling
curl "https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://seu-dominio.com/telegram/webhook.php"
```

---

## 6️⃣ Verificação

### ✅ Backend
```bash
curl https://seu-dominio.com/api/produtos.php
```

### ✅ Bot
```
/start no Telegram
```

### ✅ Admin
```
https://seu-dominio.com/admin
```

---

## 🔧 Problemas Comuns

### Bot não responde
- Verificar BOT_TOKEN
- Verificar API_BASE
- Ver logs: `pm2 logs esim-bot`

### Erro 500 no backend
- Verificar permissões
- Ver `logs/php_error.log`
- Testar conexão DB

### PIX não gera
- Verificar MXVPAY_TOKEN
- Verificar MXVPAY_SECRET
- Ver logs MXVPay

---

## 📞 Suporte

Problemas? Verifique:
1. Logs do bot (`pm2 logs`)
2. Logs PHP (`backend/logs/`)
3. Logs MySQL (`/var/log/mysql/`)
