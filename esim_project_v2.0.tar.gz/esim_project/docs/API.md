# 📡 Documentação da API

Base URL: `https://seu-dominio.com/api`

---

## 🔹 Produtos

### GET `/produtos.php`
Lista produtos (operadoras) disponíveis

**Response:**
```json
{
  "ok": true,
  "data": [
    {
      "id": 1,
      "name": "Claro",
      "price": "25.00",
      "description": "Cobertura nacional",
      "stock_count": 150
    }
  ]
}
```

---

## 🔹 Estoque

### GET `/stock_by_product.php?product_id=1`
Consulta estoque por produto

**Response:**
```json
{
  "ok": true,
  "product_id": 1,
  "available": 150
}
```

---

## 🔹 Pedidos

### POST `/orders_create.php`
Cria novo pedido

**Request:**
```json
{
  "chat_id": "123456789",
  "product_id": 1,
  "coupon_code": "DESC10"
}
```

**Response:**
```json
{
  "ok": true,
  "order_id": 42,
  "pix": {
    "qrcode": "00020126580014br.gov.bcb.pix...",
    "amount": "22.50",
    "expires_at": "2025-11-23T10:30:00Z"
  }
}
```

---

## 🔹 Status do Pedido

### GET `/order_status.php?order_id=42`
Verifica status do pedido

**Response:**
```json
{
  "ok": true,
  "order": {
    "id": 42,
    "status": "paid",
    "esim_qr": "LPA:1$smdp.gsma.com$...",
    "esim_code": "ABC123XYZ789"
  }
}
```

**Status possíveis:**
- `pending` - Aguardando pagamento
- `paid` - Pago
- `delivered` - Entregue
- `cancelled` - Cancelado
- `expired` - Expirado

---

## 🔹 Histórico

### GET `/orders_by_chat.php?chat_id=123456789`
Lista pedidos do usuário

**Response:**
```json
{
  "ok": true,
  "orders": [
    {
      "id": 42,
      "product_name": "Claro",
      "status": "delivered",
      "created_at": "2025-11-23 08:15:00"
    }
  ]
}
```

---

## 🔹 Usuários

### POST `/track_user.php`
Registra/atualiza usuário

**Request:**
```json
{
  "chat_id": "123456789",
  "username": "joao",
  "first_name": "João",
  "last_name": "Silva"
}
```

**Response:**
```json
{
  "ok": true
}
```

---

## 🔹 Webhook MXVPay

### POST `/mxvpay/callback.php`
Callback de pagamento PIX

**Request (MXVPay):**
```json
{
  "external_reference": "42",
  "status": "paid",
  "transaction_amount": 22.50
}
```

**Ações:**
1. Valida assinatura
2. Atualiza status do pedido
3. Reserva eSIM do estoque
4. Envia eSIM para usuário
5. Retorna 200 OK

---

## 🔒 Autenticação

APIs públicas (não requerem auth):
- `/produtos.php`
- `/stock_by_product.php`
- `/orders_create.php`
- `/order_status.php`
- `/orders_by_chat.php`
- `/track_user.php`

Webhook:
- `/mxvpay/callback.php` - Valida signature

Admin:
- Requer sessão PHP logada

---

## 📊 Códigos de Erro

- `200` - Sucesso
- `400` - Requisição inválida
- `404` - Não encontrado
- `500` - Erro interno

**Formato:**
```json
{
  "ok": false,
  "error": "Mensagem de erro"
}
```

---

## 🧪 Testes

### cURL Examples:

```bash
# Listar produtos
curl https://seu-dominio.com/api/produtos.php

# Consultar estoque
curl https://seu-dominio.com/api/stock_by_product.php?product_id=1

# Criar pedido
curl -X POST https://seu-dominio.com/api/orders_create.php \
  -H "Content-Type: application/json" \
  -d '{"chat_id":"123","product_id":1}'

# Status pedido
curl https://seu-dominio.com/api/order_status.php?order_id=42
```
