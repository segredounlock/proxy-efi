#!/bin/bash
###############################################################################
# Setup Script - Sistema eSIM
# Configura ambiente completo
###############################################################################

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   SETUP - SISTEMA ESIM COMPLETO      ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════╝${NC}"
echo ""

# 1. Verificar requisitos
echo -e "${YELLOW}[1/5] Verificando requisitos...${NC}"

if ! command -v php &> /dev/null; then
    echo -e "${RED}✗ PHP não instalado${NC}"
    exit 1
fi
echo -e "${GREEN}✓ PHP $(php -v | head -n1 | cut -d' ' -f2)${NC}"

if ! command -v mysql &> /dev/null; then
    echo -e "${RED}✗ MySQL não instalado${NC}"
    exit 1
fi
echo -e "${GREEN}✓ MySQL instalado${NC}"

if ! command -v node &> /dev/null; then
    echo -e "${RED}✗ Node.js não instalado${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Node.js $(node -v)${NC}"

# 2. Configurar banco de dados
echo ""
echo -e "${YELLOW}[2/5] Configurando banco de dados...${NC}"

read -p "MySQL root password: " -s MYSQL_ROOT_PASS
echo ""

mysql -u root -p"$MYSQL_ROOT_PASS" <<EOF
CREATE DATABASE IF NOT EXISTS u740956130_esim CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'u740956130_esim'@'localhost' IDENTIFIED BY '@Segredo1994';
GRANT ALL PRIVILEGES ON u740956130_esim.* TO 'u740956130_esim'@'localhost';
FLUSH PRIVILEGES;
EOF

echo -e "${GREEN}✓ Banco criado${NC}"

mysql -u u740956130_esim -p@Segredo1994 u740956130_esim < ../database/esim.sql
echo -e "${GREEN}✓ Schema importado${NC}"

# 3. Backend PHP
echo ""
echo -e "${YELLOW}[3/5] Configurando backend...${NC}"

cd ../backend
chmod 755 -R .
chmod 777 logs uploads
echo -e "${GREEN}✓ Permissões configuradas${NC}"

# 4. Bot Node.js
echo ""
echo -e "${YELLOW}[4/5] Configurando bot...${NC}"

cd ../bot
npm install
echo -e "${GREEN}✓ Dependências instaladas${NC}"

# 5. PM2
echo ""
echo -e "${YELLOW}[5/5] Configurando PM2...${NC}"

if ! command -v pm2 &> /dev/null; then
    npm install -g pm2
    echo -e "${GREEN}✓ PM2 instalado${NC}"
fi

pm2 start src/index.js --name esim-bot
pm2 save
echo -e "${GREEN}✓ Bot iniciado${NC}"

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════╗${NC}"
echo -e "${GREEN}║    ✓ SETUP COMPLETO!                 ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════╝${NC}"
echo ""
echo -e "${BLUE}Próximos passos:${NC}"
echo -e "  1. Configure backend/config.php"
echo -e "  2. Configure bot/.env"
echo -e "  3. Teste: /start no Telegram"
echo -e "  4. Admin: http://seu-dominio.com/admin"
echo ""
echo -e "${BLUE}Comandos úteis:${NC}"
echo -e "  pm2 logs esim-bot    - Ver logs"
echo -e "  pm2 restart esim-bot - Reiniciar"
echo -e "  pm2 stop esim-bot    - Parar"
echo ""
